# accounts/management/commands/bootstrap_rbac.py
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from accounts.capabilities import CAPABILITY_CATALOG, CAPABILITY_KEYS, ROLE_CATALOG, ROLE_KEYS
from accounts.models import Capability, Role, RoleCapability, UserRole


def validate_catalog():
    # 输入：模块内能力与角色目录常量；输出：校验通过时无返回值；调用者：bootstrap_rbac 命令；失败：结构、重复或引用不一致时抛 CommandError。
    # 业务判断：先验证能力目录，再验证角色及其能力引用，任何目录错误都在数据库写入前失败关闭。
    if not isinstance(CAPABILITY_CATALOG, (list, tuple)) or not CAPABILITY_CATALOG:
        raise CommandError("能力目录必须是非空列表或元组。")

    capability_keys = []
    for index, item in enumerate(CAPABILITY_CATALOG, start=1):
        if not isinstance(item, dict):
            raise CommandError("第 %s 项能力定义必须是字典。" % index)
        for field_name in ("key", "name", "description"):
            value = item.get(field_name)
            if not isinstance(value, str) or not value.strip():
                raise CommandError(
                    "第 %s 项能力缺少有效的 %s。" % (index, field_name)
                )
        if not item["key"].startswith("accounts."):
            raise CommandError("能力编码必须使用 accounts.* 命名空间。")
        capability_keys.append(item["key"])

    if len(capability_keys) != len(set(capability_keys)):
        raise CommandError("能力目录存在重复编码。")
    if set(capability_keys) != set(CAPABILITY_KEYS):
        raise CommandError("能力编码常量与能力目录不一致。")

    if not isinstance(ROLE_CATALOG, (list, tuple)) or not ROLE_CATALOG:
        raise CommandError("角色目录必须是非空列表或元组。")

    role_keys = []
    role_names = []
    for index, role in enumerate(ROLE_CATALOG, start=1):
        if not isinstance(role, dict):
            raise CommandError("第 %s 项角色定义必须是字典。" % index)
        for field_name in ("key", "name", "description"):
            value = role.get(field_name)
            if not isinstance(value, str) or not value.strip():
                raise CommandError(
                    "第 %s 项角色缺少有效的 %s。" % (index, field_name)
                )
        capabilities = role.get("capabilities")
        if not isinstance(capabilities, (list, tuple)):
            raise CommandError("角色 %s 的能力集合必须是列表或元组。" % role["key"])
        if any(not isinstance(key, str) or not key for key in capabilities):
            raise CommandError("角色 %s 包含无效能力编码。" % role["key"])
        if len(capabilities) != len(set(capabilities)):
            raise CommandError("角色 %s 存在重复能力。" % role["key"])
        missing = sorted(set(capabilities) - set(capability_keys))
        if missing:
            raise CommandError(
                "角色 %s 引用了不存在的能力：%s。"
                % (role["key"], ", ".join(missing))
            )
        role_keys.append(role["key"])
        role_names.append(role["name"])

    if len(role_keys) != len(set(role_keys)):
        raise CommandError("角色目录存在重复编码。")
    if len(role_names) != len(set(role_names)):
        raise CommandError("角色目录存在重复名称。")
    if set(role_keys) != set(ROLE_KEYS):
        raise CommandError("角色编码常量与角色目录不一致。")


class Command(BaseCommand):
    help = "幂等创建项目自有能力和四个基础角色"
    requires_migrations_checks = True

    def handle(self, *args, **options):
        # 输入：Django 管理命令标准参数；输出：无返回值并打印同步统计；调用者：manage.py bootstrap_rbac；失败：目录冲突或数据库异常时整事务回滚并抛错。
        validate_catalog()
        counts = {
            "capabilities_created": 0,
            "capabilities_updated": 0,
            "roles_created": 0,
            "roles_updated": 0,
            "links_created": 0,
            "links_deleted": 0,
            "capabilities_retired": 0,
            "roles_retired": 0,
        }

        with transaction.atomic():
            # 数据库读取与锁顺序：与网页写入相同地按“角色 -> 能力 -> 角色能力”锁全目录，避免并发同步死锁和检查后变更。
            list(Role.objects.select_for_update().order_by("pk").values_list("pk", flat=True))
            list(Capability.objects.select_for_update().order_by("pk").values_list("pk", flat=True))
            list(RoleCapability.objects.select_for_update().order_by("pk").values_list("pk", flat=True))
            capability_map = {}
            declared_capability_keys = [item["key"] for item in CAPABILITY_CATALOG]
            declared_role_keys = [item["key"] for item in ROLE_CATALOG]
            # 业务判断：系统目录绝不接管同键的自定义记录，检测到占用即失败关闭并回滚。
            for item in CAPABILITY_CATALOG:
                existing = Capability.objects.filter(key=item["key"]).first()
                if existing is not None and not existing.is_system:
                    raise CommandError(
                        "能力编码 %s 已被非系统能力占用，拒绝接管。" % item["key"]
                    )
            for item in ROLE_CATALOG:
                existing = Role.objects.filter(key=item["key"]).first()
                if existing is not None and not existing.is_system:
                    raise CommandError(
                        "角色编码 %s 已被非系统角色占用，拒绝接管。" % item["key"]
                    )
            # 保存退休项：目录中已移除的系统能力停用；系统角色先删除能力和成员关系，再改名并转为停用自定义记录。
            stale_capabilities = Capability.objects.filter(is_system=True).exclude(
                key__in=declared_capability_keys
            )
            stale_roles = list(
                Role.objects.filter(is_system=True).exclude(key__in=declared_role_keys)
            )
            counts["capabilities_retired"] = stale_capabilities.update(
                is_system=False,
                is_active=False,
            )
            for stale_role in stale_roles:
                # 退休角色不能继续携带旧能力和用户成员关系。
                # 如果只把 is_active 改成 False，网页管理员稍后可能重新启用它，
                # 使历史用户突然恢复已经被目录淘汰的授权。
                RoleCapability.objects.filter(role=stale_role).delete()
                UserRole.objects.filter(role=stale_role).delete()
                base_name = "[已停用] %s" % stale_role.name
                candidate_name = base_name[:100]
                counter = 0
                while Role.objects.filter(name=candidate_name).exclude(
                    pk=stale_role.pk
                ).exists():
                    counter += 1
                    suffix = "-%s-%s" % (stale_role.pk, counter)
                    candidate_name = "%s%s" % (
                        base_name[: 100 - len(suffix)],
                        suffix,
                    )
                Role.objects.filter(pk=stale_role.pk).update(
                    name=candidate_name,
                    is_system=False,
                    is_active=False,
                )
            counts["roles_retired"] = len(stale_roles)
            for item in ROLE_CATALOG:
                conflict = Role.objects.filter(name=item["name"]).exclude(
                    key=item["key"]
                ).first()
                if conflict is not None:
                    # 早期版本只保留系统角色编码，没有保留中文名称。
                    # 这里保留冲突角色本身及其成员关系，只为它生成一个不冲突的新名称，
                    # 让初始化命令仍能恢复代码目录声明的系统角色。
                    base_name = "[名称冲突] %s" % conflict.name
                    candidate_name = base_name[:100]
                    counter = 0
                    while Role.objects.filter(name=candidate_name).exclude(
                        pk=conflict.pk
                    ).exists():
                        counter += 1
                        suffix = "-%s-%s" % (conflict.pk, counter)
                        candidate_name = "%s%s" % (
                            base_name[: 100 - len(suffix)],
                            suffix,
                        )
                    Role.objects.filter(pk=conflict.pk).update(name=candidate_name)
            # 保存能力：按稳定 key 幂等创建或精确恢复名称、说明、系统标记和启用状态。
            for item in CAPABILITY_CATALOG:
                capability, created = Capability.objects.get_or_create(
                    key=item["key"],
                    defaults={
                        "name": item["name"],
                        "description": item["description"],
                        "is_system": True,
                        "is_active": True,
                    },
                )
                if created:
                    counts["capabilities_created"] += 1
                else:
                    changed = (
                        capability.name != item["name"]
                        or capability.description != item["description"]
                        or not capability.is_system
                        or not capability.is_active
                    )
                    Capability.objects.filter(pk=capability.pk).update(
                        name=item["name"],
                        description=item["description"],
                        is_system=True,
                        is_active=True,
                    )
                    if changed:
                        counts["capabilities_updated"] += 1
                capability_map[item["key"]] = capability

            # 保存角色与关联：按稳定 key 幂等同步角色，再把每个系统角色的能力关联精确收敛到目录声明集合。
            for item in ROLE_CATALOG:
                role, created = Role.objects.get_or_create(
                    key=item["key"],
                    defaults={
                        "name": item["name"],
                        "description": item["description"],
                        "is_system": True,
                        "is_active": True,
                    },
                )
                if created:
                    counts["roles_created"] += 1
                else:
                    changed = (
                        role.name != item["name"]
                        or role.description != item["description"]
                        or not role.is_system
                        or not role.is_active
                    )
                    Role.objects.filter(pk=role.pk).update(
                        name=item["name"],
                        description=item["description"],
                        is_system=True,
                        is_active=True,
                    )
                    if changed:
                        counts["roles_updated"] += 1

                expected_ids = {
                    capability_map[key].pk for key in item["capabilities"]
                }
                existing_ids = set(
                    RoleCapability.objects.filter(role=role).values_list(
                        "capability_id", flat=True
                    )
                )
                extra_ids = existing_ids - expected_ids
                if extra_ids:
                    deleted, _ = RoleCapability.objects.filter(
                        role=role,
                        capability_id__in=extra_ids,
                    ).delete()
                    counts["links_deleted"] += deleted
                for capability_id in sorted(expected_ids - existing_ids):
                    _, created = RoleCapability.objects.get_or_create(
                        role=role,
                        capability_id=capability_id,
                    )
                    if created:
                        counts["links_created"] += 1

        # 返回：事务提交后才输出最终统计，避免把已回滚的中间计数误报为成功。
        self.stdout.write(
            self.style.SUCCESS(
                "能力：新建 %s、更新 %s、停用 %s；角色：新建 %s、更新 %s、停用 %s；角色能力：新建 %s、删除 %s。"
                % (
                    counts["capabilities_created"],
                    counts["capabilities_updated"],
                    counts["capabilities_retired"],
                    counts["roles_created"],
                    counts["roles_updated"],
                    counts["roles_retired"],
                    counts["links_created"],
                    counts["links_deleted"],
                )
            )
        )
