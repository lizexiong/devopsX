import hashlib

from django.db import migrations, models


def populate_subject_digests(apps, schema_editor):
    # 输入：历史应用注册表和 schema_editor；输出：无返回值并回填摘要；调用者：Django RunPython；失败：编码或数据库异常使迁移失败并回滚。
    # 数据库读取：使用历史 ExternalIdentity 模型迭代全部行，避免加载到内存或依赖未来模型方法。
    ExternalIdentity = apps.get_model("accounts", "ExternalIdentity")
    for identity in ExternalIdentity.objects.all().iterator():
        # 保存：逐行按原始 subject 计算 SHA-256 并只更新新增列，不规范化或改写第三方不透明值。
        identity.subject_digest = hashlib.sha256(
            identity.subject.encode("utf-8")
        ).hexdigest()
        identity.save(update_fields=["subject_digest"])


class Migration(migrations.Migration):
    dependencies = [
        ("accounts", "0004_externalidentity_logintransaction_and_more"),
    ]

    operations = [
        # 阶段一：先增加可空列，避免历史行因没有摘要而立即违反非空约束。
        migrations.AddField(
            model_name="externalidentity",
            name="subject_digest",
            # 类型：CharField；用途：暂存 subject 的 64 位 SHA-256 摘要；空值：迁移回填阶段临时允许 NULL；删除：随身份记录删除。
            field=models.CharField(
                editable=False,
                max_length=64,
                null=True,
                verbose_name="平台身份编号摘要",
            ),
        ),
        # 阶段二：在改变唯一键前为所有历史身份回填摘要；反向迁移保留数据而不尝试还原摘要。
        migrations.RunPython(
            populate_subject_digests,
            migrations.RunPython.noop,
        ),
        # 阶段三：移除 provider + 原始 subject 的旧唯一约束与索引，准备切换到固定长度摘要。
        migrations.RemoveConstraint(
            model_name="externalidentity",
            name="accounts_unique_external_identity",
        ),
        migrations.RemoveIndex(
            model_name="externalidentity",
            name="accounts_ext_identity_lookup",
        ),
        # 阶段四：摘要全部存在后收紧为非空，避免运行期产生不可索引身份。
        migrations.AlterField(
            model_name="externalidentity",
            name="subject_digest",
            # 类型：CharField；用途：回填后作为非空身份查找摘要；空值：不再允许 NULL；删除：随身份记录删除。
            field=models.CharField(
                editable=False,
                max_length=64,
                verbose_name="平台身份编号摘要",
            ),
        ),
        # 阶段五：新增 provider + digest 索引，并以同一组合唯一约束收敛并发创建竞争。
        migrations.AddIndex(
            model_name="externalidentity",
            index=models.Index(
                fields=["provider", "subject_digest"],
                name="accounts_ext_identity_digest",
            ),
        ),
        migrations.AddConstraint(
            model_name="externalidentity",
            constraint=models.UniqueConstraint(
                fields=("provider", "subject_digest"),
                name="accounts_unique_identity_digest",
            ),
        ),
    ]
