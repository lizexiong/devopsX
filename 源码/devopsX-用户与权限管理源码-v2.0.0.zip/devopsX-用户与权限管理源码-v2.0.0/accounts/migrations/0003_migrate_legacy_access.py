from django.db import migrations


# 这份映射是 0001 版本中真正展示给用户的旧角色名称。
# 迁移文件必须保存历史快照，不能依赖未来可能继续变化的 capabilities.py。
LEGACY_ROLE_MAP = {
    "平台管理员": "platform_admin",
    "用户管理员": "user_manager",
    "权限管理员": "permission_manager",
    "只读用户查看员": "readonly_viewer",
}


CAPABILITY_CATALOG = (
    ("accounts.dashboard.view", "查看管理首页", "访问用户与权限管理首页。"),
    ("accounts.user.view", "查看用户", "查看用户列表和用户详情。"),
    ("accounts.user.create", "创建用户", "创建普通用户账号。"),
    ("accounts.user.change", "编辑用户", "编辑用户业务资料。"),
    ("accounts.user.delete", "删除用户", "删除用户账号，但不能破坏最后一个激活超级用户。"),
    ("accounts.user.status", "管理用户状态", "启用或停用用户账号。"),
    ("accounts.user.assign_role", "分配用户角色", "为用户替换项目自有角色，不提供直接权限分配。"),
    ("accounts.department.view", "查看部门", "查看部门层级和部门用户统计。"),
    ("accounts.department.manage", "管理部门", "创建、编辑和删除部门。"),
    ("accounts.role.view", "查看角色", "查看项目自有角色及其能力。"),
    ("accounts.role.manage", "管理角色", "创建、编辑和删除项目自有角色及能力关联。"),
    ("accounts.capability.view", "查看能力目录", "只读查看项目自有能力目录。"),
)


ROLE_CATALOG = (
    (
        "platform_admin",
        "平台管理员",
        "拥有本项目全部管理能力。",
        (
            "accounts.dashboard.view",
            "accounts.user.view",
            "accounts.user.create",
            "accounts.user.change",
            "accounts.user.delete",
            "accounts.user.status",
            "accounts.user.assign_role",
            "accounts.department.view",
            "accounts.department.manage",
            "accounts.role.view",
            "accounts.role.manage",
            "accounts.capability.view",
        ),
    ),
    (
        "user_manager",
        "用户管理员",
        "负责用户资料、状态、角色分配及相关只读查询。",
        (
            "accounts.dashboard.view",
            "accounts.user.view",
            "accounts.user.create",
            "accounts.user.change",
            "accounts.user.delete",
            "accounts.user.status",
            "accounts.user.assign_role",
            "accounts.department.view",
            "accounts.role.view",
            "accounts.capability.view",
        ),
    ),
    (
        "permission_manager",
        "权限管理员",
        "负责角色能力配置和用户角色分配。",
        (
            "accounts.dashboard.view",
            "accounts.user.view",
            "accounts.user.assign_role",
            "accounts.department.view",
            "accounts.role.view",
            "accounts.role.manage",
            "accounts.capability.view",
        ),
    ),
    (
        "readonly_viewer",
        "只读查看员",
        "只能查看管理数据和能力目录。",
        (
            "accounts.dashboard.view",
            "accounts.user.view",
            "accounts.department.view",
            "accounts.role.view",
            "accounts.capability.view",
        ),
    ),
)


def create_catalog_and_migrate_legacy_groups(apps, schema_editor):
    # 输入：历史应用注册表和 schema_editor；输出：无返回值并迁移目录/成员；调用者：Django RunPython；失败：数据库异常使迁移事务失败。
    # 数据库读取：必须使用 apps.get_model 的历史模型，不能导入未来 models.py。
    Capability = apps.get_model("accounts", "Capability")
    Role = apps.get_model("accounts", "Role")
    RoleCapability = apps.get_model("accounts", "RoleCapability")
    UserRole = apps.get_model("accounts", "UserRole")
    Group = apps.get_model("auth", "Group")
    Permission = apps.get_model("auth", "Permission")

    # 保存能力：按历史快照幂等创建或更新系统能力，建立后续角色关联使用的 key 映射。
    capability_map = {}
    for key, name, description in CAPABILITY_CATALOG:
        capability, _ = Capability.objects.update_or_create(
            key=key,
            defaults={
                "name": name,
                "description": description,
                "is_system": True,
                "is_active": True,
            },
        )
        capability_map[key] = capability

    # 保存角色：按历史角色目录幂等写入角色及能力关联，避免迁移重试产生重复行。
    role_map = {}
    for key, name, description, capability_keys in ROLE_CATALOG:
        role, _ = Role.objects.update_or_create(
            key=key,
            defaults={
                "name": name,
                "description": description,
                "is_system": True,
                "is_active": True,
            },
        )
        role_map[key] = role
        for capability_key in capability_keys:
            RoleCapability.objects.get_or_create(
                role=role,
                capability=capability_map[capability_key],
            )

    # 业务迁移：仅把已知旧组成员映射到对应新角色，缺失旧组时安全跳过，不推断其他组名称。
    for legacy_name, role_key in LEGACY_ROLE_MAP.items():
        group = Group.objects.filter(name=legacy_name).first()
        if group is None:
            continue
        role = role_map[role_key]
        for user in group.user_set.all():
            UserRole.objects.get_or_create(
                user_id=user.pk,
                role_id=role.pk,
                defaults={"assigned_by_id": None},
            )

    # 保存清理：删除已被项目自有能力体系替代的两个旧 Django 权限，避免双轨授权继续存在。
    obsolete_permissions = Permission.objects.filter(
        content_type__app_label="accounts",
        content_type__model="user",
        codename__in=("set_user_status", "assign_user_roles"),
    )
    obsolete_permissions.delete()


def noop(apps, schema_editor):
    # 输入：历史应用注册表和 schema_editor；输出：None；调用者：反向 RunPython；失败：故意不删除已迁移业务数据。
    # 回滚时不删除角色、能力或已经迁移的用户角色，避免误删业务数据。
    return None


class Migration(migrations.Migration):
    dependencies = [
        ("accounts", "0002_custom_rbac"),
    ]

    operations = [
        migrations.RunPython(create_catalog_and_migrate_legacy_groups, noop),
    ]
