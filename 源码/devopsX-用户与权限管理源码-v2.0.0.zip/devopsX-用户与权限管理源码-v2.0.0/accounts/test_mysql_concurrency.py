import threading
from unittest import skipUnless
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.db import OperationalError, connection, connections
from django.test import Client, TransactionTestCase
from django.urls import reverse

from . import views
from .models import Role


User = get_user_model()
PASSWORD = "StrongPass!2468"


@skipUnless(connection.vendor == "mysql", "requires the MySQL test database")
class MySQLRoleConcurrencyTests(TransactionTestCase):
    def setUp(self):
        self.delete_operator = User.objects.create_superuser(
            username="mysql-delete-admin",
            password=PASSWORD,
        )
        self.access_operator = User.objects.create_superuser(
            username="mysql-access-admin",
            password=PASSWORD,
        )
        self.target = User.objects.create_user(
            username="mysql-lock-target",
            password=PASSWORD,
        )
        self.role = Role.objects.create(
            key="mysql-concurrency-role",
            name="MySQL 并发角色",
        )
        self.delete_client = Client()
        self.delete_client.force_login(self.delete_operator)
        self.access_client = Client()
        self.access_client.force_login(self.access_operator)

    def test_delete_blocks_concurrent_assignment(self):
        delete_holds_locks = threading.Event()
        release_delete = threading.Event()
        access_lock_attempted = threading.Event()
        access_done = threading.Event()
        responses = {}
        errors = {}
        delete_calls = 0
        counter_lock = threading.Lock()
        original_deny_role = views._deny_role_outside_capability_limit
        original_lock_catalog = views._lock_role_catalog

        def pause_delete_after_locks(operator, role):
            nonlocal delete_calls
            original_deny_role(operator, role)
            if threading.current_thread().name == "delete-request":
                with counter_lock:
                    delete_calls += 1
                    current_call = delete_calls
                if current_call == 2:
                    delete_holds_locks.set()
                    if not release_delete.wait(30):
                        raise TimeoutError("delete request was not released")

        def limit_access_lock_wait():
            if threading.current_thread().name == "access-request":
                with connection.cursor() as cursor:
                    cursor.execute("SET SESSION innodb_lock_wait_timeout = 1")
                access_lock_attempted.set()
            return original_lock_catalog()

        def delete_worker():
            connections.close_all()
            try:
                responses["delete"] = self.delete_client.post(
                    reverse("accounts:role_delete", args=[self.role.pk])
                )
            except BaseException as exc:
                errors["delete"] = exc
            finally:
                connections.close_all()

        def access_worker():
            connections.close_all()
            try:
                self.access_client.post(
                    reverse("accounts:user_access", args=[self.target.pk]),
                    {"roles": [self.role.pk]},
                )
            except BaseException as exc:
                errors["access"] = exc
            finally:
                access_done.set()
                connections.close_all()

        with patch.object(
            views,
            "_deny_role_outside_capability_limit",
            side_effect=pause_delete_after_locks,
        ), patch.object(
            views,
            "_lock_role_catalog",
            side_effect=limit_access_lock_wait,
        ):
            delete_thread = threading.Thread(
                target=delete_worker,
                name="delete-request",
            )
            access_thread = threading.Thread(
                target=access_worker,
                name="access-request",
            )
            delete_thread.start()
            try:
                self.assertTrue(delete_holds_locks.wait(10))
                access_thread.start()
                self.assertTrue(access_lock_attempted.wait(10))
                self.assertTrue(access_done.wait(10))
            finally:
                release_delete.set()
                delete_thread.join(30)
                if access_thread.ident is not None:
                    access_thread.join(30)

        self.assertFalse(delete_thread.is_alive())
        self.assertFalse(access_thread.is_alive())
        self.assertNotIn("delete", errors)
        self.assertIsInstance(errors.get("access"), OperationalError)
        self.assertEqual(errors["access"].args[0], 1205)
        self.assertEqual(responses["delete"].status_code, 302)
        self.assertFalse(Role.objects.filter(pk=self.role.pk).exists())

        retry_client = Client()
        retry_client.force_login(self.access_operator)
        retry_response = retry_client.post(
            reverse("accounts:user_access", args=[self.target.pk]),
            {"roles": [self.role.pk]},
        )
        self.assertEqual(retry_response.status_code, 200)
        self.assertFalse(self.target.roles.exists())

    def test_assignment_blocks_concurrent_delete(self):
        access_holds_locks = threading.Event()
        release_access = threading.Event()
        delete_lock_attempted = threading.Event()
        delete_done = threading.Event()
        responses = {}
        errors = {}
        access_calls = 0
        counter_lock = threading.Lock()
        original_deny_user = views._deny_non_superuser_managing_superuser
        original_select_for_update = Role.objects.select_for_update

        def pause_access_after_locks(operator, user_obj):
            nonlocal access_calls
            original_deny_user(operator, user_obj)
            if threading.current_thread().name == "access-request":
                with counter_lock:
                    access_calls += 1
                    current_call = access_calls
                if current_call == 2:
                    access_holds_locks.set()
                    if not release_access.wait(30):
                        raise TimeoutError("access request was not released")

        def limit_delete_lock_wait(*args, **kwargs):
            if threading.current_thread().name == "delete-request":
                with connection.cursor() as cursor:
                    cursor.execute("SET SESSION innodb_lock_wait_timeout = 1")
                delete_lock_attempted.set()
            return original_select_for_update(*args, **kwargs)

        def access_worker():
            connections.close_all()
            try:
                responses["access"] = self.access_client.post(
                    reverse("accounts:user_access", args=[self.target.pk]),
                    {"roles": [self.role.pk]},
                )
            except BaseException as exc:
                errors["access"] = exc
            finally:
                connections.close_all()

        def delete_worker():
            connections.close_all()
            try:
                self.delete_client.post(
                    reverse("accounts:role_delete", args=[self.role.pk])
                )
            except BaseException as exc:
                errors["delete"] = exc
            finally:
                delete_done.set()
                connections.close_all()

        with patch.object(
            views,
            "_deny_non_superuser_managing_superuser",
            side_effect=pause_access_after_locks,
        ), patch.object(
            Role.objects,
            "select_for_update",
            side_effect=limit_delete_lock_wait,
        ):
            access_thread = threading.Thread(
                target=access_worker,
                name="access-request",
            )
            delete_thread = threading.Thread(
                target=delete_worker,
                name="delete-request",
            )
            access_thread.start()
            try:
                self.assertTrue(access_holds_locks.wait(10))
                delete_thread.start()
                self.assertTrue(delete_lock_attempted.wait(10))
                self.assertTrue(delete_done.wait(10))
            finally:
                release_access.set()
                access_thread.join(30)
                if delete_thread.ident is not None:
                    delete_thread.join(30)

        self.assertFalse(access_thread.is_alive())
        self.assertFalse(delete_thread.is_alive())
        self.assertNotIn("access", errors)
        self.assertIsInstance(errors.get("delete"), OperationalError)
        self.assertEqual(errors["delete"].args[0], 1205)
        self.assertEqual(responses["access"].status_code, 302)
        self.assertTrue(self.target.roles.filter(pk=self.role.pk).exists())

        retry_client = Client()
        retry_client.force_login(self.delete_operator)
        retry_response = retry_client.post(
            reverse("accounts:role_delete", args=[self.role.pk])
        )
        self.assertEqual(retry_response.status_code, 302)
        self.assertTrue(Role.objects.filter(pk=self.role.pk).exists())
