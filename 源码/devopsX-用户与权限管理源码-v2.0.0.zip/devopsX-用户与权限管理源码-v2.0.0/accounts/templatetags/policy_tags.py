# accounts/templatetags/policy_tags.py
from django import template

from accounts.policy import has_capability


register = template.Library()


@register.simple_tag(takes_context=True)
def policy_can(context, capability_key, asvar=None):
    # 输入：模板上下文、能力键和可选变量名；输出：布尔值或空字符串；调用者：Django 模板；失败：无 request 时回退 user，未认证则安全返回 False。
    # request 级快照让一个页面内的多个能力判断复用同一次查询。
    request = context.get("request")
    if request is not None:
        allowed = has_capability(request, capability_key)
    else:
        allowed = has_capability(context.get("user"), capability_key)
    if asvar:
        context[asvar] = allowed
        return ""
    return allowed
