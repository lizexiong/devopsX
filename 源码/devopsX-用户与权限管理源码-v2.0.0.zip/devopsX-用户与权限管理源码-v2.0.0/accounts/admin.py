# accounts/admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import (
    AuthorizationAuditEvent,
    Capability,
    Department,
    ExternalIdentity,
    LoginTransaction,
    Role,
    RoleCapability,
    User,
    UserRole,
)


def _active_superuser(request):
    # 输入：Django Admin 请求；输出：当前用户是否为激活超级用户；调用者：后台权限混入类；失败：匿名用户属性由认证中间件提供并返回 False。
    return request.user.is_active and request.user.is_superuser


class SuperuserOnlyAdminMixin:
    # 项目自有管理后台只作为内部运维入口，不复用学习端 RBAC。
    def has_module_permission(self, request):
        # 输入：后台请求；输出：是否显示模型模块；调用者：Django Admin；失败：非激活超级用户一律返回 False。
        return _active_superuser(request)

    def has_view_permission(self, request, obj=None):
        # 输入：后台请求和可选对象；输出：是否允许查看；调用者：Django Admin；失败：非激活超级用户一律返回 False。
        return _active_superuser(request)

    def has_add_permission(self, request):
        # 输入：后台请求；输出：是否允许新增；调用者：Django Admin；失败：非激活超级用户一律返回 False。
        return _active_superuser(request)

    def has_change_permission(self, request, obj=None):
        # 输入：后台请求和可选对象；输出：是否允许修改；调用者：Django Admin；失败：非激活超级用户一律返回 False。
        return _active_superuser(request)

    def has_delete_permission(self, request, obj=None):
        # 输入：后台请求和可选对象；输出：固定 False；调用者：Django Admin；失败：后台删除始终关闭，需走专用业务流程。
        return False


@admin.register(User)
class CustomUserAdmin(SuperuserOnlyAdminMixin, UserAdmin):
    fieldsets = (
        (None, {"fields": ("username", "password")}),
        (
            "业务信息",
            {
                "fields": (
                    "display_name",
                    "employee_number",
                    "email",
                    "mobile",
                    "department",
                )
            },
        ),
        (
            "内部状态",
            {
                "fields": (
                    "is_active",
                    "is_staff",
                    "is_superuser",
                )
            },
        ),
        ("重要日期", {"fields": ("last_login", "date_joined")}),
    )
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "username",
                    "password1",
                    "password2",
                    "display_name",
                    "employee_number",
                    "email",
                    "mobile",
                    "department",
                    "is_active",
                    "is_staff",
                    "is_superuser",
                ),
            },
        ),
    )
    list_display = (
        "username",
        "display_name",
        "employee_number",
        "department",
        "is_active",
        "is_staff",
    )
    list_filter = ("is_active", "is_staff", "is_superuser", "department")
    search_fields = ("username", "display_name", "employee_number", "email", "mobile")
    ordering = ("username",)
    filter_horizontal = ()

    def get_readonly_fields(self, request, obj=None):
        # 输入：后台请求和可选用户对象；输出：只读字段元组；调用者：Django UserAdmin；失败：已有用户的状态和超级用户标记始终不可在通用表单修改。
        readonly_fields = super().get_readonly_fields(request, obj)
        if obj is None:
            return readonly_fields
        # 状态和超级用户标记仍由专门安全流程维护。
        return (*readonly_fields, "is_active", "is_superuser")


@admin.register(Department)
class DepartmentAdmin(SuperuserOnlyAdminMixin, admin.ModelAdmin):
    list_display = ("code", "name", "parent", "is_active", "sort_order")
    list_filter = ("is_active",)
    search_fields = ("code", "name")
    ordering = ("sort_order", "code")


@admin.register(Capability)
class CapabilityAdmin(SuperuserOnlyAdminMixin, admin.ModelAdmin):
    list_display = ("key", "name", "is_system", "is_active", "updated_at")
    list_filter = ("is_system", "is_active")
    search_fields = ("key", "name", "description")
    ordering = ("key",)

    def get_readonly_fields(self, request, obj=None):
        # 输入：后台请求和可选能力对象；输出：只读字段元组；调用者：Django ModelAdmin；失败：系统能力的内置标记和稳定键不可修改。
        fields = ["is_system"]
        if obj is not None and obj.is_system:
            fields.append("key")
        return tuple(fields)


@admin.register(Role)
class RoleAdmin(SuperuserOnlyAdminMixin, admin.ModelAdmin):
    list_display = ("key", "name", "is_system", "is_active", "updated_at")
    list_filter = ("is_system", "is_active")
    search_fields = ("key", "name", "description")
    ordering = ("name", "key")

    def get_readonly_fields(self, request, obj=None):
        # 输入：后台请求和可选角色对象；输出：只读字段元组；调用者：Django ModelAdmin；失败：系统角色的内置标记和稳定键不可修改。
        fields = ["is_system"]
        if obj is not None and obj.is_system:
            fields.append("key")
        return tuple(fields)


class ReadOnlyAssignmentAdmin(SuperuserOnlyAdminMixin, admin.ModelAdmin):
    # 关联表在学习端通过带事务和越权检查的服务流程写入。
    def has_add_permission(self, request):
        # 输入：后台请求；输出：固定 False；调用者：Django Admin；失败：禁止绕过事务服务新增关联或审计记录。
        return False

    def has_change_permission(self, request, obj=None):
        # 输入：后台请求和可选对象；输出：固定 False；调用者：Django Admin；失败：禁止绕过事务服务修改关联或审计记录。
        return False


@admin.register(RoleCapability)
class RoleCapabilityAdmin(ReadOnlyAssignmentAdmin):
    list_display = ("role", "capability", "assigned_by", "created_at")
    list_filter = ("role", "capability")
    search_fields = ("role__name", "capability__key", "capability__name")
    ordering = ("role", "capability")


@admin.register(UserRole)
class UserRoleAdmin(ReadOnlyAssignmentAdmin):
    list_display = ("user", "role", "assigned_by", "created_at")
    list_filter = ("role",)
    search_fields = ("user__username", "user__display_name", "role__name")
    ordering = ("user", "role")


@admin.register(ExternalIdentity)
class ExternalIdentityAdmin(ReadOnlyAssignmentAdmin):
    list_display = ("provider", "subject", "user", "display_name", "last_seen_at")
    list_filter = ("provider",)
    search_fields = ("subject", "user__username", "display_name", "email")
    ordering = ("provider", "subject")


@admin.register(LoginTransaction)
class LoginTransactionAdmin(ReadOnlyAssignmentAdmin):
    list_display = (
        "transaction_id",
        "provider",
        "intent",
        "status",
        "initiating_user",
        "created_at",
        "consumed_at",
    )
    list_filter = ("provider", "intent", "status")
    search_fields = ("transaction_id", "failure_code", "initiating_user__username")
    ordering = ("-created_at",)


@admin.register(AuthorizationAuditEvent)
class AuthorizationAuditEventAdmin(ReadOnlyAssignmentAdmin):
    list_display = (
        "event_type",
        "outcome",
        "provider",
        "actor",
        "target_user",
        "created_at",
    )
    list_filter = ("event_type", "outcome", "provider")
    search_fields = (
        "reason_code",
        "actor__username",
        "target_user__username",
    )
    ordering = ("-created_at",)
