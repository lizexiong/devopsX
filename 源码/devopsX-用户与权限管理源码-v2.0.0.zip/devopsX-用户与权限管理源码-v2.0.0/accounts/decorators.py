# accounts/decorators.py
from functools import wraps

from django.contrib.auth.decorators import login_required

from .policy import (
    require_all_capabilities,
    require_any_capability,
    require_capability,
)


def capability_required(capability_key):
    # 输入：单个能力编码；输出：视图装饰器；调用者：受保护视图定义；失败：运行时未登录跳转、缺能力抛 PermissionDenied。
    def decorator(view_func):
        # 输入：原视图函数；输出：保留元数据的包装函数；调用者：Python 装饰器机制；失败：校验失败时不调用原视图。
        @login_required
        @wraps(view_func)
        def wrapped(request, *args, **kwargs):
            # 输入：请求和原视图参数；输出：原视图响应；调用者：Django 路由；失败：匿名跳登录、已登录但缺能力时统一 403。
            # 登录跳转由 Django 处理，已登录但缺能力时统一抛出 403。
            require_capability(request, capability_key)
            return view_func(request, *args, **kwargs)

        return wrapped

    return decorator


def any_capability_required(capability_keys):
    # 输入：能力编码可迭代对象；输出：要求任一能力的视图装饰器；调用者：受保护视图定义；失败：空集合或均缺失时拒绝。
    keys = tuple(capability_keys)

    def decorator(view_func):
        # 输入：原视图函数；输出：保留元数据的包装函数；调用者：Python 装饰器机制；失败：校验失败时不调用原视图。
        @login_required
        @wraps(view_func)
        def wrapped(request, *args, **kwargs):
            # 输入：请求和原视图参数；输出：原视图响应；调用者：Django 路由；失败：匿名跳登录、没有任一能力时 403。
            require_any_capability(request, keys)
            return view_func(request, *args, **kwargs)

        return wrapped

    return decorator


def all_capabilities_required(capability_keys):
    # 输入：能力编码可迭代对象；输出：要求全部能力的视图装饰器；调用者：受保护视图定义；失败：空集合或任一缺失时拒绝。
    keys = tuple(capability_keys)

    def decorator(view_func):
        # 输入：原视图函数；输出：保留元数据的包装函数；调用者：Python 装饰器机制；失败：校验失败时不调用原视图。
        @login_required
        @wraps(view_func)
        def wrapped(request, *args, **kwargs):
            # 输入：请求和原视图参数；输出：原视图响应；调用者：Django 路由；失败：匿名跳登录、缺任一能力时 403。
            require_all_capabilities(request, keys)
            return view_func(request, *args, **kwargs)

        return wrapped

    return decorator
