import hashlib

from django.db import IntegrityError, connection, transaction
from django.db.migrations.executor import MigrationExecutor
from django.test import TransactionTestCase


class LegacyAccessMigrationTests(TransactionTestCase):
    migrate_from = [("accounts", "0001_initial")]
    migrate_to = [("accounts", "0003_migrate_legacy_access")]

    def setUp(self):
        super().setUp()
        executor = MigrationExecutor(connection)
        executor.migrate(self.migrate_from)
        old_apps = executor.loader.project_state(self.migrate_from).apps

        User = old_apps.get_model("accounts", "User")
        Group = old_apps.get_model("auth", "Group")
        Permission = old_apps.get_model("auth", "Permission")
        ContentType = old_apps.get_model("contenttypes", "ContentType")

        self.legacy_user = User.objects.create(username="legacy-viewer")
        legacy_group = Group.objects.create(name="只读用户查看员")
        self.legacy_user.groups.add(legacy_group)

        user_content_type, _ = ContentType.objects.get_or_create(
            app_label="accounts",
            model="user",
        )
        obsolete_permission, _ = Permission.objects.get_or_create(
            content_type=user_content_type,
            codename="set_user_status",
            defaults={"name": "可以启用或停用用户"},
        )
        self.legacy_user.user_permissions.add(obsolete_permission)

        executor = MigrationExecutor(connection)
        executor.migrate(self.migrate_to)
        self.apps = executor.loader.project_state(self.migrate_to).apps

    def tearDown(self):
        executor = MigrationExecutor(connection)
        executor.migrate(executor.loader.graph.leaf_nodes())
        super().tearDown()

    def test_migration_preserves_recognized_group_access_in_custom_rbac(self):
        Role = self.apps.get_model("accounts", "Role")
        UserRole = self.apps.get_model("accounts", "UserRole")
        Capability = self.apps.get_model("accounts", "Capability")
        Permission = self.apps.get_model("auth", "Permission")

        role = Role.objects.get(key="readonly_viewer")
        self.assertTrue(role.is_system)
        self.assertTrue(
            UserRole.objects.filter(
                user_id=self.legacy_user.pk,
                role_id=role.pk,
            ).exists()
        )
        self.assertEqual(Capability.objects.filter(is_system=True).count(), 12)
        self.assertFalse(
            Permission.objects.filter(
                content_type__app_label="accounts",
                content_type__model="user",
                codename="set_user_status",
            ).exists()
        )


class ExternalIdentitySchemaMigrationTests(TransactionTestCase):
    migrate_from = [("accounts", "0003_migrate_legacy_access")]
    migrate_to = [("accounts", "0004_externalidentity_logintransaction_and_more")]

    def setUp(self):
        super().setUp()
        executor = MigrationExecutor(connection)
        executor.migrate(self.migrate_from)
        old_apps = executor.loader.project_state(self.migrate_from).apps

        User = old_apps.get_model("accounts", "User")
        self.user_id = User.objects.create(username="external-migration-user").pk

        executor = MigrationExecutor(connection)
        executor.migrate(self.migrate_to)
        self.apps = executor.loader.project_state(self.migrate_to).apps

    def tearDown(self):
        executor = MigrationExecutor(connection)
        executor.migrate(executor.loader.graph.leaf_nodes())
        super().tearDown()

    def test_migration_creates_identity_transaction_and_audit_schema(self):
        ExternalIdentity = self.apps.get_model("accounts", "ExternalIdentity")
        LoginTransaction = self.apps.get_model("accounts", "LoginTransaction")
        AuthorizationAuditEvent = self.apps.get_model(
            "accounts",
            "AuthorizationAuditEvent",
        )

        identity = ExternalIdentity.objects.create(
            provider="fake",
            subject="migration-subject",
            user_id=self.user_id,
        )
        self.assertEqual(identity.user_id, self.user_id)

        with self.assertRaises(IntegrityError), transaction.atomic():
            ExternalIdentity.objects.create(
                provider="fake",
                subject="migration-subject",
            )

        transaction_fields = {
            field.name for field in LoginTransaction._meta.get_fields()
        }
        self.assertIn("state_digest", transaction_fields)
        self.assertIn("session_binding", transaction_fields)
        self.assertIn("code_challenge", transaction_fields)
        self.assertIn("nonce_digest", transaction_fields)
        self.assertNotIn("authorization_code", transaction_fields)
        self.assertNotIn("access_token", transaction_fields)
        self.assertNotIn("refresh_token", transaction_fields)

        audit_fields = {
            field.name for field in AuthorizationAuditEvent._meta.get_fields()
        }
        self.assertIn("reason_code", audit_fields)
        self.assertIn("detail", audit_fields)


class ExternalIdentityDigestMigrationTests(TransactionTestCase):
    migrate_from = [
        ("accounts", "0004_externalidentity_logintransaction_and_more")
    ]
    migrate_to = [
        ("accounts", "0005_external_identity_subject_digest")
    ]

    def setUp(self):
        super().setUp()
        executor = MigrationExecutor(connection)
        executor.migrate(self.migrate_from)
        old_apps = executor.loader.project_state(self.migrate_from).apps
        User = old_apps.get_model("accounts", "User")
        ExternalIdentity = old_apps.get_model("accounts", "ExternalIdentity")
        user = User.objects.create(username="digest-migration-user")
        self.identity_id = ExternalIdentity.objects.create(
            provider="fake",
            subject="Case-Sensitive-Migration-Subject",
            user_id=user.pk,
        ).pk

        executor = MigrationExecutor(connection)
        executor.migrate(self.migrate_to)
        self.apps = executor.loader.project_state(self.migrate_to).apps

    def tearDown(self):
        executor = MigrationExecutor(connection)
        executor.migrate(executor.loader.graph.leaf_nodes())
        super().tearDown()

    def test_migration_backfills_case_sensitive_subject_digest(self):
        ExternalIdentity = self.apps.get_model("accounts", "ExternalIdentity")
        identity = ExternalIdentity.objects.get(pk=self.identity_id)
        expected_digest = hashlib.sha256(
            identity.subject.encode("utf-8")
        ).hexdigest()
        self.assertEqual(identity.subject_digest, expected_digest)

        lower_subject = identity.subject.lower()
        lower_digest = hashlib.sha256(lower_subject.encode("utf-8")).hexdigest()
        ExternalIdentity.objects.create(
            provider="fake",
            subject=lower_subject,
            subject_digest=lower_digest,
        )
        with self.assertRaises(IntegrityError), transaction.atomic():
            ExternalIdentity.objects.create(
                provider="fake",
                subject=identity.subject,
                subject_digest=expected_digest,
            )
