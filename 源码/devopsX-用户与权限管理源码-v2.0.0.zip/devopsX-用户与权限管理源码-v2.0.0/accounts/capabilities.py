# accounts/capabilities.py
"""项目自有能力目录与内置角色定义。"""


# 能力编码是页面、策略和初始化数据之间的稳定接口；字符串变化等同于授权契约变化。
# 以下常量只描述“能做什么”，用户是否具备能力由 UserRole -> RoleCapability 关系在 policy.py 中计算。
DASHBOARD_VIEW = "accounts.dashboard.view"
USER_VIEW = "accounts.user.view"
USER_CREATE = "accounts.user.create"
USER_CHANGE = "accounts.user.change"
USER_DELETE = "accounts.user.delete"
USER_STATUS = "accounts.user.status"
USER_ASSIGN_ROLE = "accounts.user.assign_role"
DEPARTMENT_VIEW = "accounts.department.view"
DEPARTMENT_MANAGE = "accounts.department.manage"
ROLE_VIEW = "accounts.role.view"
ROLE_MANAGE = "accounts.role.manage"
CAPABILITY_VIEW = "accounts.capability.view"


# 每一项同时提供稳定 key、管理界面名称和说明；bootstrap_rbac 会把它们精确同步为系统能力。
CAPABILITY_CATALOG = (
    {
        "key": DASHBOARD_VIEW,
        "name": "查看管理首页",
        "description": "访问用户与权限管理首页。",
    },
    {
        "key": USER_VIEW,
        "name": "查看用户",
        "description": "查看用户列表和用户详情。",
    },
    {
        "key": USER_CREATE,
        "name": "创建用户",
        "description": "创建普通用户账号。",
    },
    {
        "key": USER_CHANGE,
        "name": "编辑用户",
        "description": "编辑用户业务资料。",
    },
    {
        "key": USER_DELETE,
        "name": "删除用户",
        "description": "删除用户账号，但不能破坏最后一个激活超级用户。",
    },
    {
        "key": USER_STATUS,
        "name": "管理用户状态",
        "description": "启用或停用用户账号。",
    },
    {
        "key": USER_ASSIGN_ROLE,
        "name": "分配用户角色",
        "description": "为用户替换项目自有角色，不提供直接权限分配。",
    },
    {
        "key": DEPARTMENT_VIEW,
        "name": "查看部门",
        "description": "查看部门层级和部门用户统计。",
    },
    {
        "key": DEPARTMENT_MANAGE,
        "name": "管理部门",
        "description": "创建、编辑和删除部门。",
    },
    {
        "key": ROLE_VIEW,
        "name": "查看角色",
        "description": "查看项目自有角色及其能力。",
    },
    {
        "key": ROLE_MANAGE,
        "name": "管理角色",
        "description": "创建、编辑和删除项目自有角色及能力关联。",
    },
    {
        "key": CAPABILITY_VIEW,
        "name": "查看能力目录",
        "description": "只读查看项目自有能力目录。",
    },
)


# 角色能力集合集中声明，bootstrap 命令据此精确同步数据库。
# capabilities 元组是完整期望集合，不是增量补丁；目录中移除的关联会在初始化时删除。
ROLE_CATALOG = (
    {
        "key": "platform_admin",
        "name": "平台管理员",
        "description": "拥有本项目全部管理能力。",
        "capabilities": tuple(item["key"] for item in CAPABILITY_CATALOG),
    },
    {
        "key": "user_manager",
        "name": "用户管理员",
        "description": "负责用户资料、状态、角色分配及相关只读查询。",
        "capabilities": (
            DASHBOARD_VIEW,
            USER_VIEW,
            USER_CREATE,
            USER_CHANGE,
            USER_DELETE,
            USER_STATUS,
            USER_ASSIGN_ROLE,
            DEPARTMENT_VIEW,
            ROLE_VIEW,
            CAPABILITY_VIEW,
        ),
    },
    {
        "key": "permission_manager",
        "name": "权限管理员",
        "description": "负责角色能力配置和用户角色分配。",
        "capabilities": (
            DASHBOARD_VIEW,
            USER_VIEW,
            USER_ASSIGN_ROLE,
            DEPARTMENT_VIEW,
            ROLE_VIEW,
            ROLE_MANAGE,
            CAPABILITY_VIEW,
        ),
    },
    {
        "key": "readonly_viewer",
        "name": "只读查看员",
        "description": "只能查看管理数据和能力目录。",
        "capabilities": (
            DASHBOARD_VIEW,
            USER_VIEW,
            DEPARTMENT_VIEW,
            ROLE_VIEW,
            CAPABILITY_VIEW,
        ),
    },
)

# 派生集合用于启动命令一致性校验和模型/表单保留键保护，避免目录与常量各自漂移。
CAPABILITY_KEYS = frozenset(item["key"] for item in CAPABILITY_CATALOG)
ROLE_KEYS = frozenset(item["key"] for item in ROLE_CATALOG)
ROLE_NAMES = frozenset(item["name"] for item in ROLE_CATALOG)
