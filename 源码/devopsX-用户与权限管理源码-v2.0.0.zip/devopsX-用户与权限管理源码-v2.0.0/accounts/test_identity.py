# accounts/test_identity.py
import uuid
from datetime import timedelta
from unittest.mock import patch
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

from django.contrib import admin
from django.db import IntegrityError, transaction
from django.test import Client, RequestFactory, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .admin import AuthorizationAuditEventAdmin, ExternalIdentityAdmin, LoginTransactionAdmin
from .identity import (
    SESSION_NONCE_KEY,
    SESSION_STATE_KEY,
    SESSION_TRANSACTION_KEY,
    SESSION_VERIFIER_KEY,
    ExternalFlowError,
    unbind_external_identity,
)
from .models import (
    AuditEventType,
    AuditOutcome,
    AuthorizationAuditEvent,
    ExternalIdentity,
    IdentityProvider,
    LoginTransaction,
    LoginTransactionStatus,
    User,
    external_subject_digest,
)
from .providers.base import ProviderCallbackError, ProviderUnavailable
from .providers.enterprise_wechat import EnterpriseWechatProvider
from .providers.fake import FAKE_IDENTITIES
from .providers.feishu import FeishuProvider
from .providers.wechat_open_platform import WechatOpenPlatformProvider


PASSWORD = "StrongPass!2468"


class ExternalIdentityFlowTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username="external-user",
            password=PASSWORD,
            email="local@example.invalid",
        )
        self.other_user = User.objects.create_user(
            username="other-user",
            password=PASSWORD,
        )

    def _start_login(self, identity="demo-viewer"):
        response = self.client.post(
            reverse("accounts:external_start", args=[IdentityProvider.FAKE]),
            {"identity": identity},
        )
        self.assertEqual(response.status_code, 302)
        return response["Location"]

    def _start_bind(self, identity="demo-viewer", password=PASSWORD):
        response = self.client.post(
            reverse("accounts:external_bind_start", args=[IdentityProvider.FAKE]),
            {"identity": identity, "password": password},
        )
        return response

    def _authorization_post_data(self, authorization_url, decision="approve"):
        response = self.client.get(authorization_url)
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "accounts/fake_authorize.html")
        form = response.context["form"]
        return {
            "identity": form["identity"].value(),
            "redirect_uri": form["redirect_uri"].value(),
            "state": form["state"].value(),
            "code_challenge": form["code_challenge"].value(),
            "nonce": form["nonce"].value(),
            "transaction_id": form["transaction_id"].value(),
            "decision": decision,
        }

    def _authorize(self, authorization_url, decision="approve"):
        data = self._authorization_post_data(authorization_url, decision=decision)
        response = self.client.post(reverse("accounts:fake_authorize"), data)
        self.assertEqual(response.status_code, 302)
        return response["Location"]

    def _bind_viewer_identity(self):
        self.client.force_login(self.user)
        response = self._start_bind()
        self.assertEqual(response.status_code, 302)
        callback_url = self._authorize(response["Location"])
        response = self.client.get(callback_url)
        self.assertRedirects(response, reverse("accounts:external_identities"))
        return ExternalIdentity.objects.get(
            provider=IdentityProvider.FAKE,
            subject=FAKE_IDENTITIES["demo-viewer"]["subject"],
        )

    def test_external_identity_uses_case_sensitive_subject_digest(self):
        identity = ExternalIdentity.objects.create(
            provider=IdentityProvider.FAKE,
            subject="Case-Sensitive-Subject",
            user=self.user,
        )
        lower_case_identity = ExternalIdentity.objects.create(
            provider=IdentityProvider.FAKE,
            subject="case-sensitive-subject",
            user=self.other_user,
        )

        self.assertEqual(identity.subject, "Case-Sensitive-Subject")
        self.assertEqual(
            identity.subject_digest,
            external_subject_digest("Case-Sensitive-Subject"),
        )
        self.assertNotEqual(identity.subject_digest, lower_case_identity.subject_digest)
        with self.assertRaises(IntegrityError), transaction.atomic():
            ExternalIdentity.objects.create(
                provider=IdentityProvider.FAKE,
                subject="Case-Sensitive-Subject",
                user=self.other_user,
            )

    def test_start_persists_only_digests_and_no_callback_secrets(self):
        self._start_login()
        session = self.client.session
        login_transaction = LoginTransaction.objects.get()

        self.assertNotEqual(login_transaction.state_digest, session[SESSION_STATE_KEY])
        self.assertNotEqual(login_transaction.nonce_digest, session[SESSION_NONCE_KEY])
        self.assertNotEqual(login_transaction.code_challenge, session[SESSION_VERIFIER_KEY])
        self.assertEqual(
            str(login_transaction.transaction_id),
            session[SESSION_TRANSACTION_KEY],
        )
        field_names = {field.name for field in LoginTransaction._meta.get_fields()}
        self.assertNotIn("authorization_code", field_names)
        self.assertNotIn("code_verifier", field_names)
        self.assertNotIn("access_token", field_names)
        self.assertNotIn("refresh_token", field_names)
        audit = AuthorizationAuditEvent.objects.get(
            event_type=AuditEventType.LOGIN_STARTED
        )
        serialized_audit = "%s %s %s" % (
            audit.reason_code,
            audit.provider,
            audit.detail,
        )
        self.assertNotIn(session[SESSION_STATE_KEY], serialized_audit)
        self.assertNotIn(session[SESSION_VERIFIER_KEY], serialized_audit)
        self.assertNotIn(session[SESSION_NONCE_KEY], serialized_audit)

    def test_unbound_identity_never_creates_or_email_merges_user(self):
        User.objects.create_user(
            username="same-email-user",
            password=PASSWORD,
            email=FAKE_IDENTITIES["demo-viewer"]["email"],
        )
        original_user_count = User.objects.count()
        callback_url = self._authorize(self._start_login())
        response = self.client.get(callback_url)

        self.assertEqual(response.status_code, 400)
        self.assertEqual(User.objects.count(), original_user_count)
        self.assertNotIn("_auth_user_id", self.client.session)
        identity = ExternalIdentity.objects.get(
            provider=IdentityProvider.FAKE,
            subject=FAKE_IDENTITIES["demo-viewer"]["subject"],
        )
        self.assertIsNone(identity.user_id)
        self.assertNotContains(response, identity.subject, status_code=400)

    def test_bind_then_external_login_creates_session_and_audits_success(self):
        identity = self._bind_viewer_identity()
        self.assertEqual(identity.user, self.user)
        self.assertTrue(
            AuthorizationAuditEvent.objects.filter(
                event_type=AuditEventType.IDENTITY_BOUND,
                outcome=AuditOutcome.SUCCESS,
                target_user=self.user,
            ).exists()
        )

        self.client.post(reverse("accounts:logout"))
        callback_url = self._authorize(self._start_login())
        response = self.client.get(callback_url)

        self.assertRedirects(
            response,
            reverse("accounts:home"),
            fetch_redirect_response=False,
        )
        self.assertEqual(int(self.client.session["_auth_user_id"]), self.user.pk)
        self.assertTrue(
            AuthorizationAuditEvent.objects.filter(
                event_type=AuditEventType.LOGIN_SUCCEEDED,
                outcome=AuditOutcome.SUCCESS,
                target_user=self.user,
            ).exists()
        )

    def test_bind_requires_current_password(self):
        self.client.force_login(self.user)
        response = self._start_bind(password="wrong-password")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "当前密码不正确")
        self.assertFalse(LoginTransaction.objects.exists())
        self.assertFalse(ExternalIdentity.objects.exists())

    def test_identity_bound_to_another_user_is_rejected(self):
        identity = ExternalIdentity.objects.create(
            provider=IdentityProvider.FAKE,
            subject=FAKE_IDENTITIES["demo-viewer"]["subject"],
            user=self.other_user,
        )
        self.client.force_login(self.user)
        callback_url = self._authorize(self._start_bind()["Location"])
        response = self.client.get(callback_url)

        self.assertEqual(response.status_code, 409)
        identity.refresh_from_db()
        self.assertEqual(identity.user, self.other_user)
        login_transaction = LoginTransaction.objects.latest("created_at")
        self.assertEqual(login_transaction.status, LoginTransactionStatus.FAILED)
        self.assertEqual(login_transaction.failure_code, "identity_already_bound")

    def test_wrong_state_and_replay_do_not_create_second_login(self):
        self._bind_viewer_identity()
        self.client.post(reverse("accounts:logout"))
        callback_url = self._authorize(self._start_login())
        parsed = urlparse(callback_url)
        query = parse_qs(parsed.query)
        query["state"] = ["wrong-state"]
        wrong_state_url = urlunparse(
            parsed._replace(query=urlencode(query, doseq=True))
        )
        response = self.client.get(wrong_state_url)
        self.assertEqual(response.status_code, 400)
        self.assertNotIn("_auth_user_id", self.client.session)

        callback_url = self._authorize(self._start_login())
        first = self.client.get(callback_url)
        self.assertRedirects(
            first,
            reverse("accounts:home"),
            fetch_redirect_response=False,
        )
        success_count = AuthorizationAuditEvent.objects.filter(
            event_type=AuditEventType.LOGIN_SUCCEEDED
        ).count()
        second = self.client.get(callback_url)
        self.assertEqual(second.status_code, 400)
        self.assertEqual(
            AuthorizationAuditEvent.objects.filter(
                event_type=AuditEventType.LOGIN_SUCCEEDED
            ).count(),
            success_count,
        )

    def test_forged_callback_does_not_clear_current_flow_session(self):
        authorization_url = self._start_login()
        session_before = self.client.session
        transaction_id = session_before[SESSION_TRANSACTION_KEY]
        state = session_before[SESSION_STATE_KEY]

        forged_callback = reverse(
            "accounts:external_callback",
            args=[IdentityProvider.FAKE],
        )
        response = self.client.get(
            forged_callback,
            {
                "transaction_id": str(uuid.uuid4()),
                "state": "attacker-state",
                "code": "attacker-code",
            },
        )
        self.assertEqual(response.status_code, 400)

        session_after = self.client.session
        self.assertEqual(session_after[SESSION_TRANSACTION_KEY], transaction_id)
        self.assertEqual(session_after[SESSION_STATE_KEY], state)

        callback_url = self._authorize(authorization_url)
        response = self.client.get(callback_url)
        self.assertEqual(response.status_code, 400)
        self.assertNotIn(SESSION_TRANSACTION_KEY, self.client.session)

    def test_inactive_user_cannot_unbind_with_existing_session(self):
        identity = self._bind_viewer_identity()
        self.user.is_active = False
        self.user.save(update_fields=["is_active"])

        response = self.client.post(
            reverse("accounts:external_identity_unbind", args=[identity.pk])
        )

        self.assertRedirects(
            response,
            "%s?next=/external/identities/%s/unbind/"
            % (reverse("accounts:login"), identity.pk),
            fetch_redirect_response=False,
        )
        request = RequestFactory().post(
            reverse("accounts:external_identity_unbind", args=[identity.pk])
        )
        request.user = self.user
        with self.assertRaises(ExternalFlowError) as error_context:
            unbind_external_identity(request, identity.pk)
        self.assertEqual(error_context.exception.reason_code, "account_inactive")
        identity.refresh_from_db()
        self.assertEqual(identity.user_id, self.user.pk)

    def test_expired_transaction_and_provider_denial_are_recorded(self):
        authorization_url = self._start_login()
        LoginTransaction.objects.update(expires_at=timezone.now() - timedelta(seconds=1))
        callback_url = self._authorize(authorization_url)
        response = self.client.get(callback_url)
        self.assertEqual(response.status_code, 400)
        expired = LoginTransaction.objects.get()
        self.assertEqual(expired.status, LoginTransactionStatus.FAILED)
        self.assertEqual(expired.failure_code, "transaction_expired")

        LoginTransaction.objects.all().delete()
        AuthorizationAuditEvent.objects.all().delete()
        authorization_url = self._start_login()
        callback_url = self._authorize(authorization_url, decision="deny")
        response = self.client.get(callback_url)
        self.assertEqual(response.status_code, 400)
        denied = LoginTransaction.objects.get()
        self.assertEqual(denied.status, LoginTransactionStatus.FAILED)
        self.assertEqual(denied.failure_code, "provider_access_denied")

    def test_pkce_and_nonce_tampering_fail_before_identity_resolution(self):
        authorization_url = self._start_login()
        callback_url = self._authorize(authorization_url)
        session = self.client.session
        session[SESSION_VERIFIER_KEY] = "wrong-verifier"
        session.save()
        response = self.client.get(callback_url)
        self.assertEqual(response.status_code, 400)
        self.assertFalse(ExternalIdentity.objects.exists())

        LoginTransaction.objects.all().delete()
        authorization_url = self._start_login()
        callback_url = self._authorize(authorization_url)
        session = self.client.session
        session[SESSION_NONCE_KEY] = "wrong-nonce"
        session.save()
        response = self.client.get(callback_url)
        self.assertEqual(response.status_code, 400)
        self.assertFalse(ExternalIdentity.objects.exists())

    def test_unbind_retains_identity_and_last_login_method_is_protected(self):
        identity = self._bind_viewer_identity()
        response = self.client.post(
            reverse("accounts:external_identity_unbind", args=[identity.pk])
        )
        self.assertRedirects(response, reverse("accounts:external_identities"))
        identity.refresh_from_db()
        self.assertIsNone(identity.user_id)
        self.assertTrue(
            AuthorizationAuditEvent.objects.filter(
                event_type=AuditEventType.IDENTITY_UNBOUND,
                outcome=AuditOutcome.SUCCESS,
            ).exists()
        )

        identity.user = self.user
        identity.save(update_fields=["user"])
        self.user.set_unusable_password()
        self.user.save(update_fields=["password"])
        self.client.force_login(self.user)
        response = self.client.post(
            reverse("accounts:external_identity_unbind", args=[identity.pk])
        )
        self.assertRedirects(response, reverse("accounts:external_identities"))
        identity.refresh_from_db()
        self.assertEqual(identity.user, self.user)
        self.assertTrue(
            AuthorizationAuditEvent.objects.filter(
                event_type=AuditEventType.IDENTITY_UNBOUND,
                outcome=AuditOutcome.DENIED,
                reason_code="last_login_method",
            ).exists()
        )

    def test_real_provider_stubs_fail_closed_and_fake_is_debug_only(self):
        providers = (
            (
                IdentityProvider.ENTERPRISE_WECHAT,
                EnterpriseWechatProvider,
                "enterprise_wechat_not_configured",
            ),
            (
                IdentityProvider.FEISHU,
                FeishuProvider,
                "feishu_not_configured",
            ),
            (
                IdentityProvider.WECHAT_OPEN_PLATFORM,
                WechatOpenPlatformProvider,
                "wechat_open_platform_not_configured",
            ),
        )
        for provider_key, provider_class, reason_code in providers:
            with self.subTest(provider=provider_key):
                response = self.client.post(
                    reverse("accounts:external_start", args=[provider_key])
                )
                self.assertEqual(response.status_code, 400)
                login_transaction = LoginTransaction.objects.latest("created_at")
                self.assertEqual(
                    login_transaction.status,
                    LoginTransactionStatus.FAILED,
                )
                self.assertEqual(login_transaction.failure_code, reason_code)
                with self.assertRaises(ProviderUnavailable):
                    provider_class().complete_callback(None)

        self.assertFalse(ExternalIdentity.objects.exists())
        LoginTransaction.objects.all().delete()
        with override_settings(ACCOUNTS_ENABLE_FAKE_PROVIDER=False):
            response = self.client.post(
                reverse("accounts:external_start", args=[IdentityProvider.FAKE]),
                {"identity": "demo-viewer"},
            )
        self.assertEqual(response.status_code, 400)
        self.assertFalse(LoginTransaction.objects.exists())

        with override_settings(
            DEBUG=False,
            ACCOUNTS_ENABLE_FAKE_PROVIDER=True,
            ACCOUNTS_FAKE_PROVIDER_ALLOWED=False,
        ):
            response = self.client.post(
                reverse("accounts:external_start", args=[IdentityProvider.FAKE]),
                {"identity": "demo-viewer"},
            )
        self.assertEqual(response.status_code, 400)
        self.assertFalse(LoginTransaction.objects.exists())

    def test_session_provider_and_redirect_bindings_fail_closed(self):
        callback_url = self._authorize(self._start_login())
        source_session = self.client.session
        other_client = Client()
        other_session = other_client.session
        for key in (
            SESSION_TRANSACTION_KEY,
            SESSION_STATE_KEY,
            SESSION_VERIFIER_KEY,
            SESSION_NONCE_KEY,
        ):
            other_session[key] = source_session[key]
        other_session.save()

        response = other_client.get(callback_url)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(
            LoginTransaction.objects.get().status,
            LoginTransactionStatus.PENDING,
        )
        self.assertFalse(ExternalIdentity.objects.exists())

        LoginTransaction.objects.all().delete()
        callback_url = self._authorize(self._start_login())
        provider_mismatch_url = "%s?%s" % (
            reverse(
                "accounts:external_callback",
                args=[IdentityProvider.FEISHU],
            ),
            urlparse(callback_url).query,
        )
        response = self.client.get(provider_mismatch_url)
        self.assertEqual(response.status_code, 400)
        self.assertFalse(ExternalIdentity.objects.exists())

        LoginTransaction.objects.all().delete()
        callback_url = self._authorize(self._start_login())
        login_transaction = LoginTransaction.objects.get()
        login_transaction.redirect_uri = "https://invalid.example/callback"
        login_transaction.save(update_fields=["redirect_uri"])
        response = self.client.get(callback_url)
        self.assertEqual(response.status_code, 400)
        self.assertFalse(ExternalIdentity.objects.exists())

    def test_inactive_user_cannot_finish_bind_or_external_login(self):
        self.client.force_login(self.user)
        bind_response = self._start_bind()
        callback_url = self._authorize(bind_response["Location"])
        self.user.is_active = False
        self.user.save(update_fields=["is_active"])

        response = self.client.get(callback_url)
        self.assertEqual(response.status_code, 403)
        self.assertFalse(ExternalIdentity.objects.exists())

        self.user.is_active = True
        self.user.save(update_fields=["is_active"])
        ExternalIdentity.objects.create(
            provider=IdentityProvider.FAKE,
            subject=FAKE_IDENTITIES["demo-viewer"]["subject"],
            user=self.user,
        )
        self.client.logout()
        callback_url = self._authorize(self._start_login())
        self.user.is_active = False
        self.user.save(update_fields=["is_active"])

        response = self.client.get(callback_url)
        self.assertEqual(response.status_code, 400)
        self.assertNotIn("_auth_user_id", self.client.session)
        login_transaction = LoginTransaction.objects.latest("created_at")
        self.assertEqual(login_transaction.status, LoginTransactionStatus.FAILED)
        self.assertEqual(
            login_transaction.failure_code,
            "identity_user_inactive",
        )

    def test_provider_exception_text_is_not_persisted(self):
        class LeakyProvider:
            def complete_callback(self, request, **kwargs):
                raise ProviderCallbackError(
                    "access_token_secret_response_body"
                )

        callback_url = self._authorize(self._start_login())
        with patch("accounts.identity.get_provider", return_value=LeakyProvider()):
            response = self.client.get(callback_url)

        self.assertEqual(response.status_code, 400)
        login_transaction = LoginTransaction.objects.get()
        self.assertEqual(
            login_transaction.failure_code,
            "provider_callback_failed",
        )
        audit = AuthorizationAuditEvent.objects.get(
            event_type=AuditEventType.LOGIN_FAILED,
            login_transaction=login_transaction,
        )
        self.assertEqual(audit.reason_code, "provider_callback_failed")
        serialized = "%s %s" % (
            login_transaction.failure_code,
            audit.reason_code,
        )
        self.assertNotIn("access_token", serialized)
        self.assertNotIn("response_body", serialized)

    def test_unavailable_identity_does_not_count_as_login_method(self):
        identity = self._bind_viewer_identity()
        ExternalIdentity.objects.create(
            provider=IdentityProvider.FEISHU,
            subject="unavailable-feishu-subject",
            user=self.user,
        )
        self.user.set_unusable_password()
        self.user.save(update_fields=["password"])
        self.client.force_login(self.user)

        response = self.client.post(
            reverse("accounts:external_identity_unbind", args=[identity.pk])
        )

        self.assertRedirects(response, reverse("accounts:external_identities"))
        identity.refresh_from_db()
        self.assertEqual(identity.user_id, self.user.pk)
        self.assertTrue(
            AuthorizationAuditEvent.objects.filter(
                event_type=AuditEventType.IDENTITY_UNBOUND,
                outcome=AuditOutcome.DENIED,
                reason_code="last_login_method",
            ).exists()
        )

    def test_identity_endpoints_enforce_http_methods(self):
        self.assertEqual(
            self.client.get(
                reverse("accounts:external_start", args=[IdentityProvider.FAKE])
            ).status_code,
            405,
        )
        self.assertEqual(
            self.client.post(
                reverse("accounts:external_callback", args=[IdentityProvider.FAKE])
            ).status_code,
            405,
        )
        self.client.force_login(self.user)
        identity = ExternalIdentity.objects.create(
            provider=IdentityProvider.FAKE,
            subject="method-check-subject",
            user=self.user,
        )
        self.assertEqual(
            self.client.get(
                reverse(
                    "accounts:external_identity_unbind",
                    args=[identity.pk],
                )
            ).status_code,
            405,
        )

    def test_external_identity_posts_require_csrf(self):
        csrf_client = Client(enforce_csrf_checks=True)
        self.assertEqual(
            csrf_client.post(
                reverse("accounts:external_start", args=[IdentityProvider.FAKE]),
                {"identity": "demo-viewer"},
            ).status_code,
            403,
        )
        csrf_client.force_login(self.user)
        identity = ExternalIdentity.objects.create(
            provider=IdentityProvider.FAKE,
            subject="csrf-subject",
            user=self.user,
        )
        self.assertEqual(
            csrf_client.post(
                reverse("accounts:external_bind_start", args=[IdentityProvider.FAKE]),
                {"identity": "demo-viewer", "password": PASSWORD},
            ).status_code,
            403,
        )
        self.assertEqual(
            csrf_client.post(
                reverse("accounts:external_identity_unbind", args=[identity.pk])
            ).status_code,
            403,
        )

        csrf_client.get(
            reverse("accounts:external_bind_start", args=[IdentityProvider.FAKE])
        )
        csrf_token = csrf_client.cookies["csrftoken"].value
        start_response = csrf_client.post(
            reverse("accounts:external_bind_start", args=[IdentityProvider.FAKE]),
            {"identity": "demo-viewer", "password": PASSWORD},
            HTTP_X_CSRFTOKEN=csrf_token,
        )
        self.assertEqual(start_response.status_code, 302)
        authorization_response = csrf_client.get(start_response["Location"])
        form = authorization_response.context["form"]
        authorization_data = {
            "identity": form["identity"].value(),
            "redirect_uri": form["redirect_uri"].value(),
            "state": form["state"].value(),
            "code_challenge": form["code_challenge"].value(),
            "nonce": form["nonce"].value(),
            "transaction_id": form["transaction_id"].value(),
            "decision": "approve",
        }
        self.assertEqual(
            csrf_client.post(
                reverse("accounts:fake_authorize"),
                authorization_data,
            ).status_code,
            403,
        )

    def test_identity_admin_models_are_registered_and_read_only(self):
        request = type("Request", (), {"user": User.objects.create_superuser(
            username="identity-admin",
            password=PASSWORD,
        )})()
        model_admins = (
            ExternalIdentityAdmin(ExternalIdentity, admin.site),
            LoginTransactionAdmin(LoginTransaction, admin.site),
            AuthorizationAuditEventAdmin(AuthorizationAuditEvent, admin.site),
        )
        for model_admin in model_admins:
            self.assertTrue(model_admin.has_view_permission(request))
            self.assertFalse(model_admin.has_add_permission(request))
            self.assertFalse(model_admin.has_change_permission(request))
            self.assertFalse(model_admin.has_delete_permission(request))
