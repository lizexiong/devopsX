# accounts/models.py
import hashlib
import uuid

from django.contrib.auth.models import AbstractUser
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone

from .capabilities import ROLE_KEYS, ROLE_NAMES


class IdentityProvider(models.TextChoices):
    # fake 只用于本地学习和自动化测试；其余三项是后续真实平台适配器的稳定键。
    FAKE = "fake", "本地 Fake Provider"
    ENTERPRISE_WECHAT = "enterprise_wechat", "企业微信"
    FEISHU = "feishu", "飞书"
    WECHAT_OPEN_PLATFORM = "wechat_open_platform", "微信开放平台"


class LoginIntent(models.TextChoices):
    LOGIN = "login", "登录"
    BIND = "bind", "绑定"


class LoginTransactionStatus(models.TextChoices):
    PENDING = "pending", "等待回调"
    CONSUMED = "consumed", "已消费"
    SUCCEEDED = "succeeded", "成功"
    FAILED = "failed", "失败"


class AuditEventType(models.TextChoices):
    LOGIN_STARTED = "external_login.started", "外部登录开始"
    LOGIN_SUCCEEDED = "external_login.succeeded", "外部登录成功"
    LOGIN_FAILED = "external_login.failed", "外部登录失败"
    IDENTITY_BOUND = "external_identity.bound", "第三方身份绑定"
    IDENTITY_UNBOUND = "external_identity.unbound", "第三方身份解绑"


class AuditOutcome(models.TextChoices):
    SUCCESS = "success", "成功"
    DENIED = "denied", "拒绝"
    ERROR = "error", "错误"


class Department(models.Model):
    # 类型：CharField；用途：保存部门稳定编码；空值：不允许 NULL 或表单空值；删除：随部门记录一并删除。
    code = models.CharField("部门编码", max_length=50, unique=True)
    # 类型：CharField；用途：保存部门展示名称；空值：不允许 NULL 或表单空值；删除：随部门记录一并删除。
    name = models.CharField("部门名称", max_length=100)
    # 类型：自关联 ForeignKey；用途：指向上级部门；空值：允许 NULL 和表单空值表示根部门；删除：PROTECT 阻止删除仍有子部门的父部门。
    parent = models.ForeignKey(
        "self",
        verbose_name="上级部门",
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name="children",
    )
    # 类型：BooleanField；用途：标记部门是否可用；空值：不允许 NULL，默认 True；删除：随部门记录一并删除。
    is_active = models.BooleanField("启用", default=True)
    # 类型：PositiveIntegerField；用途：控制部门列表顺序；空值：不允许 NULL，默认 0；删除：随部门记录一并删除。
    sort_order = models.PositiveIntegerField("排序", default=0)
    # 类型：DateTimeField；用途：记录创建时间；空值：不允许 NULL，由数据库写入时自动生成；删除：随部门记录一并删除。
    created_at = models.DateTimeField("创建时间", auto_now_add=True)
    # 类型：DateTimeField；用途：记录最近更新时间；空值：不允许 NULL，每次保存时自动更新；删除：随部门记录一并删除。
    updated_at = models.DateTimeField("更新时间", auto_now=True)

    class Meta:
        ordering = ["sort_order", "code"]
        verbose_name = "部门"
        verbose_name_plural = "部门"

    def clean(self):
        # 输入：待校验的部门实例；输出：无返回值；调用者：ModelForm/full_clean；失败：父子自环或祖先环时抛出 ValidationError。
        super().clean()
        if not self.parent_id:
            return

        # 同一节点不能同时成为自己的父节点。
        if self.pk and self.parent_id == self.pk:
            raise ValidationError({"parent": "上级部门不能是当前部门。"})

        # 沿父链检查，避免保存后形成无法遍历的环。
        ancestor = self.parent
        visited = set()
        while ancestor is not None:
            if self.pk and ancestor.pk == self.pk:
                raise ValidationError({"parent": "上级部门不能是当前部门的后代。"})
            if ancestor.pk in visited:
                raise ValidationError({"parent": "部门层级中存在循环关系。"})
            visited.add(ancestor.pk)
            ancestor = ancestor.parent

    def __str__(self):
        # 输入：当前部门实例；输出：由编码和名称组成的字符串；调用者：后台、模板和日志；失败：字段缺失时按 Python 字符串规则显示。
        return "%s - %s" % (self.code, self.name)


class User(AbstractUser):
    # 类型：CharField；用途：保存用户姓名或业务展示名；空值：数据库不存 NULL，但允许空字符串；删除：随用户记录一并删除。
    display_name = models.CharField("姓名", max_length=100, blank=True)
    # 类型：CharField；用途：保存唯一工号；空值：允许 NULL 和表单空值，clean() 会把空字符串归一为 NULL；删除：随用户记录一并删除。
    employee_number = models.CharField(
        "工号",
        max_length=50,
        unique=True,
        null=True,
        blank=True,
    )
    # 类型：CharField；用途：保存手机号展示值；空值：数据库不存 NULL，但允许空字符串；删除：随用户记录一并删除。
    mobile = models.CharField("手机号", max_length=20, blank=True)
    # 类型：ForeignKey；用途：关联用户所属部门；空值：允许 NULL 和表单空值表示未分配部门；删除：PROTECT 阻止删除仍有用户的部门。
    department = models.ForeignKey(
        Department,
        verbose_name="部门",
        null=True,
        blank=True,
        on_delete=models.PROTECT,
        related_name="users",
    )
    # groups 与 user_permissions 由 AbstractUser 保留，仅用于 Django 兼容。
    # 类型：ManyToManyField；用途：经 UserRole 关联项目角色；空值：允许没有角色；删除：用户或角色删除时由中间模型的 CASCADE 删除关联行。
    roles = models.ManyToManyField(
        "Role",
        verbose_name="角色",
        through="UserRole",
        through_fields=("user", "role"),
        related_name="users",
        blank=True,
    )

    def clean(self):
        # 输入：待校验的用户实例；输出：无返回值；调用者：ModelForm/full_clean；失败：父类校验失败时抛出 ValidationError。
        super().clean()
        # 唯一字段把空字符串统一成 NULL，允许多个用户暂不填写工号。
        if not self.employee_number:
            self.employee_number = None

    def __str__(self):
        # 输入：当前用户实例；输出：优先使用姓名、否则使用用户名；调用者：后台、模板和日志；失败：字段为空时回退用户名。
        return self.display_name.strip() or self.username


class Capability(models.Model):
    # key 是代码中的稳定契约，名称可按业务需要调整。
    # 类型：CharField；用途：保存全局唯一的能力编码；空值：不允许 NULL 或表单空值；删除：随能力记录一并删除。
    key = models.CharField("能力编码", max_length=150, unique=True)
    # 类型：CharField；用途：保存能力展示名称；空值：不允许 NULL 或表单空值；删除：随能力记录一并删除。
    name = models.CharField("能力名称", max_length=100)
    # 类型：TextField；用途：保存能力说明；空值：数据库不存 NULL，但允许空字符串；删除：随能力记录一并删除。
    description = models.TextField("说明", blank=True)
    # 类型：BooleanField；用途：标记能力是否由代码目录维护；空值：不允许 NULL，默认 False；删除：随能力记录一并删除。
    is_system = models.BooleanField("系统内置", default=False)
    # 类型：BooleanField；用途：标记能力是否参与授权；空值：不允许 NULL，默认 True；删除：随能力记录一并删除。
    is_active = models.BooleanField("启用", default=True)
    # 类型：DateTimeField；用途：记录能力创建时间；空值：不允许 NULL，由创建时自动生成；删除：随能力记录一并删除。
    created_at = models.DateTimeField("创建时间", auto_now_add=True)
    # 类型：DateTimeField；用途：记录能力最近更新时间；空值：不允许 NULL，每次保存自动更新；删除：随能力记录一并删除。
    updated_at = models.DateTimeField("更新时间", auto_now=True)

    class Meta:
        ordering = ["key"]
        verbose_name = "能力"
        verbose_name_plural = "能力"

    def clean(self):
        # 输入：待校验的能力实例；输出：无返回值并规范化编码；调用者：ModelForm/full_clean；失败：父类字段校验失败时抛出 ValidationError。
        super().clean()
        self.key = self.key.strip().lower()

    def save(self, *args, **kwargs):
        # 输入：标准 Django save 参数；输出：父类 save 的结果；调用者：ORM 与业务写入；失败：数据库约束或写入异常向上抛出。
        # 数据库可能使用不区分大小写排序规则，先统一稳定编码。
        self.key = self.key.strip().lower()
        return super().save(*args, **kwargs)

    def __str__(self):
        # 输入：当前能力实例；输出：名称与编码组合文本；调用者：后台、模板和日志；失败：字段缺失时按 Python 字符串规则显示。
        return "%s（%s）" % (self.name, self.key)


class Role(models.Model):
    # key 供程序和初始化命令稳定引用，name 面向管理界面。
    # 类型：CharField；用途：保存全局唯一的角色编码；空值：不允许 NULL 或表单空值；删除：随角色记录一并删除。
    key = models.CharField("角色编码", max_length=100, unique=True)
    # 类型：CharField；用途：保存全局唯一的角色名称；空值：不允许 NULL 或表单空值；删除：随角色记录一并删除。
    name = models.CharField("角色名称", max_length=100, unique=True)
    # 类型：TextField；用途：保存角色说明；空值：数据库不存 NULL，但允许空字符串；删除：随角色记录一并删除。
    description = models.TextField("说明", blank=True)
    # 类型：BooleanField；用途：标记角色是否由代码目录维护；空值：不允许 NULL，默认 False；删除：随角色记录一并删除。
    is_system = models.BooleanField("系统内置", default=False)
    # 类型：BooleanField；用途：标记角色是否参与授权；空值：不允许 NULL，默认 True；删除：随角色记录一并删除。
    is_active = models.BooleanField("启用", default=True)
    # 类型：DateTimeField；用途：记录角色创建时间；空值：不允许 NULL，由创建时自动生成；删除：随角色记录一并删除。
    created_at = models.DateTimeField("创建时间", auto_now_add=True)
    # 类型：DateTimeField；用途：记录角色最近更新时间；空值：不允许 NULL，每次保存自动更新；删除：随角色记录一并删除。
    updated_at = models.DateTimeField("更新时间", auto_now=True)
    # 类型：ManyToManyField；用途：经 RoleCapability 关联能力；空值：允许角色没有能力；删除：角色或能力删除时由中间模型的 CASCADE 删除关联行。
    capabilities = models.ManyToManyField(
        Capability,
        verbose_name="能力",
        through="RoleCapability",
        related_name="roles",
        blank=True,
    )

    class Meta:
        ordering = ["name", "key"]
        verbose_name = "角色"
        verbose_name_plural = "角色"

    def clean(self):
        # 输入：待校验的角色实例；输出：无返回值并规范化编码；调用者：ModelForm/full_clean；失败：占用系统保留编码或名称时抛出 ValidationError。
        super().clean()
        self.key = self.key.strip().lower()
        # 内置编码和名称都只能属于 bootstrap 创建的系统角色。
        # 同时保护名称，是为了避免自定义角色占用中文名称后阻断目录修复。
        if self.key in ROLE_KEYS and not self.is_system:
            raise ValidationError({"key": "该角色编码由系统内置角色保留。"})
        if self.name.strip() in ROLE_NAMES and not self.is_system:
            raise ValidationError({"name": "该角色名称由系统内置角色保留。"})

    def save(self, *args, **kwargs):
        # 输入：标准 Django save 参数；输出：父类 save 的结果；调用者：ORM 与业务写入；失败：保留键冲突、校验或数据库错误向上抛出。
        # save() 不会自动调用 clean()，因此在模型边界再次拒绝保留编码和名称。
        self.key = self.key.strip().lower()
        self.name = self.name.strip()
        if self.key in ROLE_KEYS and not self.is_system:
            raise ValidationError("该角色编码由系统内置角色保留。")
        if self.name in ROLE_NAMES and not self.is_system:
            raise ValidationError("该角色名称由系统内置角色保留。")
        return super().save(*args, **kwargs)

    def __str__(self):
        # 输入：当前角色实例；输出：角色名称；调用者：后台、模板和日志；失败：名称缺失时按 Python 字符串规则显示。
        return self.name


class RoleCapability(models.Model):
    # 类型：ForeignKey；用途：指向被授予能力的角色；空值：不允许 NULL；删除：CASCADE 在角色删除时删除关联授权。
    role = models.ForeignKey(
        Role,
        verbose_name="角色",
        on_delete=models.CASCADE,
        related_name="role_capabilities",
    )
    # 类型：ForeignKey；用途：指向角色获得的能力；空值：不允许 NULL；删除：CASCADE 在能力删除时删除关联授权。
    capability = models.ForeignKey(
        Capability,
        verbose_name="能力",
        on_delete=models.CASCADE,
        related_name="role_capabilities",
    )
    # 删除操作人账号时保留授权记录本身，审计字段置空即可。
    # 类型：ForeignKey；用途：记录分配该角色能力的操作人；空值：允许 NULL 和表单空值；删除：SET_NULL 保留授权行并清空操作人。
    assigned_by = models.ForeignKey(
        User,
        verbose_name="分配人",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="assigned_role_capabilities",
    )
    # 类型：DateTimeField；用途：记录角色能力分配时间；空值：不允许 NULL，由创建时自动生成；删除：随关联授权记录一并删除。
    created_at = models.DateTimeField("分配时间", auto_now_add=True)

    class Meta:
        ordering = ["role_id", "capability_id"]
        constraints = [
            models.UniqueConstraint(
                fields=["role", "capability"],
                name="accounts_unique_role_capability",
            )
        ]
        verbose_name = "角色能力"
        verbose_name_plural = "角色能力"

    def __str__(self):
        # 输入：当前角色能力关联；输出：角色与能力编码组合文本；调用者：后台、模板和日志；失败：关联对象缺失时由 ORM 抛出异常。
        return "%s：%s" % (self.role, self.capability.key)


class UserRole(models.Model):
    # 类型：ForeignKey；用途：指向被分配角色的用户；空值：不允许 NULL；删除：CASCADE 在用户删除时删除关联行。
    user = models.ForeignKey(
        User,
        verbose_name="用户",
        on_delete=models.CASCADE,
        related_name="user_roles",
    )
    # 类型：ForeignKey；用途：指向分配给用户的角色；空值：不允许 NULL；删除：CASCADE 在角色删除时删除关联行。
    role = models.ForeignKey(
        Role,
        verbose_name="角色",
        on_delete=models.CASCADE,
        related_name="user_roles",
    )
    # 删除操作人账号不能连带删除目标用户的角色。
    # 类型：ForeignKey；用途：记录角色分配操作人；空值：允许 NULL 和表单空值；删除：SET_NULL 保留用户角色并清空操作人。
    assigned_by = models.ForeignKey(
        User,
        verbose_name="分配人",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="assigned_user_roles",
    )
    # 类型：DateTimeField；用途：记录用户角色分配时间；空值：不允许 NULL，由创建时自动生成；删除：随关联记录一并删除。
    created_at = models.DateTimeField("分配时间", auto_now_add=True)

    class Meta:
        ordering = ["user_id", "role_id"]
        constraints = [
            models.UniqueConstraint(
                fields=["user", "role"],
                name="accounts_unique_user_role",
            )
        ]
        verbose_name = "用户角色"
        verbose_name_plural = "用户角色"

    def __str__(self):
        # 输入：当前用户角色关联；输出：用户与角色组合文本；调用者：后台、模板和日志；失败：关联对象缺失时由 ORM 抛出异常。
        return "%s：%s" % (self.user, self.role)


def external_subject_digest(subject):
    # 输入：第三方原始 subject 字符串；输出：64 位 SHA-256 十六进制摘要；调用者：身份保存和查找流程；失败：非字符串输入会抛出编码异常。
    return hashlib.sha256(subject.encode("utf-8")).hexdigest()


class ExternalIdentity(models.Model):
    # provider 是项目内部注册表键，不直接使用第三方显示名称。
    # 类型：CharField；用途：保存身份提供方稳定键；空值：不允许 NULL 或表单空值；删除：随第三方身份记录一并删除。
    provider = models.CharField(
        "身份提供方",
        max_length=50,
        choices=IdentityProvider.choices,
    )
    # subject 是平台返回的稳定身份编号，不能用邮箱代替，也不能随意改大小写。
    # 类型：CharField；用途：保存第三方返回的不透明稳定身份编号；空值：不允许 NULL、空串或首尾空格；删除：随第三方身份记录一并删除。
    subject = models.CharField("平台身份编号", max_length=255)
    # 类型：CharField；用途：保存 subject 的 SHA-256 摘要供索引和唯一约束使用；空值：不允许 NULL，由 save() 自动计算；删除：随第三方身份记录一并删除。
    subject_digest = models.CharField(
        "平台身份编号摘要",
        max_length=64,
        editable=False,
    )
    # 类型：ForeignKey；用途：关联当前绑定的本地用户；空值：允许 NULL 和表单空值表示尚未绑定；删除：SET_NULL 保留历史身份并清空用户关系。
    user = models.ForeignKey(
        User,
        verbose_name="本地用户",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="external_identities",
    )
    # 这些字段只用于页面展示，不作为账号合并或授权依据。
    # 类型：CharField；用途：缓存平台展示名称；空值：数据库不存 NULL，但允许空字符串；删除：随第三方身份记录一并删除。
    display_name = models.CharField("平台显示名称", max_length=100, blank=True)
    # 类型：EmailField；用途：缓存平台邮箱用于展示；空值：数据库不存 NULL，但允许空字符串；删除：随第三方身份记录一并删除。
    email = models.EmailField("平台邮箱", blank=True)
    # 类型：DateTimeField；用途：记录身份首次出现时间；空值：不允许 NULL，由创建时自动生成；删除：随第三方身份记录一并删除。
    first_seen_at = models.DateTimeField("首次发现时间", auto_now_add=True)
    # 类型：DateTimeField；用途：记录身份最近使用或更新的时间；空值：不允许 NULL，每次保存自动更新；删除：随第三方身份记录一并删除。
    last_seen_at = models.DateTimeField("最近使用时间", auto_now=True)

    class Meta:
        ordering = ["provider", "subject"]
        constraints = [
            models.UniqueConstraint(
                fields=["provider", "subject_digest"],
                name="accounts_unique_identity_digest",
            )
        ]
        indexes = [
            models.Index(
                fields=["provider", "subject_digest"],
                name="accounts_ext_identity_digest",
            ),
            models.Index(
                fields=["user", "provider"],
                name="accounts_ext_identity_user",
            ),
        ]
        verbose_name = "第三方身份"
        verbose_name_plural = "第三方身份"

    def clean(self):
        # 输入：待校验的第三方身份；输出：无返回值并规范化 provider；调用者：ModelForm/full_clean；失败：未知 provider 或非法 subject 时抛出 ValidationError。
        super().clean()
        self.provider = self.provider.strip().lower()
        if self.provider not in IdentityProvider.values:
            raise ValidationError({"provider": "不支持该身份提供方。"})
        if not self.subject or not self.subject.strip():
            raise ValidationError({"subject": "平台身份编号不能为空。"})
        if self.subject != self.subject.strip():
            raise ValidationError({"subject": "平台身份编号不能包含首尾空格。"})

    def save(self, *args, **kwargs):
        # 输入：标准 Django save 参数；输出：父类 save 的结果；调用者：身份服务和 ORM；失败：provider/subject 校验、唯一键竞争或数据库错误向上抛出。
        # provider 是项目自己的注册表键，可以统一成小写。
        # subject 是第三方平台的不透明值，不能改大小写，也不能擅自替换字符。
        self.provider = self.provider.strip().lower()
        if self.provider not in IdentityProvider.values:
            raise ValidationError("不支持该身份提供方。")
        if not self.subject or self.subject != self.subject.strip():
            raise ValidationError("平台身份编号不能为空，也不能包含首尾空格。")
        self.subject_digest = external_subject_digest(self.subject)
        update_fields = kwargs.get("update_fields")
        if update_fields is not None and "subject" in update_fields:
            kwargs["update_fields"] = set(update_fields) | {"subject_digest"}
        return super().save(*args, **kwargs)

    def __str__(self):
        # 输入：当前第三方身份；输出：provider 与原始 subject 组合文本；调用者：后台、模板和日志；失败：字段缺失时按 Python 字符串规则显示。
        return "%s：%s" % (self.provider, self.subject)


class LoginTransaction(models.Model):
    # 外部回调使用这个不可预测编号定位一次登录事务。
    # 类型：UUIDField；用途：作为外部流程公开的一次事务编号；空值：不允许 NULL，由 uuid4 自动生成；删除：随登录事务记录一并删除。
    transaction_id = models.UUIDField(
        "事务编号",
        default=uuid.uuid4,
        unique=True,
        editable=False,
    )
    # 类型：CharField；用途：保存本次事务的身份提供方键；空值：不允许 NULL 或表单空值；删除：随登录事务记录一并删除。
    provider = models.CharField(
        "身份提供方",
        max_length=50,
        choices=IdentityProvider.choices,
    )
    # 类型：CharField；用途：区分登录或绑定目的；空值：不允许 NULL 或表单空值；删除：随登录事务记录一并删除。
    intent = models.CharField(
        "事务目的",
        max_length=20,
        choices=LoginIntent.choices,
    )
    # 数据库只保存摘要；原始 state、verifier 和 nonce 只在当前 Session 短暂保存。
    # 类型：CharField；用途：保存 state 的 HMAC 摘要并唯一定位请求；空值：不允许 NULL 或空值；删除：随登录事务记录一并删除。
    state_digest = models.CharField("state 摘要", max_length=64, unique=True)
    # 类型：CharField；用途：保存发起流程的 Session key 摘要；空值：不允许 NULL 或空值；删除：随登录事务记录一并删除。
    session_binding = models.CharField("Session 绑定摘要", max_length=64)
    # 类型：CharField；用途：固定授权时使用的服务端回调地址；空值：不允许 NULL 或空值；删除：随登录事务记录一并删除。
    redirect_uri = models.CharField("固定回调地址", max_length=500)
    # 类型：CharField；用途：保存 PKCE verifier 对应的 S256 challenge；空值：不允许 NULL 或空值；删除：随登录事务记录一并删除。
    code_challenge = models.CharField("PKCE challenge", max_length=128)
    # 类型：CharField；用途：保存 OIDC nonce 的 HMAC 摘要；空值：数据库不存 NULL，但允许空字符串；删除：随登录事务记录一并删除。
    nonce_digest = models.CharField("nonce 摘要", max_length=64, blank=True)
    # 类型：ForeignKey；用途：绑定事务发起用户以防登录 Session 被换人；空值：允许 NULL 和表单空值，普通登录没有发起用户；删除：SET_NULL 保留事务审计并清空用户。
    initiating_user = models.ForeignKey(
        User,
        verbose_name="发起用户",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="initiated_login_transactions",
    )
    # 类型：CharField；用途：记录事务等待、消费、成功或失败状态；空值：不允许 NULL，默认 pending；删除：随登录事务记录一并删除。
    status = models.CharField(
        "状态",
        max_length=20,
        choices=LoginTransactionStatus.choices,
        default=LoginTransactionStatus.PENDING,
    )
    # 类型：CharField；用途：保存可审计但不泄密的内部失败代码；空值：数据库不存 NULL，但允许空字符串；删除：随登录事务记录一并删除。
    failure_code = models.CharField("内部失败代码", max_length=100, blank=True)
    # 类型：DateTimeField；用途：定义 state 与事务失效时间；空值：不允许 NULL；删除：随登录事务记录一并删除。
    expires_at = models.DateTimeField("过期时间")
    # 类型：DateTimeField；用途：记录首次消费回调的时间以识别重放；空值：允许 NULL 和表单空值表示尚未消费；删除：随登录事务记录一并删除。
    consumed_at = models.DateTimeField("消费时间", null=True, blank=True)
    # 类型：DateTimeField；用途：记录事务创建时间；空值：不允许 NULL，由创建时自动生成；删除：随登录事务记录一并删除。
    created_at = models.DateTimeField("创建时间", auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(
                fields=["provider", "state_digest"],
                name="accounts_login_tx_lookup",
            ),
            models.Index(
                fields=["expires_at", "consumed_at"],
                name="accounts_login_tx_expiry",
            ),
        ]
        verbose_name = "外部登录事务"
        verbose_name_plural = "外部登录事务"

    def has_expired(self):
        # 输入：当前登录事务；输出：当前时间是否达到过期时间的布尔值；调用者：回调消费服务；失败：时间字段非法时抛出比较异常。
        return timezone.now() >= self.expires_at

    def __str__(self):
        # 输入：当前登录事务；输出：provider 与事务 UUID 组合文本；调用者：后台和日志；失败：字段缺失时按 Python 字符串规则显示。
        return "%s：%s" % (self.provider, self.transaction_id)


class AuthorizationAuditEvent(models.Model):
    # 审计事件使用固定枚举，避免把任意异常文本变成日志字段。
    # 类型：CharField；用途：保存固定审计事件类型；空值：不允许 NULL 或空值；删除：随审计记录一并删除。
    event_type = models.CharField(
        "事件类型",
        max_length=80,
        choices=AuditEventType.choices,
    )
    # 类型：CharField；用途：保存成功、拒绝或错误结果；空值：不允许 NULL 或空值；删除：随审计记录一并删除。
    outcome = models.CharField(
        "结果",
        max_length=20,
        choices=AuditOutcome.choices,
    )
    # 类型：ForeignKey；用途：关联执行操作的用户；空值：允许 NULL 和表单空值；删除：SET_NULL 保留审计记录并清空操作用户。
    actor = models.ForeignKey(
        User,
        verbose_name="操作用户",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="authorization_audit_events",
    )
    # 类型：ForeignKey；用途：关联被操作或登录的目标用户；空值：允许 NULL 和表单空值；删除：SET_NULL 保留审计记录并清空目标用户。
    target_user = models.ForeignKey(
        User,
        verbose_name="目标用户",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="targeted_authorization_audit_events",
    )
    # 类型：ForeignKey；用途：关联本次事件涉及的第三方身份；空值：允许 NULL 和表单空值；删除：SET_NULL 保留审计记录并清空身份引用。
    external_identity = models.ForeignKey(
        ExternalIdentity,
        verbose_name="第三方身份",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="authorization_audit_events",
    )
    # 类型：ForeignKey；用途：关联本次事件对应的登录事务；空值：允许 NULL 和表单空值；删除：SET_NULL 保留审计记录并清空事务引用。
    login_transaction = models.ForeignKey(
        LoginTransaction,
        verbose_name="登录事务",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="authorization_audit_events",
    )
    # 类型：CharField；用途：冗余保存提供方键便于审计检索；空值：数据库不存 NULL，但允许空字符串；删除：随审计记录一并删除。
    provider = models.CharField("身份提供方", max_length=50, blank=True)
    # 类型：CharField；用途：保存固定且不含秘密的失败原因代码；空值：数据库不存 NULL，但允许空字符串；删除：随审计记录一并删除。
    reason_code = models.CharField("原因代码", max_length=100, blank=True)
    # 只允许服务层写入筛选后的非秘密结构化信息。
    # 类型：JSONField；用途：保存非秘密结构化审计详情；空值：不使用 NULL，允许空字典；删除：随审计记录一并删除。
    detail = models.JSONField("安全详情", default=dict, blank=True)
    # 类型：DateTimeField；用途：记录审计事件发生时间；空值：不允许 NULL，由创建时自动生成；删除：随审计记录一并删除。
    created_at = models.DateTimeField("发生时间", auto_now_add=True)

    class Meta:
        ordering = ["-created_at", "-pk"]
        indexes = [
            models.Index(
                fields=["event_type", "created_at"],
                name="accounts_audit_event_time",
            ),
            models.Index(
                fields=["actor", "created_at"],
                name="accounts_audit_actor_time",
            ),
        ]
        verbose_name = "授权审计事件"
        verbose_name_plural = "授权审计事件"

    def __str__(self):
        # 输入：当前授权审计事件；输出：事件类型与结果组合文本；调用者：后台和日志；失败：字段缺失时按 Python 字符串规则显示。
        return "%s：%s" % (self.event_type, self.outcome)
