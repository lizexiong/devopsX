# accounts/tests.py
from io import StringIO
from pathlib import Path
from unittest.mock import patch

from django.conf import settings
from django.contrib import admin
from django.contrib.auth.models import AnonymousUser, Group, Permission
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.management import call_command
from django.core.management.base import CommandError
from django.db import IntegrityError, models, transaction
from django.db.models.deletion import ProtectedError
from django.http import HttpResponse
from django.test import Client, RequestFactory, TestCase
from django.urls import reverse

from . import views
from .admin import CustomUserAdmin
from .capabilities import (
    CAPABILITY_CATALOG,
    CAPABILITY_VIEW,
    DASHBOARD_VIEW,
    DEPARTMENT_MANAGE,
    DEPARTMENT_VIEW,
    ROLE_MANAGE,
    ROLE_VIEW,
    USER_ASSIGN_ROLE,
    USER_CHANGE,
    USER_CREATE,
    USER_DELETE,
    USER_STATUS,
    USER_VIEW,
)
from .decorators import (
    all_capabilities_required,
    any_capability_required,
    capability_required,
)
from .forms import RoleForm, UserAccessForm, UserCreateForm, UserUpdateForm
from .models import Capability, Department, Role, RoleCapability, User, UserRole
from .policy import (
    PolicySnapshot,
    has_all_capabilities,
    has_any_capability,
    has_capability,
    policy_snapshot,
    require_all_capabilities,
    require_any_capability,
    require_capability,
)


PASSWORD = "StrongPass!2468"
NEW_PASSWORD = "NewStrongPass!8642"

EXPECTED_ROLE_CAPABILITIES = {
    "platform_admin": {
        DASHBOARD_VIEW,
        USER_VIEW,
        USER_CREATE,
        USER_CHANGE,
        USER_DELETE,
        USER_STATUS,
        USER_ASSIGN_ROLE,
        DEPARTMENT_VIEW,
        DEPARTMENT_MANAGE,
        ROLE_VIEW,
        ROLE_MANAGE,
        CAPABILITY_VIEW,
    },
    "user_manager": {
        DASHBOARD_VIEW,
        USER_VIEW,
        USER_CREATE,
        USER_CHANGE,
        USER_DELETE,
        USER_STATUS,
        USER_ASSIGN_ROLE,
        DEPARTMENT_VIEW,
        ROLE_VIEW,
        CAPABILITY_VIEW,
    },
    "permission_manager": {
        DASHBOARD_VIEW,
        USER_VIEW,
        USER_ASSIGN_ROLE,
        DEPARTMENT_VIEW,
        ROLE_VIEW,
        ROLE_MANAGE,
        CAPABILITY_VIEW,
    },
    "readonly_viewer": {
        DASHBOARD_VIEW,
        USER_VIEW,
        DEPARTMENT_VIEW,
        ROLE_VIEW,
        CAPABILITY_VIEW,
    },
}


def ensure_capability(key, active=True):
    capability, _ = Capability.objects.get_or_create(
        key=key,
        defaults={
            "name": key,
            "description": "测试能力",
            "is_active": active,
        },
    )
    if capability.is_active != active:
        capability.is_active = active
        capability.save(update_fields=["is_active"])
    return capability


def create_role(key, capability_keys=(), name=None, active=True, system=False):
    role = Role.objects.create(
        key=key,
        name=name or key,
        is_active=active,
        is_system=system,
    )
    for capability_key in capability_keys:
        RoleCapability.objects.create(
            role=role,
            capability=ensure_capability(capability_key),
        )
    return role


def grant_capabilities(user, *capability_keys, role_key=None):
    key = role_key or "test_role_%s" % user.username
    role, _ = Role.objects.get_or_create(key=key, defaults={"name": key})
    for capability_key in capability_keys:
        RoleCapability.objects.get_or_create(
            role=role,
            capability=ensure_capability(capability_key),
        )
    UserRole.objects.get_or_create(user=user, role=role)
    return role


class ModelTests(TestCase):
    def test_department_fields_string_and_protection(self):
        department = Department.objects.create(code="OPS", name="运维部", sort_order=10)
        self.assertEqual(str(department), "OPS - 运维部")
        self.assertTrue(Department._meta.get_field("code").unique)
        self.assertIs(Department._meta.get_field("parent").remote_field.on_delete, models.PROTECT)

        Department.objects.create(code="CHILD", name="子部门", parent=department)
        with self.assertRaises(ProtectedError):
            department.delete()

    def test_department_rejects_direct_and_indirect_cycles(self):
        root = Department.objects.create(code="ROOT", name="根部门")
        child = Department.objects.create(code="CHILD", name="子部门", parent=root)
        root.parent = root
        with self.assertRaises(ValidationError):
            root.full_clean()

        root.parent = child
        with self.assertRaises(ValidationError):
            root.full_clean()

    def test_user_keeps_auth_compatibility_but_has_custom_roles(self):
        user = User.objects.create_user(
            username="alice",
            password=PASSWORD,
            display_name="张三",
            employee_number="E001",
        )
        self.assertEqual(str(user), "张三")
        self.assertTrue(user.check_password(PASSWORD))
        self.assertIsNotNone(User._meta.get_field("groups"))
        self.assertIsNotNone(User._meta.get_field("user_permissions"))
        self.assertIsNotNone(User._meta.get_field("roles"))
        self.assertEqual(User._meta.permissions, [])

    def test_user_empty_employee_number_normalizes_to_none(self):
        user = User(username="empty-number", employee_number="")
        user.full_clean(exclude=["password"])
        self.assertIsNone(user.employee_number)

    def test_keys_are_normalized_and_reserved_aliases_are_rejected(self):
        capability = Capability.objects.create(
            key=" Accounts.Custom.View ",
            name="测试能力",
        )
        role = Role.objects.create(key=" Custom_Role ", name="测试角色")
        self.assertEqual(capability.key, "accounts.custom.view")
        self.assertEqual(role.key, "custom_role")
        with self.assertRaises(ValidationError):
            Role.objects.create(key=" PLATFORM_ADMIN ", name="伪平台角色")

    def test_custom_rbac_models_enforce_unique_pairs(self):
        operator = User.objects.create_user(username="operator", password=PASSWORD)
        member = User.objects.create_user(username="member", password=PASSWORD)
        capability = ensure_capability(USER_VIEW)
        role = create_role("viewer")
        RoleCapability.objects.create(
            role=role,
            capability=capability,
            assigned_by=operator,
        )
        UserRole.objects.create(user=member, role=role, assigned_by=operator)

        with self.assertRaises(IntegrityError), transaction.atomic():
            RoleCapability.objects.create(role=role, capability=capability)
        with self.assertRaises(IntegrityError), transaction.atomic():
            UserRole.objects.create(user=member, role=role)

    def test_deleting_assigner_preserves_assignments(self):
        operator = User.objects.create_user(username="assigner", password=PASSWORD)
        member = User.objects.create_user(username="member", password=PASSWORD)
        role = create_role("assigned-role", (USER_VIEW,))
        role_link = RoleCapability.objects.get(role=role)
        role_link.assigned_by = operator
        role_link.save(update_fields=["assigned_by"])
        user_link = UserRole.objects.create(user=member, role=role, assigned_by=operator)

        operator.delete()
        role_link.refresh_from_db()
        user_link.refresh_from_db()
        self.assertIsNone(role_link.assigned_by)
        self.assertIsNone(user_link.assigned_by)


class PolicyTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="policy-user", password=PASSWORD)

    def test_policy_reads_only_active_custom_chain(self):
        active_role = create_role("active-role", (USER_VIEW,))
        inactive_role = create_role("inactive-role", (USER_CHANGE,), active=False)
        inactive_capability_role = create_role("inactive-cap-role")
        inactive_capability = ensure_capability(USER_DELETE, active=False)
        RoleCapability.objects.create(
            role=inactive_capability_role,
            capability=inactive_capability,
        )
        UserRole.objects.create(user=self.user, role=active_role)
        UserRole.objects.create(user=self.user, role=inactive_role)
        UserRole.objects.create(user=self.user, role=inactive_capability_role)

        snapshot = PolicySnapshot(self.user)
        self.assertEqual(snapshot.capability_keys, frozenset({USER_VIEW}))
        self.assertTrue(snapshot.has_capability(USER_VIEW))
        self.assertFalse(snapshot.has_capability(USER_CHANGE))
        self.assertFalse(snapshot.has_capability(USER_DELETE))

    def test_policy_ignores_django_group_and_direct_permission(self):
        permission = Permission.objects.get(
            content_type__app_label="accounts",
            codename="view_user",
        )
        group = Group.objects.create(name="旧 Django 角色")
        group.permissions.add(permission)
        self.user.groups.add(group)
        self.user.user_permissions.add(permission)

        self.assertTrue(self.user.has_perm("accounts.view_user"))
        self.assertFalse(has_capability(self.user, USER_VIEW))

    def test_anonymous_and_inactive_users_have_no_capabilities(self):
        grant_capabilities(self.user, USER_VIEW)
        self.assertFalse(has_capability(AnonymousUser(), USER_VIEW))
        self.user.is_active = False
        self.user.save(update_fields=["is_active"])
        self.assertFalse(has_capability(self.user, USER_VIEW))

    def test_only_active_superuser_bypasses(self):
        superuser = User.objects.create_superuser(username="root", password=PASSWORD)
        self.assertTrue(has_capability(superuser, "accounts.unknown.capability"))
        superuser.is_active = False
        superuser.save(update_fields=["is_active"])
        self.assertFalse(has_capability(superuser, USER_VIEW))

    def test_any_all_and_require_helpers(self):
        grant_capabilities(self.user, USER_VIEW, DEPARTMENT_VIEW)
        self.assertTrue(has_any_capability(self.user, (USER_VIEW, ROLE_VIEW)))
        self.assertFalse(has_any_capability(self.user, (ROLE_VIEW, ROLE_MANAGE)))
        self.assertTrue(has_all_capabilities(self.user, (USER_VIEW, DEPARTMENT_VIEW)))
        self.assertFalse(has_all_capabilities(self.user, (USER_VIEW, USER_CHANGE)))
        self.assertFalse(has_all_capabilities(self.user, ()))
        require_capability(self.user, USER_VIEW)
        require_any_capability(self.user, (USER_CHANGE, USER_VIEW))
        require_all_capabilities(self.user, (USER_VIEW, DEPARTMENT_VIEW))
        with self.assertRaises(PermissionDenied):
            require_capability(self.user, USER_CHANGE)
        with self.assertRaises(PermissionDenied):
            require_any_capability(self.user, (USER_CHANGE, USER_DELETE))
        with self.assertRaises(PermissionDenied):
            require_all_capabilities(self.user, (USER_VIEW, USER_CHANGE))

    def test_snapshot_is_cached_only_inside_one_request(self):
        capability = ensure_capability(USER_VIEW)
        role = create_role("cache-role")
        RoleCapability.objects.create(role=role, capability=capability)
        UserRole.objects.create(user=self.user, role=role)
        factory = RequestFactory()
        request = factory.get("/")
        request.user = self.user

        first = policy_snapshot(request)
        self.assertIs(first, policy_snapshot(request))
        capability.is_active = False
        capability.save(update_fields=["is_active"])
        self.assertTrue(has_capability(request, USER_VIEW))

        next_request = factory.get("/")
        next_request.user = self.user
        self.assertIsNot(first, policy_snapshot(next_request))
        self.assertFalse(has_capability(next_request, USER_VIEW))


class DecoratorTests(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username="decorator-user", password=PASSWORD)

    @staticmethod
    def response_view(request):
        return HttpResponse("ok")

    def request_for(self, user):
        request = self.factory.get("/protected/")
        request.user = user
        return request

    def test_capability_decorator_redirects_anonymous_and_denies_member(self):
        decorated = capability_required(USER_VIEW)(self.response_view)
        anonymous_response = decorated(self.request_for(AnonymousUser()))
        self.assertEqual(anonymous_response.status_code, 302)
        with self.assertRaises(PermissionDenied):
            decorated(self.request_for(self.user))

        grant_capabilities(self.user, USER_VIEW)
        self.assertEqual(decorated(self.request_for(self.user)).status_code, 200)

    def test_any_and_all_decorators(self):
        grant_capabilities(self.user, USER_VIEW)
        any_view = any_capability_required((USER_VIEW, ROLE_VIEW))(self.response_view)
        all_view = all_capabilities_required((USER_VIEW, ROLE_VIEW))(self.response_view)
        self.assertEqual(any_view(self.request_for(self.user)).status_code, 200)
        with self.assertRaises(PermissionDenied):
            all_view(self.request_for(self.user))

        grant_capabilities(self.user, ROLE_VIEW)
        self.assertEqual(all_view(self.request_for(self.user)).status_code, 200)


class FormAndAdminTests(TestCase):
    def test_business_user_forms_hide_internal_auth_fields(self):
        create_fields = set(UserCreateForm().fields)
        update_fields = set(UserUpdateForm().fields)
        for field_name in (
            "first_name",
            "last_name",
            "is_superuser",
            "groups",
            "user_permissions",
            "roles",
        ):
            self.assertNotIn(field_name, create_fields)
            self.assertNotIn(field_name, update_fields)
        self.assertNotIn("password", update_fields)

    def test_access_form_offers_roles_only_and_enforces_subset(self):
        operator = User.objects.create_user(username="limited", password=PASSWORD)
        grant_capabilities(operator, USER_VIEW)
        allowed_role = create_role("allowed", (USER_VIEW,))
        forbidden_role = create_role("forbidden", (USER_CHANGE,))
        form = UserAccessForm(operator=operator)

        self.assertEqual(set(form.fields), {"roles"})
        self.assertIn(allowed_role, form.fields["roles"].queryset)
        self.assertNotIn(forbidden_role, form.fields["roles"].queryset)
        bound = UserAccessForm(
            {"roles": [forbidden_role.pk]},
            operator=operator,
            instance=User.objects.create_user(username="target", password=PASSWORD),
        )
        self.assertFalse(bound.is_valid())
        self.assertIn("roles", bound.errors)

    def test_inactive_capability_still_blocks_role_delegation(self):
        operator = User.objects.create_user(username="inactive-scope", password=PASSWORD)
        grant_capabilities(operator, USER_VIEW)
        capability = ensure_capability(USER_CHANGE, active=False)
        role = create_role("deferred-role", (USER_VIEW,))
        RoleCapability.objects.create(role=role, capability=capability)

        form = UserAccessForm(operator=operator)
        self.assertNotIn(role, form.fields["roles"].queryset)

    def test_role_form_offers_only_operator_capabilities(self):
        operator = User.objects.create_user(username="role-manager", password=PASSWORD)
        own_capability = ensure_capability(USER_VIEW)
        foreign_capability = ensure_capability(USER_CHANGE)
        grant_capabilities(operator, ROLE_MANAGE, USER_VIEW)
        form = RoleForm(operator=operator)
        self.assertEqual(
            set(form.fields["capabilities"].queryset),
            {ensure_capability(ROLE_MANAGE), own_capability},
        )
        self.assertNotIn(foreign_capability, form.fields["capabilities"].queryset)

    def test_system_role_key_is_disabled_and_reserved_key_cannot_be_created(self):
        operator = User.objects.create_superuser(username="admin", password=PASSWORD)
        system_role = Role.objects.get(key="platform_admin")
        edit_form = RoleForm(instance=system_role, operator=operator)
        self.assertTrue(edit_form.fields["key"].disabled)

        create_form = RoleForm(
            {
                "key": "readonly_viewer",
                "name": "伪造系统角色",
                "description": "",
                "is_active": "on",
                "capabilities": [],
            },
            operator=operator,
        )
        self.assertFalse(create_form.is_valid())
        self.assertIn("key", create_form.errors)

        reserved_name_form = RoleForm(
            {
                "key": "custom-platform-name",
                "name": "平台管理员",
                "description": "",
                "is_active": "on",
                "capabilities": [],
            },
            operator=operator,
        )
        self.assertFalse(reserved_name_form.is_valid())
        self.assertIn("name", reserved_name_form.errors)

        custom_role = create_role("custom-reserved-test", (USER_VIEW,))
        rename_form = RoleForm(
            {
                "key": "platform_admin",
                "name": custom_role.name,
                "description": "",
                "is_active": "on",
                "capabilities": [],
            },
            instance=custom_role,
            operator=operator,
        )
        self.assertFalse(rename_form.is_valid())
        self.assertIn("key", rename_form.errors)

    def test_custom_user_admin_does_not_expose_legacy_authorization_fields(self):
        user_admin = CustomUserAdmin(User, admin.site)
        fields = {
            field
            for _, options in user_admin.fieldsets
            for field in options.get("fields", ())
        }
        add_fields = {
            field
            for _, options in user_admin.add_fieldsets
            for field in options.get("fields", ())
        }
        for field_name in ("groups", "user_permissions"):
            self.assertNotIn(field_name, fields)
            self.assertNotIn(field_name, add_fields)
        self.assertTrue(admin.site.is_registered(Group))
        self.assertTrue(admin.site.is_registered(Capability))
        self.assertTrue(admin.site.is_registered(Role))
        self.assertTrue(admin.site.is_registered(RoleCapability))
        self.assertTrue(admin.site.is_registered(UserRole))

    def test_non_superuser_staff_cannot_access_custom_admin_models(self):
        staff = User.objects.create_user(
            username="staff",
            password=PASSWORD,
            is_staff=True,
        )
        self.client.force_login(staff)
        for url in (
            reverse("admin:accounts_user_changelist"),
            reverse("admin:accounts_capability_changelist"),
            reverse("admin:accounts_role_changelist"),
            reverse("admin:accounts_rolecapability_changelist"),
            reverse("admin:accounts_userrole_changelist"),
        ):
            with self.subTest(url=url):
                self.assertEqual(self.client.get(url).status_code, 403)


class AuthenticationTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="login-user", password=PASSWORD)
        grant_capabilities(self.user, DASHBOARD_VIEW)
        self.inactive = User.objects.create_user(
            username="inactive-user",
            password=PASSWORD,
            is_active=False,
        )

    def test_login_success_failure_and_inactive_rejection(self):
        response = self.client.post(
            reverse("accounts:login"),
            {"username": self.user.username, "password": PASSWORD},
        )
        self.assertRedirects(response, reverse("accounts:home"))
        self.client.logout()

        response = self.client.post(
            reverse("accounts:login"),
            {"username": self.user.username, "password": "wrong-password"},
        )
        self.assertEqual(response.status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)

        response = self.client.post(
            reverse("accounts:login"),
            {"username": self.inactive.username, "password": PASSWORD},
        )
        self.assertEqual(response.status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_custom_capability_controls_view_and_legacy_permission_does_not(self):
        url = reverse("accounts:user_list")
        response = self.client.get(url)
        self.assertRedirects(response, "%s?next=%s" % (reverse("accounts:login"), url))

        permission = Permission.objects.get(
            content_type__app_label="accounts",
            codename="view_user",
        )
        self.user.user_permissions.add(permission)
        self.client.force_login(self.user)
        response = self.client.get(url)
        self.assertEqual(response.status_code, 403)
        self.assertTemplateUsed(response, "403.html")

        grant_capabilities(self.user, USER_VIEW)
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_password_change_keeps_session(self):
        grant_capabilities(self.user, DASHBOARD_VIEW)
        self.client.force_login(self.user)
        response = self.client.post(
            reverse("accounts:password_change"),
            {
                "old_password": PASSWORD,
                "new_password1": NEW_PASSWORD,
                "new_password2": NEW_PASSWORD,
            },
        )
        self.assertRedirects(response, reverse("accounts:password_change_done"))
        self.user.refresh_from_db()
        self.assertTrue(self.user.check_password(NEW_PASSWORD))
        self.assertEqual(int(self.client.session["_auth_user_id"]), self.user.pk)
        self.assertEqual(self.client.get(reverse("accounts:home")).status_code, 200)

    def test_logout_is_post_only_and_post_ends_session(self):
        self.client.force_login(self.user)
        self.assertEqual(self.client.get(reverse("accounts:logout")).status_code, 405)
        response = self.client.post(reverse("accounts:logout"))
        self.assertRedirects(response, reverse("accounts:login"))
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_csrf_protects_sensitive_posts(self):
        operator = User.objects.create_superuser(username="csrf-admin", password=PASSWORD)
        target = User.objects.create_user(username="csrf-target", password=PASSWORD)
        csrf_client = Client(enforce_csrf_checks=True)
        csrf_client.force_login(operator)
        self.assertEqual(csrf_client.post(reverse("accounts:logout")).status_code, 403)
        self.assertEqual(
            csrf_client.post(reverse("accounts:user_status", args=[target.pk])).status_code,
            403,
        )
        self.assertEqual(
            csrf_client.post(
                reverse("accounts:user_access", args=[target.pk]),
                {"roles": []},
            ).status_code,
            403,
        )
        self.assertEqual(
            csrf_client.post(
                reverse("accounts:role_create"),
                {
                    "key": "csrf-role",
                    "name": "无 CSRF 角色",
                    "description": "",
                    "is_active": "on",
                    "capabilities": [],
                },
            ).status_code,
            403,
        )


class UserManagementTests(TestCase):
    def setUp(self):
        self.operator = User.objects.create_superuser(
            username="operator",
            password=PASSWORD,
            email="operator@example.com",
        )
        self.client.force_login(self.operator)

    def test_user_creation_hashes_password(self):
        response = self.client.post(
            reverse("accounts:user_create"),
            {
                "username": "created-user",
                "display_name": "新用户",
                "employee_number": "E100",
                "email": "created@example.com",
                "mobile": "13800000000",
                "department": "",
                "is_active": "on",
                "password1": PASSWORD,
                "password2": PASSWORD,
            },
        )
        created = User.objects.get(username="created-user")
        self.assertRedirects(response, reverse("accounts:user_detail", args=[created.pk]))
        self.assertNotEqual(created.password, PASSWORD)
        self.assertTrue(created.check_password(PASSWORD))

    def test_operator_cannot_change_own_status_roles_or_delete_self(self):
        status_response = self.client.post(
            reverse("accounts:user_status", args=[self.operator.pk])
        )
        self.assertRedirects(
            status_response,
            reverse("accounts:user_detail", args=[self.operator.pk]),
        )
        self.operator.refresh_from_db()
        self.assertTrue(self.operator.is_active)

        access_response = self.client.get(
            reverse("accounts:user_access", args=[self.operator.pk])
        )
        self.assertRedirects(
            access_response,
            reverse("accounts:user_detail", args=[self.operator.pk]),
        )
        self.client.post(reverse("accounts:user_delete", args=[self.operator.pk]))
        self.assertTrue(User.objects.filter(pk=self.operator.pk).exists())

    def test_user_manager_cannot_elevate_target_but_can_assign_subset(self):
        call_command("bootstrap_rbac", stdout=StringIO())
        manager = User.objects.create_user(username="user-manager", password=PASSWORD)
        target = User.objects.create_user(username="target", password=PASSWORD)
        manager_role = Role.objects.get(key="user_manager")
        platform_role = Role.objects.get(key="platform_admin")
        readonly_role = Role.objects.get(key="readonly_viewer")
        UserRole.objects.create(user=manager, role=manager_role)
        self.client.force_login(manager)

        forged = self.client.post(
            reverse("accounts:user_access", args=[target.pk]),
            {"roles": [platform_role.pk]},
        )
        self.assertEqual(forged.status_code, 200)
        self.assertIn("roles", forged.context["form"].errors)
        self.assertFalse(target.roles.exists())

        allowed = self.client.post(
            reverse("accounts:user_access", args=[target.pk]),
            {"roles": [readonly_role.pk]},
        )
        self.assertRedirects(
            allowed,
            reverse("accounts:user_detail", args=[target.pk]),
        )
        self.assertEqual(list(target.roles.all()), [readonly_role])

    def test_user_access_cannot_remove_role_outside_operator_scope(self):
        call_command("bootstrap_rbac", stdout=StringIO())
        manager = User.objects.create_user(username="limited-manager", password=PASSWORD)
        target = User.objects.create_user(username="high-target", password=PASSWORD)
        manager_role = Role.objects.get(key="user_manager")
        platform_role = Role.objects.get(key="platform_admin")
        readonly_role = Role.objects.get(key="readonly_viewer")
        UserRole.objects.create(user=manager, role=manager_role)
        UserRole.objects.create(user=target, role=platform_role)
        self.client.force_login(manager)

        response = self.client.post(
            reverse("accounts:user_access", args=[target.pk]),
            {"roles": [readonly_role.pk]},
        )
        self.assertEqual(response.status_code, 403)
        self.assertEqual(list(target.roles.all()), [platform_role])

    def test_user_access_rechecks_operator_capability_inside_transaction(self):
        call_command("bootstrap_rbac", stdout=StringIO())
        manager = User.objects.create_user(username="recheck-manager", password=PASSWORD)
        target = User.objects.create_user(username="recheck-target", password=PASSWORD)
        manager_role = Role.objects.get(key="user_manager")
        readonly_role = Role.objects.get(key="readonly_viewer")
        UserRole.objects.create(user=manager, role=manager_role)
        self.client.force_login(manager)
        original_lock = views._lock_role_catalog

        def revoke_after_catalog_lock():
            role_ids = original_lock()
            UserRole.objects.filter(user=manager, role=manager_role).delete()
            return role_ids

        with patch.object(
            views,
            "_lock_role_catalog",
            side_effect=revoke_after_catalog_lock,
        ):
            response = self.client.post(
                reverse("accounts:user_access", args=[target.pk]),
                {"roles": [readonly_role.pk]},
            )
        self.assertEqual(response.status_code, 403)
        self.assertFalse(target.roles.exists())
        self.assertTrue(UserRole.objects.filter(user=manager, role=manager_role).exists())

    def test_user_access_rechecks_assignable_roles_after_catalog_lock(self):
        call_command("bootstrap_rbac", stdout=StringIO())
        manager = User.objects.create_user(username="scope-manager", password=PASSWORD)
        target = User.objects.create_user(username="scope-target", password=PASSWORD)
        manager_role = Role.objects.get(key="user_manager")
        readonly_role = Role.objects.get(key="readonly_viewer")
        UserRole.objects.create(user=manager, role=manager_role)
        self.client.force_login(manager)
        original_lock = views._lock_role_catalog

        def expand_role_after_catalog_lock():
            role_ids = original_lock()
            RoleCapability.objects.create(
                role=readonly_role,
                capability=Capability.objects.get(key=DEPARTMENT_MANAGE),
            )
            return role_ids

        with patch.object(
            views,
            "_lock_role_catalog",
            side_effect=expand_role_after_catalog_lock,
        ):
            response = self.client.post(
                reverse("accounts:user_access", args=[target.pk]),
                {"roles": [readonly_role.pk]},
            )
        self.assertEqual(response.status_code, 200)
        self.assertIn("roles", response.context["form"].errors)
        self.assertFalse(target.roles.exists())

    def test_custom_access_writes_do_not_touch_legacy_assignments(self):
        target = User.objects.create_user(username="legacy-target", password=PASSWORD)
        role = create_role("custom-target-role", (USER_VIEW,))
        group = Group.objects.create(name="legacy-group")
        permission = Permission.objects.get(
            content_type__app_label="accounts",
            codename="view_user",
        )
        target.groups.add(group)
        target.user_permissions.add(permission)

        response = self.client.post(
            reverse("accounts:user_access", args=[target.pk]),
            {"roles": [role.pk]},
        )
        self.assertRedirects(response, reverse("accounts:user_detail", args=[target.pk]))
        self.assertEqual(list(target.roles.all()), [role])
        self.assertEqual(list(target.groups.all()), [group])
        self.assertEqual(list(target.user_permissions.all()), [permission])

    def test_non_superuser_cannot_manage_superuser(self):
        manager = User.objects.create_user(username="manager", password=PASSWORD)
        grant_capabilities(
            manager,
            USER_CHANGE,
            USER_ASSIGN_ROLE,
            USER_STATUS,
            USER_DELETE,
        )
        self.client.force_login(manager)
        protected_urls = (
            reverse("accounts:user_update", args=[self.operator.pk]),
            reverse("accounts:user_access", args=[self.operator.pk]),
            reverse("accounts:user_status", args=[self.operator.pk]),
            reverse("accounts:user_delete", args=[self.operator.pk]),
        )
        for url in protected_urls:
            with self.subTest(url=url):
                self.assertEqual(self.client.post(url).status_code, 403)
        self.assertTrue(User.objects.filter(pk=self.operator.pk, is_active=True).exists())

    def test_status_is_post_only(self):
        target = User.objects.create_user(username="status-target", password=PASSWORD)
        self.assertEqual(
            self.client.get(reverse("accounts:user_status", args=[target.pk])).status_code,
            405,
        )

    def test_user_list_filters_and_ignores_invalid_department_ids(self):
        department = Department.objects.create(code="OPS", name="运维部")
        User.objects.create_user(
            username="search-target",
            password=PASSWORD,
            display_name="目标用户",
            department=department,
            is_active=False,
        )
        response = self.client.get(
            reverse("accounts:user_list"),
            {"q": "目标", "department": department.pk, "status": "inactive"},
        )
        self.assertContains(response, "search-target")
        self.assertEqual(response.context["page_obj"].paginator.per_page, 10)

        for value in ("abc", "9" * 100, "9223372036854775808"):
            response = self.client.get(
                reverse("accounts:user_list"),
                {"department": value},
            )
            self.assertEqual(response.context["selected_department"], "")

    def test_status_delete_and_access_request_row_locks(self):
        status_target = User.objects.create_user(username="status-lock", password=PASSWORD)
        delete_target = User.objects.create_user(username="delete-lock", password=PASSWORD)
        access_target = User.objects.create_user(username="access-lock", password=PASSWORD)
        with patch.object(
            User.objects,
            "select_for_update",
            wraps=User.objects.select_for_update,
        ) as user_lock, patch.object(
            Role.objects,
            "select_for_update",
            wraps=Role.objects.select_for_update,
        ) as role_lock, patch.object(
            UserRole.objects,
            "select_for_update",
            wraps=UserRole.objects.select_for_update,
        ) as user_role_lock:
            self.client.post(reverse("accounts:user_status", args=[status_target.pk]))
            self.client.post(reverse("accounts:user_delete", args=[delete_target.pk]))
            self.client.post(
                reverse("accounts:user_access", args=[access_target.pk]),
                {"roles": []},
            )
        self.assertGreaterEqual(user_lock.call_count, 5)
        self.assertGreaterEqual(role_lock.call_count, 3)
        self.assertGreaterEqual(user_role_lock.call_count, 3)


class RoleAndDepartmentViewTests(TestCase):
    def setUp(self):
        self.operator = User.objects.create_superuser(username="admin", password=PASSWORD)
        self.client.force_login(self.operator)

    def test_role_assignment_takes_effect_in_custom_policy(self):
        role = create_role("user-viewer", (USER_VIEW,))
        member = User.objects.create_user(username="member", password=PASSWORD)
        UserRole.objects.create(user=member, role=role)
        self.assertTrue(has_capability(User.objects.get(pk=member.pk), USER_VIEW))
        self.assertFalse(User.objects.get(pk=member.pk).has_perm("accounts.view_user"))

    def test_role_update_replaces_capabilities_and_records_operator(self):
        role = create_role("editable", (USER_VIEW,), name="待编辑角色")
        new_capability = ensure_capability(USER_CHANGE)
        with patch.object(
            Role.objects,
            "select_for_update",
            wraps=Role.objects.select_for_update,
        ) as role_lock:
            response = self.client.post(
                reverse("accounts:role_update", args=[role.pk]),
                {
                    "key": "edited",
                    "name": "已编辑角色",
                    "description": "更新后",
                    "is_active": "on",
                    "capabilities": [new_capability.pk],
                },
            )
        self.assertRedirects(response, reverse("accounts:role_list"))
        self.assertGreaterEqual(role_lock.call_count, 1)
        role.refresh_from_db()
        self.assertEqual(role.key, "edited")
        self.assertEqual(set(role.capabilities.all()), {new_capability})
        self.assertEqual(RoleCapability.objects.get(role=role).assigned_by, self.operator)

    def test_permission_manager_cannot_create_or_manage_higher_role(self):
        call_command("bootstrap_rbac", stdout=StringIO())
        manager = User.objects.create_user(username="permission-manager", password=PASSWORD)
        manager_role = Role.objects.get(key="permission_manager")
        platform_role = Role.objects.get(key="platform_admin")
        readonly_role = Role.objects.get(key="readonly_viewer")
        UserRole.objects.create(user=manager, role=manager_role)
        self.client.force_login(manager)
        user_create = Capability.objects.get(key=USER_CREATE)
        user_view = Capability.objects.get(key=USER_VIEW)

        forged = self.client.post(
            reverse("accounts:role_create"),
            {
                "key": "forged-role",
                "name": "越权角色",
                "description": "",
                "is_active": "on",
                "capabilities": [user_create.pk],
            },
        )
        self.assertEqual(forged.status_code, 200)
        self.assertIn("capabilities", forged.context["form"].errors)
        self.assertFalse(Role.objects.filter(key="forged-role").exists())

        allowed = self.client.post(
            reverse("accounts:role_create"),
            {
                "key": "allowed-role",
                "name": "权限范围内角色",
                "description": "",
                "is_active": "on",
                "capabilities": [user_view.pk],
            },
        )
        self.assertRedirects(allowed, reverse("accounts:role_list"))
        self.assertEqual(
            self.client.get(
                reverse("accounts:role_update", args=[platform_role.pk])
            ).status_code,
            403,
        )
        self.assertEqual(
            self.client.get(
                reverse("accounts:role_update", args=[readonly_role.pk])
            ).status_code,
            403,
        )
        self.assertEqual(
            self.client.post(
                reverse("accounts:role_delete", args=[platform_role.pk])
            ).status_code,
            403,
        )

    def test_superuser_cannot_edit_bootstrap_owned_system_role(self):
        call_command("bootstrap_rbac", stdout=StringIO())
        readonly_role = Role.objects.get(key="readonly_viewer")

        response = self.client.get(
            reverse("accounts:role_update", args=[readonly_role.pk])
        )

        self.assertEqual(response.status_code, 403)

    def test_non_superuser_cannot_edit_or_delete_own_role(self):
        call_command("bootstrap_rbac", stdout=StringIO())
        manager = User.objects.create_user(username="own-role-manager", password=PASSWORD)
        manager_role = Role.objects.get(key="permission_manager")
        UserRole.objects.create(user=manager, role=manager_role)
        self.client.force_login(manager)

        self.assertEqual(
            self.client.get(
                reverse("accounts:role_update", args=[manager_role.pk])
            ).status_code,
            403,
        )
        self.assertEqual(
            self.client.post(
                reverse("accounts:role_delete", args=[manager_role.pk])
            ).status_code,
            403,
        )

    def test_role_create_rechecks_manage_capability_after_lock(self):
        call_command("bootstrap_rbac", stdout=StringIO())
        manager = User.objects.create_user(username="recheck-role-manager", password=PASSWORD)
        manager_role = Role.objects.get(key="permission_manager")
        UserRole.objects.create(user=manager, role=manager_role)
        self.client.force_login(manager)
        user_view = Capability.objects.get(key=USER_VIEW)
        original_lock = views._lock_role_catalog

        def revoke_after_lock():
            role_ids = original_lock()
            UserRole.objects.filter(user=manager, role=manager_role).delete()
            return role_ids

        with patch.object(views, "_lock_role_catalog", side_effect=revoke_after_lock):
            response = self.client.post(
                reverse("accounts:role_create"),
                {
                    "key": "revoked-create",
                    "name": "撤权后角色",
                    "description": "",
                    "is_active": "on",
                    "capabilities": [user_view.pk],
                },
            )
        self.assertEqual(response.status_code, 403)
        self.assertFalse(Role.objects.filter(key="revoked-create").exists())

    def test_assigned_system_and_custom_role_delete_rules(self):
        system_role = create_role("system-role", system=True)
        assigned_role = create_role("assigned-role")
        empty_role = create_role("empty-role")
        member = User.objects.create_user(username="member", password=PASSWORD)
        UserRole.objects.create(user=member, role=assigned_role)

        self.client.post(reverse("accounts:role_delete", args=[system_role.pk]))
        self.client.post(reverse("accounts:role_delete", args=[assigned_role.pk]))
        self.client.post(reverse("accounts:role_delete", args=[empty_role.pk]))
        self.assertTrue(Role.objects.filter(pk=system_role.pk).exists())
        self.assertTrue(Role.objects.filter(pk=assigned_role.pk).exists())
        self.assertFalse(Role.objects.filter(pk=empty_role.pk).exists())

    def test_role_crud_does_not_create_django_groups(self):
        initial_count = Group.objects.count()
        response = self.client.post(
            reverse("accounts:role_create"),
            {
                "key": "custom-only",
                "name": "仅项目角色",
                "description": "",
                "is_active": "on",
                "capabilities": [],
            },
        )
        self.assertRedirects(response, reverse("accounts:role_list"))
        self.assertEqual(Group.objects.count(), initial_count)
        self.assertTrue(Role.objects.filter(key="custom-only").exists())

    def test_department_cycle_and_delete_safety(self):
        root = Department.objects.create(code="ROOT", name="根部门")
        child = Department.objects.create(code="CHILD", name="子部门", parent=root)
        cycle_response = self.client.post(
            reverse("accounts:department_update", args=[root.pk]),
            {
                "code": root.code,
                "name": root.name,
                "parent": child.pk,
                "is_active": "on",
                "sort_order": 0,
            },
        )
        self.assertContains(cycle_response, "上级部门不能是当前部门的后代")
        self.client.post(reverse("accounts:department_delete", args=[root.pk]))
        self.assertTrue(Department.objects.filter(pk=root.pk).exists())

        leaf = Department.objects.create(code="LEAF", name="叶子部门")
        User.objects.create_user(username="department-user", password=PASSWORD, department=leaf)
        self.client.post(reverse("accounts:department_delete", args=[leaf.pk]))
        self.assertTrue(Department.objects.filter(pk=leaf.pk).exists())

    def test_capability_list_is_read_only_catalog(self):
        call_command("bootstrap_rbac", stdout=StringIO())
        response = self.client.get(
            reverse("accounts:permission_list"),
            {"app_label": "accounts", "q": "user.view"},
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, USER_VIEW)
        self.assertNotContains(response, ROLE_MANAGE)
        self.assertNotIn("permissions", response.context)
        self.assertIn("capabilities", response.context)


class BootstrapCommandTests(TestCase):
    def role_capability_keys(self, role_key):
        return set(
            RoleCapability.objects.filter(role__key=role_key).values_list(
                "capability__key", flat=True
            )
        )

    def test_bootstrap_is_idempotent_and_exact(self):
        output = StringIO()
        call_command("bootstrap_rbac", stdout=output)
        first = {
            key: self.role_capability_keys(key)
            for key in EXPECTED_ROLE_CAPABILITIES
        }
        call_command("bootstrap_rbac", stdout=output)
        second = {
            key: self.role_capability_keys(key)
            for key in EXPECTED_ROLE_CAPABILITIES
        }
        self.assertEqual(first, EXPECTED_ROLE_CAPABILITIES)
        self.assertEqual(second, EXPECTED_ROLE_CAPABILITIES)
        self.assertEqual(Capability.objects.filter(is_system=True).count(), len(CAPABILITY_CATALOG))
        self.assertEqual(Role.objects.filter(is_system=True).count(), 4)
        self.assertIn("能力：新建", output.getvalue())

    def test_bootstrap_restores_catalog_drift_and_exact_links(self):
        call_command("bootstrap_rbac", stdout=StringIO())
        role = Role.objects.get(key="readonly_viewer")
        extra = Capability.objects.get(key=ROLE_MANAGE)
        RoleCapability.objects.create(role=role, capability=extra)
        stale_capability = Capability.objects.create(
            key="accounts.stale",
            name="废弃能力",
            is_system=True,
            is_active=True,
        )
        stale_role = Role.objects.create(
            key="stale_role",
            name="废弃角色",
            is_system=True,
            is_active=True,
        )
        stale_member = User.objects.create_user(
            username="stale-role-member",
            password=PASSWORD,
        )
        RoleCapability.objects.create(
            role=stale_role,
            capability=Capability.objects.get(key=USER_VIEW),
        )
        UserRole.objects.create(user=stale_member, role=stale_role)
        role.name = "漂移名称"
        role.is_active = False
        role.save(update_fields=["name", "is_active"])
        capability = Capability.objects.get(key=USER_VIEW)
        capability.is_active = False
        capability.save(update_fields=["is_active"])

        call_command("bootstrap_rbac", stdout=StringIO())
        role.refresh_from_db()
        capability.refresh_from_db()
        self.assertEqual(role.name, "只读查看员")
        self.assertTrue(role.is_active)
        self.assertTrue(capability.is_active)
        self.assertEqual(
            self.role_capability_keys("readonly_viewer"),
            EXPECTED_ROLE_CAPABILITIES["readonly_viewer"],
        )
        stale_capability.refresh_from_db()
        stale_role.refresh_from_db()
        self.assertFalse(stale_capability.is_system)
        self.assertFalse(stale_capability.is_active)
        self.assertFalse(stale_role.is_system)
        self.assertFalse(stale_role.is_active)
        self.assertFalse(RoleCapability.objects.filter(role=stale_role).exists())
        self.assertFalse(UserRole.objects.filter(role=stale_role).exists())

    def test_bootstrap_renames_legacy_custom_role_using_reserved_name(self):
        Role.objects.filter(key="platform_admin").delete()
        custom_role = Role.objects.create(
            key="legacy-custom-role",
            name="旧自定义角色",
        )
        Role.objects.filter(pk=custom_role.pk).update(name="平台管理员")

        call_command("bootstrap_rbac", stdout=StringIO())

        custom_role.refresh_from_db()
        self.assertTrue(custom_role.name.startswith("[名称冲突]"))
        self.assertTrue(
            Role.objects.filter(
                key="platform_admin",
                name="平台管理员",
                is_system=True,
            ).exists()
        )

    def test_bootstrap_rejects_non_system_reserved_role_without_reassigning_users(self):
        Role.objects.filter(key="platform_admin").delete()
        legacy_role = Role.objects.create(key="legacy-key", name="旧自定义角色")
        Role.objects.filter(pk=legacy_role.pk).update(key="platform_admin")
        member = User.objects.create_user(username="legacy-member", password=PASSWORD)
        UserRole.objects.create(user=member, role=legacy_role)

        with self.assertRaises(CommandError):
            call_command("bootstrap_rbac", stdout=StringIO())
        legacy_role.refresh_from_db()
        self.assertFalse(legacy_role.is_system)
        self.assertEqual(list(member.roles.all()), [legacy_role])
        self.assertFalse(RoleCapability.objects.filter(role=legacy_role).exists())

    def test_bootstrap_retires_stale_role_name_before_creating_declared_role(self):
        Role.objects.filter(key="platform_admin").delete()
        stale_role = Role.objects.create(
            key="old_platform_role",
            name="平台管理员",
            is_system=True,
        )
        call_command("bootstrap_rbac", stdout=StringIO())
        stale_role.refresh_from_db()
        self.assertFalse(stale_role.is_system)
        self.assertFalse(stale_role.is_active)
        self.assertNotEqual(stale_role.name, "平台管理员")
        self.assertTrue(
            Role.objects.filter(
                key="platform_admin",
                name="平台管理员",
                is_system=True,
            ).exists()
        )

    def test_invalid_catalog_fails_before_database_writes(self):
        from .management.commands import bootstrap_rbac

        invalid = (
            {"key": USER_VIEW, "name": "一", "description": ""},
            {"key": USER_VIEW, "name": "二", "description": ""},
        )
        before = {
            "capabilities": Capability.objects.count(),
            "roles": Role.objects.count(),
            "links": RoleCapability.objects.count(),
        }
        with patch.object(bootstrap_rbac, "CAPABILITY_CATALOG", invalid):
            with self.assertRaises(CommandError):
                call_command("bootstrap_rbac", stdout=StringIO())
        after = {
            "capabilities": Capability.objects.count(),
            "roles": Role.objects.count(),
            "links": RoleCapability.objects.count(),
        }
        self.assertEqual(after, before)

    def test_bootstrap_rolls_back_all_rows_on_failure(self):
        capability = Capability.objects.get(key=USER_VIEW)
        capability.is_active = False
        capability.save(update_fields=["is_active"])
        platform_role = Role.objects.get(key="platform_admin")
        Role.objects.filter(pk=platform_role.pk).update(name="事务前漂移名称")
        original = Role.objects.get_or_create

        def fail_on_third(*args, **kwargs):
            if kwargs.get("key") == "permission_manager":
                raise RuntimeError("模拟第三个角色写入失败")
            return original(*args, **kwargs)

        with patch.object(Role.objects, "get_or_create", side_effect=fail_on_third):
            with self.assertRaises(RuntimeError):
                call_command("bootstrap_rbac", stdout=StringIO())
        capability.refresh_from_db()
        platform_role.refresh_from_db()
        self.assertFalse(capability.is_active)
        self.assertEqual(platform_role.name, "事务前漂移名称")
        self.assertEqual(Capability.objects.count(), len(CAPABILITY_CATALOG))
        self.assertEqual(Role.objects.count(), 4)
        self.assertEqual(RoleCapability.objects.count(), 34)


class UrlAndTemplateTests(TestCase):
    def setUp(self):
        self.admin_user = User.objects.create_superuser(
            username="template-admin",
            password=PASSWORD,
        )
        call_command("bootstrap_rbac", stdout=StringIO())
        self.department = Department.objects.create(code="TPL", name="模板部门")
        self.user_obj = User.objects.create_user(
            username="template-user",
            password=PASSWORD,
            department=self.department,
        )
        self.role = create_role("template-role", (USER_VIEW,), name="模板角色")
        UserRole.objects.create(user=self.user_obj, role=self.role)
        self.client.force_login(self.admin_user)

    def test_core_url_names_reverse(self):
        no_arg_names = (
            "home",
            "login",
            "logout",
            "password_change",
            "password_change_done",
            "user_list",
            "user_create",
            "department_list",
            "department_create",
            "role_list",
            "role_create",
            "permission_list",
        )
        for name in no_arg_names:
            self.assertTrue(reverse("accounts:%s" % name))

        object_names = {
            "user_detail": self.user_obj.pk,
            "user_update": self.user_obj.pk,
            "user_access": self.user_obj.pk,
            "user_status": self.user_obj.pk,
            "user_delete": self.user_obj.pk,
            "department_update": self.department.pk,
            "department_delete": self.department.pk,
            "role_update": self.role.pk,
            "role_delete": self.role.pk,
        }
        for name, pk in object_names.items():
            self.assertTrue(reverse("accounts:%s" % name, args=[pk]))

    def test_all_core_get_templates_render_for_superuser(self):
        urls_and_templates = (
            (reverse("accounts:home"), "accounts/home.html"),
            (reverse("accounts:password_change"), "accounts/password_change_form.html"),
            (reverse("accounts:password_change_done"), "accounts/password_change_done.html"),
            (reverse("accounts:user_list"), "accounts/user_list.html"),
            (reverse("accounts:user_create"), "accounts/user_form.html"),
            (reverse("accounts:user_detail", args=[self.user_obj.pk]), "accounts/user_detail.html"),
            (reverse("accounts:user_update", args=[self.user_obj.pk]), "accounts/user_form.html"),
            (reverse("accounts:user_access", args=[self.user_obj.pk]), "accounts/user_access_form.html"),
            (reverse("accounts:user_delete", args=[self.user_obj.pk]), "accounts/user_confirm_delete.html"),
            (reverse("accounts:department_list"), "accounts/department_list.html"),
            (reverse("accounts:department_create"), "accounts/department_form.html"),
            (reverse("accounts:department_update", args=[self.department.pk]), "accounts/department_form.html"),
            (reverse("accounts:department_delete", args=[self.department.pk]), "accounts/department_confirm_delete.html"),
            (reverse("accounts:role_list"), "accounts/role_list.html"),
            (reverse("accounts:role_create"), "accounts/role_form.html"),
            (reverse("accounts:role_update", args=[self.role.pk]), "accounts/role_form.html"),
            (reverse("accounts:role_delete", args=[self.role.pk]), "accounts/role_confirm_delete.html"),
            (reverse("accounts:permission_list"), "accounts/permission_list.html"),
        )
        for url, template_name in urls_and_templates:
            with self.subTest(url=url):
                response = self.client.get(url)
                self.assertEqual(response.status_code, 200)
                self.assertTemplateUsed(response, template_name)

    def test_templates_use_policy_tags_and_custom_role_wording(self):
        template_root = Path(settings.BASE_DIR) / "templates"
        contents = "\n".join(
            path.read_text(encoding="utf-8")
            for path in template_root.rglob("*.html")
        )
        self.assertNotIn("perms.", contents)
        self.assertNotIn("user.groups", contents)
        self.assertNotIn("user_permissions", contents)
        self.assertNotIn("Django Group", contents)
        self.assertIn("policy_can", contents)

    def test_readonly_template_hides_management_actions(self):
        call_command("bootstrap_rbac", stdout=StringIO())
        viewer = User.objects.create_user(username="viewer", password=PASSWORD)
        UserRole.objects.create(user=viewer, role=Role.objects.get(key="readonly_viewer"))
        self.client.force_login(viewer)

        user_response = self.client.get(reverse("accounts:user_list"))
        self.assertNotContains(user_response, "新建用户")
        role_response = self.client.get(reverse("accounts:role_list"))
        self.assertNotContains(role_response, "新建角色")
        self.assertContains(role_response, "模板角色")
        self.assertContains(role_response, "由初始化命令维护", count=4)
        self.assertNotContains(
            role_response,
            reverse("accounts:role_update", args=[self.role.pk]),
        )

    def test_user_detail_shows_custom_role_without_direct_permissions(self):
        response = self.client.get(
            reverse("accounts:user_detail", args=[self.user_obj.pk])
        )
        self.assertContains(response, "模板角色")
        self.assertNotContains(response, "直接权限")

    def test_login_template_renders_for_anonymous_user(self):
        self.client.logout()
        response = self.client.get(reverse("accounts:login"))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "accounts/login.html")
        self.assertContains(response, "登录 devopsX")
