# accounts/policy.py
from django.core.exceptions import PermissionDenied

from .models import Capability, UserRole


_REQUEST_SNAPSHOT_ATTRIBUTE = "_accounts_policy_snapshot"


class PolicySnapshot:
    # 每个快照只查询一次，避免模板中的多个判断重复访问数据库。
    def __init__(self, user):
        # 输入：用户或匿名用户对象；输出：初始化不可跨请求复用的策略快照；调用者：策略辅助函数；失败：数据库读取异常向上抛出。
        self.user = user
        self.is_authenticated = bool(
            user is not None and getattr(user, "is_authenticated", False)
        )
        self.is_active = bool(self.is_authenticated and user.is_active)
        self.is_superuser = bool(self.is_active and user.is_superuser)
        self.capability_keys = self._load_capability_keys()

    def _load_capability_keys(self):
        # 输入：已初始化的认证/激活/超级用户状态；输出：能力编码 frozenset；调用者：快照构造函数；失败：数据库读取异常向上抛出。
        if not self.is_active:
            return frozenset()
        if self.is_superuser:
            # 超级用户绕过业务角色，但目录仍只展示当前启用的能力。
            return frozenset(
                Capability.objects.filter(is_active=True).values_list("key", flat=True)
            )

        # 只沿项目自有用户角色链路读取，不触碰 Django Group/Permission。
        return frozenset(
            UserRole.objects.filter(
                user_id=self.user.pk,
                role__is_active=True,
                role__role_capabilities__capability__is_active=True,
            )
            .values_list("role__role_capabilities__capability__key", flat=True)
            .distinct()
        )

    def has_capability(self, capability_key):
        # 输入：单个能力编码；输出：当前快照是否允许的布尔值；调用者：策略函数、装饰器和模板；失败：未激活用户失败关闭为 False。
        if not self.is_active:
            return False
        # 激活的超级用户保留内部运维旁路。
        if self.is_superuser:
            return True
        return capability_key in self.capability_keys

    def has_any_capability(self, capability_keys):
        # 输入：能力编码可迭代对象；输出：是否至少拥有一项；调用者：任一能力策略；失败：空集合或全部不满足时返回 False。
        keys = tuple(capability_keys)
        return any(self.has_capability(key) for key in keys)

    def has_all_capabilities(self, capability_keys):
        # 输入：能力编码可迭代对象；输出：是否拥有全部能力；调用者：全部能力策略；失败：空集合明确失败关闭为 False。
        keys = tuple(capability_keys)
        if not keys:
            # 空集合不代表业务授权，避免配置错误时意外放行。
            return False
        return all(self.has_capability(key) for key in keys)


def policy_snapshot(subject):
    # 输入：request、用户或已有快照；输出：PolicySnapshot；调用者：所有策略入口；失败：数据库读取异常向上抛出。
    if isinstance(subject, PolicySnapshot):
        return subject

    # 传入 request 时做请求内缓存；进程之间和请求之间绝不共享。
    if hasattr(subject, "user"):
        snapshot = getattr(subject, _REQUEST_SNAPSHOT_ATTRIBUTE, None)
        if snapshot is None:
            snapshot = PolicySnapshot(subject.user)
            setattr(subject, _REQUEST_SNAPSHOT_ATTRIBUTE, snapshot)
        return snapshot

    return PolicySnapshot(subject)


def has_capability(subject, capability_key):
    # 输入：request/用户/快照和能力键；输出：布尔值；调用者：视图、模板和装饰器；失败：未认证或停用时返回 False。
    return policy_snapshot(subject).has_capability(capability_key)


def has_any_capability(subject, capability_keys):
    # 输入：request/用户/快照和能力集合；输出：是否拥有任一能力；调用者：装饰器和业务代码；失败：均不满足时返回 False。
    return policy_snapshot(subject).has_any_capability(capability_keys)


def has_all_capabilities(subject, capability_keys):
    # 输入：request/用户/快照和能力集合；输出：是否拥有全部能力；调用者：装饰器和业务代码；失败：空集合或任一缺失时返回 False。
    return policy_snapshot(subject).has_all_capabilities(capability_keys)


def require_capability(subject, capability_key):
    # 输入：request/用户/快照和单个能力；输出：校验通过时无返回值；调用者：装饰器和锁后重验；失败：缺能力时抛 PermissionDenied。
    if not has_capability(subject, capability_key):
        raise PermissionDenied("缺少能力：%s。" % capability_key)


def require_any_capability(subject, capability_keys):
    # 输入：request/用户/快照和能力集合；输出：至少一项通过时无返回值；调用者：任一能力装饰器；失败：全部缺失时抛 PermissionDenied。
    keys = tuple(capability_keys)
    if not has_any_capability(subject, keys):
        raise PermissionDenied("至少需要以下一项能力：%s。" % "、".join(keys))


def require_all_capabilities(subject, capability_keys):
    # 输入：request/用户/快照和能力集合；输出：全部通过时无返回值；调用者：全部能力装饰器；失败：空集合或任一缺失时抛 PermissionDenied。
    keys = tuple(capability_keys)
    if not has_all_capabilities(subject, keys):
        raise PermissionDenied("需要具备以下全部能力：%s。" % "、".join(keys))
