# accounts/providers/fake.py
import base64
import hashlib
import secrets
from urllib.parse import urlencode

from django.urls import reverse

from .base import ProviderCallbackError, VerifiedExternalIdentity


_FAKE_CODE_SESSION_KEY = "accounts_fake_provider_codes"

FAKE_IDENTITIES = {
    "demo-viewer": {
        "subject": "fake-subject-viewer",
        "display_name": "Fake 查看用户",
        "email": "fake-viewer@example.invalid",
    },
    "demo-admin": {
        "subject": "fake-subject-admin",
        "display_name": "Fake 管理用户",
        "email": "fake-admin@example.invalid",
    },
}


def create_s256_code_challenge(code_verifier):
    # 输入：ASCII PKCE verifier；输出：S256 base64url challenge；调用者：流程启动与 Fake 回调校验；失败：非 ASCII 或非字符串输入时抛出编码异常。
    # OAuth 2.0 PKCE 的 S256 规则是 SHA-256 后再做无填充 base64url。
    digest = hashlib.sha256(code_verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


class FakeProvider:
    key = "fake"
    display_name = "本地 Fake Provider"

    def is_available(self):
        # 输入：Fake 适配器实例；输出：True；调用者：provider 可用性检查；失败：全局启用开关由注册表在调用前统一拒绝。
        return True

    def begin_authorization(
        self,
        request,
        *,
        redirect_uri,
        state,
        code_challenge,
        nonce,
        transaction_id,
        identity_hint,
    ):
        # 输入：请求及服务端生成的回调、state、PKCE challenge、nonce、事务号和 Fake 提示；输出：本地授权页 URL；调用者：流程启动服务；失败：URL 反向解析异常向上抛出。
        # Fake 授权页仍通过浏览器跳转，便于真实验收完整开始和回调流程。
        query = urlencode(
            {
                "redirect_uri": redirect_uri,
                "state": state,
                "code_challenge": code_challenge,
                "nonce": nonce,
                "transaction_id": transaction_id,
                "identity": identity_hint,
            }
        )
        # 返回：只返回本地授权页地址；真正的一次性 code 必须等用户明确批准后才签发。
        return "%s?%s" % (reverse("accounts:fake_authorize"), query)

    def issue_code(
        self,
        request,
        *,
        subject,
        display_name,
        email,
        redirect_uri,
        state,
        code_challenge,
        nonce,
    ):
        # 输入：当前 Session、已选身份、固定回调、state、PKCE challenge 和 nonce；输出：一次性授权 code；调用者：Fake 授权视图；失败：Session 保存异常向上抛出。
        # code 使用密码学随机数；身份资料只临时保存在当前服务端 Session，因而授权码也绑定同一浏览器会话。
        code = secrets.token_urlsafe(32)
        codes = request.session.get(_FAKE_CODE_SESSION_KEY, {})
        codes[code] = {
            "provider": self.key,
            "subject": subject,
            "display_name": display_name,
            "email": email,
            "redirect_uri": redirect_uri,
            "state": state,
            "code_challenge": code_challenge,
            "nonce": nonce,
        }
        request.session[_FAKE_CODE_SESSION_KEY] = codes
        request.session.modified = True
        # 返回：只把高熵一次性 code 交给授权页拼入回调，不返回 subject、nonce 等完整载荷。
        return code

    def complete_callback(
        self,
        request,
        *,
        code,
        redirect_uri,
        code_verifier,
        expected_nonce,
    ):
        # 输入：当前 Session、一次性 code、固定回调、PKCE verifier 和预期 nonce；输出：已验证身份；调用者：回调完成服务；失败：任一绑定不符即抛 ProviderCallbackError。
        # 重放防护：先 pop 一次性 code，即使后续 redirect_uri、PKCE 或 nonce 校验失败也不能再次使用。
        codes = request.session.get(_FAKE_CODE_SESSION_KEY, {})
        result = codes.pop(code, None)
        request.session[_FAKE_CODE_SESSION_KEY] = codes
        request.session.modified = True

        if result is None:
            raise ProviderCallbackError("fake_code_invalid")
        if result.get("provider") != self.key:
            raise ProviderCallbackError("fake_provider_mismatch")
        if result.get("redirect_uri") != redirect_uri:
            raise ProviderCallbackError("fake_redirect_mismatch")
        if result.get("code_challenge") != create_s256_code_challenge(code_verifier):
            raise ProviderCallbackError("fake_pkce_mismatch")
        if result.get("nonce") != expected_nonce:
            raise ProviderCallbackError("fake_nonce_mismatch")

        subject = result.get("subject", "")
        if not subject or subject != subject.strip() or len(subject) > 255:
            raise ProviderCallbackError("fake_subject_invalid")

        # 返回：所有绑定校验通过后才构造标准身份值对象；一次性 code 已在上方 pop，不能再次使用。
        return VerifiedExternalIdentity(
            provider=self.key,
            subject=subject,
            display_name=result.get("display_name", "")[:100],
            email=result.get("email", "")[:254],
        )
