# accounts/providers/base.py
from dataclasses import dataclass
from typing import Protocol


SAFE_PROVIDER_REASON_CODES = frozenset(
    {
        "provider_error",
        "provider_unavailable",
        "provider_callback_failed",
        "provider_not_registered",
        "fake_provider_disabled",
        "enterprise_wechat_not_configured",
        "feishu_not_configured",
        "wechat_open_platform_not_configured",
        "fake_code_invalid",
        "fake_provider_mismatch",
        "fake_redirect_mismatch",
        "fake_pkce_mismatch",
        "fake_nonce_mismatch",
        "fake_subject_invalid",
    }
)


class ProviderError(Exception):
    """第三方身份提供方返回了不能继续处理的结果。"""

    fallback_reason_code = "provider_error"

    def __init__(self, reason_code=""):
        # 输入：provider 内部原因码；输出：初始化仅携带白名单原因的异常；调用者：所有适配器；失败：未知原因降级为通用码以免泄露细节。
        if reason_code not in SAFE_PROVIDER_REASON_CODES:
            reason_code = self.fallback_reason_code
        self.reason_code = reason_code
        super().__init__("第三方身份提供方返回了不能继续处理的结果。")


class ProviderUnavailable(ProviderError):
    """提供方尚未配置，必须拒绝继续而不是退回 Fake 实现。"""

    fallback_reason_code = "provider_unavailable"


class ProviderCallbackError(ProviderError):
    """回调参数、一次性 code、PKCE 或 nonce 校验失败。"""

    fallback_reason_code = "provider_callback_failed"


@dataclass(frozen=True)
class VerifiedExternalIdentity:
    # provider 和 subject 是登录查找使用的稳定键。
    provider: str
    subject: str
    # display_name 与 email 只用于展示，不能用于自动合并本地用户。
    display_name: str = ""
    email: str = ""


class ExternalIdentityProvider(Protocol):
    key: str
    display_name: str

    def is_available(self):
        # 输入：适配器实例；输出：配置可用性的布尔值；调用者：注册表和解绑保护；失败：实现应失败关闭为不可用。
        """返回当前配置是否允许这个身份源完成真实登录。"""

    def begin_authorization(
        self,
        request,
        *,
        redirect_uri,
        state,
        code_challenge,
        nonce,
        transaction_id,
        identity_hint,
    ):
        # 输入：请求、固定回调、state、PKCE challenge、nonce、事务号和提示；输出：授权地址；调用者：流程启动服务；失败：不可用或参数异常时抛 ProviderError。
        """返回跳转到第三方授权页面的完整地址。"""

    def complete_callback(
        self,
        request,
        *,
        code,
        redirect_uri,
        code_verifier,
        expected_nonce,
    ):
        # 输入：请求、一次性 code、固定回调、PKCE verifier 和预期 nonce；输出：VerifiedExternalIdentity；调用者：回调服务；失败：任一验证失败时抛 ProviderError 并拒绝身份。
        """完成 code、PKCE、OIDC nonce 校验并返回已验证身份。"""
