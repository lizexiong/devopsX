# accounts/providers/wechat_open_platform.py
from .base import ProviderUnavailable


class WechatOpenPlatformProvider:
    key = "wechat_open_platform"
    display_name = "微信开放平台"

    def is_available(self):
        # 输入：微信开放平台适配器实例；输出：False；调用者：注册表和解绑保护；失败：未配置时始终失败关闭。
        return False

    def begin_authorization(self, request, **kwargs):
        # 输入：请求及授权参数；输出：无；调用者：流程启动服务；失败：尚未配置时明确抛 ProviderUnavailable，绝不回退 Fake。
        raise ProviderUnavailable("wechat_open_platform_not_configured")

    def complete_callback(self, request, **kwargs):
        # 输入：请求及回调参数；输出：无；调用者：回调完成服务；失败：尚未配置时明确抛 ProviderUnavailable，绝不接受未验证身份。
        raise ProviderUnavailable("wechat_open_platform_not_configured")
