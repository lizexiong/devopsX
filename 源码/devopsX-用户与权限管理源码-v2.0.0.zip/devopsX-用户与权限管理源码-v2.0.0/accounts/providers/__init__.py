# accounts/providers/__init__.py
from django.conf import settings

from .base import ProviderUnavailable
from .enterprise_wechat import EnterpriseWechatProvider
from .fake import FakeProvider
from .feishu import FeishuProvider
from .wechat_open_platform import WechatOpenPlatformProvider


_PROVIDERS = {
    FakeProvider.key: FakeProvider(),
    EnterpriseWechatProvider.key: EnterpriseWechatProvider(),
    FeishuProvider.key: FeishuProvider(),
    WechatOpenPlatformProvider.key: WechatOpenPlatformProvider(),
}


def get_provider(provider_key):
    # 输入：服务端 provider 稳定键；输出：已注册适配器实例；调用者：身份服务和授权视图；失败：未知或禁用 Fake 时抛出 ProviderUnavailable。
    # 注册表只接受服务端已知键，浏览器不能通过模块名动态导入任意代码。
    provider = _PROVIDERS.get(provider_key)
    if provider is None:
        raise ProviderUnavailable("provider_not_registered")
    if provider_key == FakeProvider.key and (
        not settings.ACCOUNTS_FAKE_PROVIDER_ALLOWED
        or not settings.ACCOUNTS_ENABLE_FAKE_PROVIDER
    ):
        raise ProviderUnavailable("fake_provider_disabled")
    return provider


def provider_is_available(provider_key):
    # 输入：provider 稳定键；输出：当前是否可完成登录的布尔值；调用者：解绑最后登录方式检查；失败：未注册或禁用时安全返回 False。
    try:
        provider = get_provider(provider_key)
    except ProviderUnavailable:
        return False
    return bool(provider.is_available())
