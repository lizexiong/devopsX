# accounts/identity.py
import hashlib
import hmac
import secrets
from datetime import timedelta

from django.conf import settings
from django.contrib.auth import login
from django.db import IntegrityError, transaction
from django.urls import reverse
from django.utils import timezone

from .models import (
    AuditEventType,
    AuditOutcome,
    AuthorizationAuditEvent,
    ExternalIdentity,
    IdentityProvider,
    LoginIntent,
    LoginTransaction,
    LoginTransactionStatus,
    User,
    external_subject_digest,
)
from .providers import get_provider, provider_is_available
from .providers.base import ProviderError, VerifiedExternalIdentity
from .providers.fake import FAKE_IDENTITIES, create_s256_code_challenge


SESSION_TRANSACTION_KEY = "accounts_external_transaction_id"
SESSION_STATE_KEY = "accounts_external_state"
SESSION_VERIFIER_KEY = "accounts_external_code_verifier"
SESSION_NONCE_KEY = "accounts_external_nonce"
SESSION_INTENT_KEY = "accounts_external_intent"
SESSION_IDENTITY_HINT_KEY = "accounts_external_identity_hint"


class ExternalFlowError(Exception):
    def __init__(self, reason_code, identity=None, status_code=400):
        # 输入：稳定原因码、可选身份和 HTTP 状态；输出：初始化可安全展示的流程异常；调用者：身份服务；失败：不包装底层秘密信息。
        self.reason_code = reason_code
        self.identity = identity
        self.status_code = status_code
        super().__init__("外部身份流程无法继续。")


def _digest(value, purpose):
    # 输入：待保护字符串与用途域；输出：基于 SECRET_KEY 的 SHA-256 HMAC；调用者：state、nonce、Session 绑定函数；失败：配置或编码异常向上抛出。
    # 用 SECRET_KEY 做 HMAC，不在数据库保存原始 state、nonce 或 Session key。
    message = (purpose + ":" + value).encode("utf-8")
    secret = settings.SECRET_KEY.encode("utf-8")
    return hmac.new(secret, message, hashlib.sha256).hexdigest()


def session_binding(session_key):
    # 输入：Django Session key；输出：不可逆 Session 绑定摘要；调用者：流程创建与回调校验；失败：Session 不存在时失败关闭并抛出 ExternalFlowError。
    if not session_key:
        raise ExternalFlowError("session_not_available")
    return _digest(session_key, "session")


def state_digest(state):
    # 输入：浏览器往返的随机 state；输出：用途隔离的 HMAC 摘要；调用者：事务创建和回调校验；失败：摘要计算异常向上抛出。
    return _digest(state, "state")


def nonce_digest(nonce):
    # 输入：OIDC 随机 nonce；输出：用途隔离的 HMAC 摘要；调用者：事务创建和回调校验；失败：摘要计算异常向上抛出。
    return _digest(nonce, "nonce")


def new_pkce_verifier():
    # 输入：无；输出：高熵 PKCE verifier；调用者：外部流程启动服务；失败：系统随机源异常向上抛出。
    return secrets.token_urlsafe(48)


def new_state():
    # 输入：无；输出：高熵 OAuth state；调用者：外部流程启动服务；失败：系统随机源异常向上抛出。
    return secrets.token_urlsafe(32)


def new_nonce():
    # 输入：无；输出：高熵 OIDC nonce；调用者：外部流程启动服务；失败：系统随机源异常向上抛出。
    return secrets.token_urlsafe(32)


def expected_redirect_uri(request, provider_key):
    # 输入：当前请求与已注册 provider 键；输出：服务端生成的绝对回调地址；调用者：流程开始和回调消费；失败：URL 反向解析或请求主机校验异常向上抛出。
    # 回调路径只由服务端 reverse() 生成，不接收浏览器提交的 redirect_uri。
    return request.build_absolute_uri(
        reverse("accounts:external_callback", kwargs={"provider": provider_key})
    )


def _audit(
    *,
    event_type,
    outcome,
    actor=None,
    target_user=None,
    external_identity=None,
    login_transaction=None,
    provider="",
    reason_code="",
    detail=None,
):
    # 输入：固定事件字段及已筛选详情；输出：新建审计事件；调用者：登录、绑定、解绑服务；失败：数据库写入异常向上抛出并使所在事务回滚。
    # 调用方只能传入 intent 等非秘密字段；这里永远不接收 token、code 或 state。
    # 返回：数据库创建成功后返回审计事件对象，供需要关联该事件的调用者继续使用。
    return AuthorizationAuditEvent.objects.create(
        event_type=event_type,
        outcome=outcome,
        actor=actor,
        target_user=target_user,
        external_identity=external_identity,
        login_transaction=login_transaction,
        provider=provider,
        reason_code=reason_code,
        detail=detail or {},
    )


def _clear_flow_session(request):
    # 输入：当前请求；输出：无返回值并删除全部外部流程 Session 临时值；调用者：成功或失败收尾；失败：Session 后端异常向上抛出。
    for key in (
        SESSION_TRANSACTION_KEY,
        SESSION_STATE_KEY,
        SESSION_VERIFIER_KEY,
        SESSION_NONCE_KEY,
        SESSION_INTENT_KEY,
        SESSION_IDENTITY_HINT_KEY,
    ):
        request.session.pop(key, None)
    request.session.modified = True


def _clear_flow_session_if_current(request, transaction_id, state):
    # 输入：请求、回调事务号和 state；输出：无返回值，仅在二者仍匹配当前 Session 时清理；调用者：回调预校验失败路径；失败：不匹配时保留其他并发流程数据。
    session_transaction_id = request.session.get(SESSION_TRANSACTION_KEY, "")
    session_state = request.session.get(SESSION_STATE_KEY, "")
    if session_transaction_id == str(transaction_id) and session_state == state:
        _clear_flow_session(request)


def start_external_flow(request, provider_key, intent, identity_hint=""):
    # 输入：请求、提供方、登录/绑定意图和可选 Fake 身份提示；输出：第三方授权跳转地址；调用者：登录或绑定起点视图；失败：配置、会话、参数或提供方错误时失败关闭。
    # 业务判断：只允许已注册 provider、已知意图；绑定必须属于当前激活用户，真实 provider 不接收客户端身份提示。
    provider = get_provider(provider_key)
    if intent not in LoginIntent.values:
        raise ExternalFlowError("intent_invalid")
    if intent == LoginIntent.BIND:
        if not request.user.is_authenticated or not request.user.is_active:
            raise ExternalFlowError("bind_login_required", status_code=403)
    if provider_key == IdentityProvider.FAKE:
        if identity_hint not in FAKE_IDENTITIES:
            raise ExternalFlowError("fake_identity_invalid")
    elif identity_hint:
        raise ExternalFlowError("identity_hint_not_allowed")

    # 业务准备：state 防跨站请求伪造，PKCE 把授权码绑定到 verifier，nonce 把身份响应绑定到本次请求。
    state = new_state()
    verifier = new_pkce_verifier()
    nonce = new_nonce()
    challenge = create_s256_code_challenge(verifier)

    # 先保存 Session，确保后面绑定的是已经存在的服务端 Session key。
    request.session.save()
    current_session_key = request.session.session_key
    if not current_session_key:
        raise ExternalFlowError("session_not_available")

    redirect_uri = expected_redirect_uri(request, provider_key)
    ttl_seconds = settings.ACCOUNTS_EXTERNAL_LOGIN_TTL_SECONDS
    expires_at = timezone.now() + timedelta(seconds=ttl_seconds)
    # 数据库保存：原子创建事务和开始审计，只落 state/nonce/Session 摘要；任一写入失败都整体回滚。
    with transaction.atomic():
        login_transaction = LoginTransaction.objects.create(
            provider=provider_key,
            intent=intent,
            state_digest=state_digest(state),
            session_binding=session_binding(current_session_key),
            redirect_uri=redirect_uri,
            code_challenge=challenge,
            nonce_digest=nonce_digest(nonce),
            initiating_user=(request.user if intent == LoginIntent.BIND else None),
            expires_at=expires_at,
        )
        _audit(
            event_type=AuditEventType.LOGIN_STARTED,
            outcome=AuditOutcome.SUCCESS,
            actor=request.user if request.user.is_authenticated else None,
            target_user=request.user if intent == LoginIntent.BIND else None,
            login_transaction=login_transaction,
            provider=provider_key,
            detail={"intent": intent},
        )

    # Session 保存：原始 state、verifier、nonce 只留在发起浏览器的服务端 Session，并与数据库事务号成组绑定。
    request.session[SESSION_TRANSACTION_KEY] = str(login_transaction.transaction_id)
    request.session[SESSION_STATE_KEY] = state
    request.session[SESSION_VERIFIER_KEY] = verifier
    request.session[SESSION_NONCE_KEY] = nonce
    request.session[SESSION_INTENT_KEY] = intent
    request.session[SESSION_IDENTITY_HINT_KEY] = identity_hint
    request.session.modified = True

    # 返回：provider 仅获得本次授权所需值；启动失败时先把事务标为失败、清理 Session，再返回统一错误。
    try:
        return provider.begin_authorization(
            request,
            redirect_uri=redirect_uri,
            state=state,
            code_challenge=challenge,
            nonce=nonce,
            transaction_id=str(login_transaction.transaction_id),
            identity_hint=identity_hint,
        )
    except ProviderError as error:
        _mark_transaction_failed(
            request,
            login_transaction,
            error.reason_code,
            AuditOutcome.ERROR,
        )
        _clear_flow_session(request)
        raise ExternalFlowError("provider_unavailable")


def _load_and_consume_transaction(request, provider_key, transaction_id, state):
    # 输入：当前请求、provider、事务 UUID 和回传 state；输出：已消费事务、verifier、nonce、回调地址；调用者：成功或拒绝回调；失败：任一绑定校验不符即失败关闭。
    # Session 读取：原始 verifier/nonce 只能来自发起浏览器；缺少任一关键值都不尝试恢复或降级。
    current_session_key = request.session.session_key
    verifier = request.session.get(SESSION_VERIFIER_KEY, "")
    nonce = request.session.get(SESSION_NONCE_KEY, "")
    session_state = request.session.get(SESSION_STATE_KEY, "")
    session_transaction_id = request.session.get(SESSION_TRANSACTION_KEY, "")
    if not current_session_key or not verifier or not nonce:
        raise ExternalFlowError("flow_session_missing")
    if session_transaction_id != str(transaction_id) or session_state != state:
        raise ExternalFlowError("state_session_mismatch")

    callback_redirect_uri = expected_redirect_uri(request, provider_key)
    expired = False
    # 数据库读取与锁定：先锁唯一 LoginTransaction 行，再检查状态；同一事务的并发回调只能有一个继续。
    with transaction.atomic():
        try:
            login_transaction = LoginTransaction.objects.select_for_update().get(
                transaction_id=transaction_id
            )
        except LoginTransaction.DoesNotExist:
            raise ExternalFlowError("transaction_missing")

        if login_transaction.provider != provider_key:
            raise ExternalFlowError("provider_mismatch")
        # 重放判断：只有 PENDING 可继续；CONSUMED/SUCCEEDED/FAILED 均永久拒绝旧回调。
        if login_transaction.status != LoginTransactionStatus.PENDING:
            raise ExternalFlowError("transaction_replayed")
        if login_transaction.has_expired():
            login_transaction.status = LoginTransactionStatus.FAILED
            login_transaction.failure_code = "transaction_expired"
            login_transaction.consumed_at = timezone.now()
            login_transaction.save(
                update_fields=["status", "failure_code", "consumed_at"]
            )
            _audit(
                event_type=AuditEventType.LOGIN_FAILED,
                outcome=AuditOutcome.DENIED,
                actor=request.user if request.user.is_authenticated else None,
                login_transaction=login_transaction,
                provider=provider_key,
                reason_code="transaction_expired",
            )
            expired = True
        else:
            # 业务判断：依次核对 Session 绑定、state、固定 redirect_uri、PKCE challenge 和 nonce；任何不符都立即拒绝。
            if not hmac.compare_digest(
                login_transaction.session_binding,
                session_binding(current_session_key),
            ):
                raise ExternalFlowError("session_binding_mismatch")
            if not hmac.compare_digest(
                login_transaction.state_digest,
                state_digest(state),
            ):
                raise ExternalFlowError("state_mismatch")
            if login_transaction.redirect_uri != callback_redirect_uri:
                raise ExternalFlowError("redirect_uri_mismatch")
            if login_transaction.code_challenge != create_s256_code_challenge(verifier):
                raise ExternalFlowError("pkce_mismatch")
            if not hmac.compare_digest(
                login_transaction.nonce_digest,
                nonce_digest(nonce),
            ):
                raise ExternalFlowError("nonce_mismatch")

            # 数据库保存：在调用第三方网络接口前先消费事务，防止两个并发回调同时成功。
            login_transaction.status = LoginTransactionStatus.CONSUMED
            login_transaction.consumed_at = timezone.now()
            login_transaction.save(update_fields=["status", "consumed_at"])

    if expired:
        raise ExternalFlowError("transaction_expired")
    # 返回：事务已经提交为 CONSUMED，后续提供方网络失败也不会把同一回调恢复成可重放状态。
    return login_transaction, verifier, nonce, callback_redirect_uri


def _mark_transaction_failed(request, login_transaction, reason_code, outcome):
    # 输入：请求、事务、稳定原因码和审计结果；输出：无返回值并持久化失败；调用者：provider 或身份解析失败路径；失败：数据库异常向上抛出。
    # 数据库读取与保存：锁定事务后仅覆盖非成功状态，并在同一原子事务写入失败审计。
    with transaction.atomic():
        locked = LoginTransaction.objects.select_for_update().get(pk=login_transaction.pk)
        if locked.status != LoginTransactionStatus.SUCCEEDED:
            locked.status = LoginTransactionStatus.FAILED
            locked.failure_code = reason_code
            locked.save(update_fields=["status", "failure_code"])
        _audit(
            event_type=AuditEventType.LOGIN_FAILED,
            outcome=outcome,
            actor=request.user if request.user.is_authenticated else None,
            login_transaction=locked,
            provider=locked.provider,
            reason_code=reason_code,
        )


def reject_external_callback(request, provider_key, transaction_id, state):
    # 输入：第三方拒绝回调的请求、provider、事务号和 state；输出：不正常返回；调用者：回调视图；失败：消费事务、记拒绝审计、清 Session 后抛出 ExternalFlowError。
    # 业务判断：拒绝回调仍必须先完整校验并消费事务；不能因没有 code 就跳过 state、Session 和重放检查。
    try:
        login_transaction, unused_verifier, unused_nonce, unused_redirect_uri = (
            _load_and_consume_transaction(
                request,
                provider_key,
                transaction_id,
                state,
            )
        )
    except ExternalFlowError:
        _clear_flow_session_if_current(request, transaction_id, state)
        raise
    _mark_transaction_failed(
        request,
        login_transaction,
        "provider_access_denied",
        AuditOutcome.DENIED,
    )
    _clear_flow_session(request)
    raise ExternalFlowError("provider_access_denied")


def finish_external_callback(request, provider_key, transaction_id, state, code):
    # 输入：回调请求、provider、事务号、state 和一次性 code；输出：登录或绑定结果字典；调用者：回调视图；失败：校验、换码或身份归属失败时关闭流程并清理 Session。
    provider = get_provider(provider_key)
    try:
        login_transaction, verifier, nonce, redirect_uri = _load_and_consume_transaction(
            request,
            provider_key,
            transaction_id,
            state,
        )
    except ExternalFlowError:
        _clear_flow_session_if_current(request, transaction_id, state)
        raise

    # 第三方回调：事务已先消费；provider 必须用 code + verifier 换取并校验身份，并核对 expected_nonce，失败不允许重试旧 code。
    try:
        verified_identity = provider.complete_callback(
            request,
            code=code,
            redirect_uri=redirect_uri,
            code_verifier=verifier,
            expected_nonce=nonce,
        )
    except ProviderError as error:
        _mark_transaction_failed(
            request,
            login_transaction,
            error.reason_code,
            AuditOutcome.ERROR,
        )
        _clear_flow_session(request)
        raise ExternalFlowError("provider_callback_failed")

    # 业务判断与保存：已验证身份只按 provider + subject 解析；无论成功或失败都清除本次 Session 秘密。
    try:
        result = _resolve_identity(request, login_transaction, verified_identity)
    finally:
        _clear_flow_session(request)

    if result["kind"] == "login":
        # Django login() 会轮换 Session key，防止会话固定攻击。
        login(
            request,
            result["user"],
            backend=settings.AUTHENTICATION_BACKENDS[0],
        )
    # 返回：登录结果此时已轮换 Session；绑定结果保持当前登录 Session，但敏感临时值已清除。
    return result


def _resolve_identity(request, login_transaction, verified_identity):
    # 输入：请求、已消费事务和 provider 验证结果；输出：登录或绑定结果；调用者：回调完成服务；失败：类型/provider/意图不一致时记失败并拒绝。
    # 业务判断：只接受标准值对象，且其 provider 必须与事务完全一致，避免跨 provider 身份替换。
    if not isinstance(verified_identity, VerifiedExternalIdentity):
        _mark_transaction_failed(
            request,
            login_transaction,
            "provider_result_invalid",
            AuditOutcome.ERROR,
        )
        raise ExternalFlowError("provider_callback_failed")
    if verified_identity.provider != login_transaction.provider:
        _mark_transaction_failed(
            request,
            login_transaction,
            "verified_provider_mismatch",
            AuditOutcome.DENIED,
        )
        raise ExternalFlowError("provider_callback_failed")
    # 返回：只按事务中服务端保存的意图分派，浏览器不能在回调时把登录改成绑定或反向修改。
    if login_transaction.intent == LoginIntent.BIND:
        return _bind_verified_identity(request, login_transaction, verified_identity)
    return _login_verified_identity(request, login_transaction, verified_identity)


def _find_or_create_identity(verified_identity):
    # 输入：已验证第三方身份；输出：在当前外层事务内加锁的 ExternalIdentity；调用者：登录和绑定服务；失败：摘要碰撞或数据库异常时拒绝。
    # 数据库读取：先按 provider + subject 摘要锁定现有行，再用常量时间比较原文以防摘要碰撞被误认。
    digest = external_subject_digest(verified_identity.subject)
    identity = (
        ExternalIdentity.objects.select_for_update()
        .filter(
            provider=verified_identity.provider,
            subject_digest=digest,
        )
        .first()
    )
    # 业务判断：命中摘要后必须继续常量时间比较原始 UTF-8 字节，不能把极小概率摘要碰撞当成同一身份。
    if identity is not None:
        if not hmac.compare_digest(
            identity.subject.encode("utf-8"),
            verified_identity.subject.encode("utf-8"),
        ):
            raise ExternalFlowError(
                "identity_subject_digest_collision",
                status_code=409,
            )
        # 返回：已有身份已锁定且原始 subject 完全一致，可以安全交给登录或绑定事务。
        return identity

    try:
        # 保存：嵌套 atomic 创建保存点；唯一键竞争失败时，外层事务仍可继续读取胜者。
        with transaction.atomic():
            return ExternalIdentity.objects.create(
                provider=verified_identity.provider,
                subject=verified_identity.subject,
                display_name=verified_identity.display_name,
                email=verified_identity.email,
            )
    except IntegrityError:
        # 唯一键竞争：另一事务先创建时锁住并读取胜者；若原始 subject 不同则按摘要碰撞失败关闭。
        identity = ExternalIdentity.objects.select_for_update().get(
            provider=verified_identity.provider,
            subject_digest=digest,
        )
        if not hmac.compare_digest(
            identity.subject.encode("utf-8"),
            verified_identity.subject.encode("utf-8"),
        ):
            raise ExternalFlowError(
                "identity_subject_digest_collision",
                status_code=409,
            )
        # 返回：并发创建的胜者已锁定且原始 subject 一致，调用者继续使用这一行。
        return identity


def _set_transaction_result(login_transaction, status, reason_code=""):
    # 输入：已锁定事务、最终状态和可选原因码；输出：无返回值并保存指定字段；调用者：登录和绑定事务；失败：数据库错误使外层事务回滚。
    login_transaction.status = status
    login_transaction.failure_code = reason_code
    login_transaction.save(update_fields=["status", "failure_code"])


def _bind_verified_identity(request, login_transaction, verified_identity):
    # 输入：当前登录请求、已消费绑定事务和已验证身份；输出：绑定结果；调用者：身份解析服务；失败：Session 换人、停用或身份已占用时原子失败。
    failure_code = ""
    identity = None
    actor = None
    # 数据库读取与锁顺序：先锁登录事务，再锁发起用户，最后按 provider + subject 锁身份，所有判断与保存位于同一事务。
    with transaction.atomic():
        locked_transaction = LoginTransaction.objects.select_for_update().get(
            pk=login_transaction.pk
        )
        if request.user.is_authenticated:
            actor = User.objects.select_for_update().get(pk=request.user.pk)
        if (
            actor is None
            or not actor.is_active
            or locked_transaction.initiating_user_id != actor.pk
        ):
            # 业务判断：绑定必须仍由原发起 Session 中同一激活用户完成，Session 换人时失败关闭。
            failure_code = "bind_session_changed"
        else:
            identity = _find_or_create_identity(verified_identity)
            if identity.user_id not in (None, actor.pk):
                failure_code = "identity_already_bound"

        # 保存：失败状态和审计、或身份归属与成功审计必须一起提交，避免出现绑定成功但事务仍未完成。
        if failure_code:
            _set_transaction_result(
                locked_transaction,
                LoginTransactionStatus.FAILED,
                failure_code,
            )
            _audit(
                event_type=AuditEventType.IDENTITY_BOUND,
                outcome=AuditOutcome.DENIED,
                actor=actor,
                target_user=actor,
                external_identity=identity,
                login_transaction=locked_transaction,
                provider=verified_identity.provider,
                reason_code=failure_code,
            )
        else:
            identity.user = actor
            identity.display_name = verified_identity.display_name
            identity.email = verified_identity.email
            identity.save(
                update_fields=["user", "display_name", "email", "last_seen_at"]
            )
            _set_transaction_result(
                locked_transaction,
                LoginTransactionStatus.SUCCEEDED,
            )
            _audit(
                event_type=AuditEventType.IDENTITY_BOUND,
                outcome=AuditOutcome.SUCCESS,
                actor=actor,
                target_user=actor,
                external_identity=identity,
                login_transaction=locked_transaction,
                provider=verified_identity.provider,
            )

    if failure_code:
        status_code = 409 if failure_code == "identity_already_bound" else 403
        raise ExternalFlowError("identity_conflict", status_code=status_code)
    # 返回：只有数据库事务完整提交后才向视图返回已绑定身份。
    return {"kind": "bound", "identity": identity}


def _login_verified_identity(request, login_transaction, verified_identity):
    # 输入：请求、已消费登录事务和已验证身份；输出：本地登录结果；调用者：身份解析服务；失败：解绑、归属变化、用户缺失或停用时原子拒绝。
    failure_code = ""
    locked_user = None
    digest = external_subject_digest(verified_identity.subject)
    # 数据库读取与锁顺序：先锁事务，再按“用户 -> 身份”顺序加锁；解绑使用同序，避免并发死锁。
    with transaction.atomic():
        locked_transaction = LoginTransaction.objects.select_for_update().get(
            pk=login_transaction.pk
        )

        # 先无锁读取当前归属，随后统一按“用户 -> 身份”顺序加锁。
        # 解绑流程也使用这个顺序，避免两个并发事务互相等待。
        candidate = (
            ExternalIdentity.objects.filter(
                provider=verified_identity.provider,
                subject_digest=digest,
            )
            .only("pk", "user_id")
            .first()
        )
        candidate_user_id = candidate.user_id if candidate is not None else None
        if candidate_user_id is not None:
            try:
                locked_user = User.objects.select_for_update().get(
                    pk=candidate_user_id
                )
            except User.DoesNotExist:
                locked_user = None

        identity = _find_or_create_identity(verified_identity)
        # 业务判断：锁定后的归属必须与候选读取一致，并且必须指向仍存在且激活的本地用户。
        if identity.user_id != candidate_user_id:
            failure_code = "identity_binding_changed"
        elif identity.user_id is None:
            failure_code = "identity_unbound"
        elif locked_user is None:
            failure_code = "identity_binding_changed"
        elif not locked_user.is_active:
            failure_code = "identity_user_inactive"
        else:
            identity.user = locked_user

        # 保存：身份归属必须与无锁候选读取一致；失败状态或展示资料更新和审计在同一事务提交。
        if failure_code:
            _set_transaction_result(
                locked_transaction,
                LoginTransactionStatus.FAILED,
                failure_code,
            )
            _audit(
                event_type=AuditEventType.LOGIN_FAILED,
                outcome=AuditOutcome.DENIED,
                target_user=locked_user,
                external_identity=identity,
                login_transaction=locked_transaction,
                provider=verified_identity.provider,
                reason_code=failure_code,
            )
        else:
            identity.display_name = verified_identity.display_name
            identity.email = verified_identity.email
            identity.save(update_fields=["display_name", "email", "last_seen_at"])
            _set_transaction_result(
                locked_transaction,
                LoginTransactionStatus.SUCCEEDED,
            )
            _audit(
                event_type=AuditEventType.LOGIN_SUCCEEDED,
                outcome=AuditOutcome.SUCCESS,
                actor=locked_user,
                target_user=locked_user,
                external_identity=identity,
                login_transaction=locked_transaction,
                provider=verified_identity.provider,
            )

    if failure_code:
        raise ExternalFlowError(failure_code, identity=identity)
    # 返回：只返回仍被锁定并确认激活的本地用户，真正写入登录 Session 由上层统一完成。
    return {"kind": "login", "user": locked_user, "identity": identity}


def unbind_external_identity(request, identity_id):
    # 输入：当前登录请求和待解绑身份主键；输出：已解绑身份；调用者：解绑视图；失败：停用、非本人或最后登录方式时失败关闭。
    # 业务判断：入口先拒绝匿名或停用账号，事务内还会在锁后再次检查。
    if not request.user.is_authenticated or not request.user.is_active:
        raise ExternalFlowError("account_inactive", status_code=403)

    failure_code = ""
    # 数据库读取与锁顺序：先锁用户，再按主键锁该用户全部身份；与登录流程的“用户 -> 身份”顺序一致。
    with transaction.atomic():
        user = User.objects.select_for_update().get(pk=request.user.pk)
        if not user.is_active:
            raise ExternalFlowError("account_inactive", status_code=403)
        identities = list(
            ExternalIdentity.objects.select_for_update()
            .filter(user=user)
            .order_by("pk")
        )
        identity = next((item for item in identities if item.pk == identity_id), None)
        if identity is None:
            raise ExternalFlowError("identity_not_owned", status_code=404)

        other_usable_identity_exists = any(
            item.pk != identity.pk and provider_is_available(item.provider)
            for item in identities
        )
        # 业务判断：没有可用密码时必须至少保留另一个当前可用 provider 身份，避免把用户永久锁在账号外。
        if not user.has_usable_password() and not other_usable_identity_exists:
            failure_code = "last_login_method"
            _audit(
                event_type=AuditEventType.IDENTITY_UNBOUND,
                outcome=AuditOutcome.DENIED,
                actor=user,
                target_user=user,
                external_identity=identity,
                provider=identity.provider,
                reason_code=failure_code,
            )
        else:
            # 保存：解绑只清空本地用户关系；保留 provider + subject 防止历史身份被误合并或被另一账号重新认领。
            identity.user = None
            identity.save(update_fields=["user", "last_seen_at"])
            _audit(
                event_type=AuditEventType.IDENTITY_UNBOUND,
                outcome=AuditOutcome.SUCCESS,
                actor=user,
                target_user=user,
                external_identity=identity,
                provider=identity.provider,
            )

    if failure_code:
        raise ExternalFlowError(failure_code)
    # 返回：身份历史行仍存在，仅 user 外键已原子清空并写入成功审计。
    return identity
