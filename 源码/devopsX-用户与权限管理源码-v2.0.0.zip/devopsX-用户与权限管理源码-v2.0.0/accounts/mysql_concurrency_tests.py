# accounts/mysql_concurrency_tests.py
# 保留旧教程路径，实际测试由默认发现规则可加载的模块承载。
from .test_mysql_concurrency import *
