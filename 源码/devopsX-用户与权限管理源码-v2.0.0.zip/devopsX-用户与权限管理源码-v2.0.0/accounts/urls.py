# accounts/urls.py
from django.contrib.auth import views as auth_views
from django.contrib.auth.decorators import login_required
from django.urls import path, reverse_lazy

from . import views
from .forms import LoginForm

app_name = "accounts"

urlpatterns = [
    # 首页视图自身要求 DASHBOARD_VIEW；空路径由项目根路由 include 后成为站点首页。
    path("", views.home, name="home"),
    # 本地密码登录使用自定义字段标签，但认证和 Session 轮换仍由 Django 内置视图负责。
    path(
        "login/",
        auth_views.LoginView.as_view(
            template_name="accounts/login.html",
            authentication_form=LoginForm,
            redirect_authenticated_user=True,
        ),
        name="login",
    ),
    path(
        "logout/",
        login_required(auth_views.LogoutView.as_view()),
        name="logout",
    ),
    path(
        "password/change/",
        login_required(
            auth_views.PasswordChangeView.as_view(
                template_name="accounts/password_change_form.html",
                success_url=reverse_lazy("accounts:password_change_done"),
            )
        ),
        name="password_change",
    ),
    path(
        "password/change/done/",
        login_required(
            auth_views.PasswordChangeDoneView.as_view(
                template_name="accounts/password_change_done.html"
            )
        ),
        name="password_change_done",
    ),
    # 用户、部门、角色和能力目录路由的授权边界由各视图的 capability_required 及事务内重验共同保证。
    path("users/", views.user_list, name="user_list"),
    path("users/create/", views.user_create, name="user_create"),
    path("users/<int:pk>/", views.user_detail, name="user_detail"),
    path("users/<int:pk>/edit/", views.user_update, name="user_update"),
    path("users/<int:pk>/access/", views.user_access, name="user_access"),
    path("users/<int:pk>/status/", views.user_status, name="user_status"),
    path("users/<int:pk>/delete/", views.user_delete, name="user_delete"),
    path("departments/", views.department_list, name="department_list"),
    path("departments/create/", views.department_create, name="department_create"),
    path("departments/<int:pk>/edit/", views.department_update, name="department_update"),
    path("departments/<int:pk>/delete/", views.department_delete, name="department_delete"),
    path("roles/", views.role_list, name="role_list"),
    path("roles/create/", views.role_create, name="role_create"),
    path("roles/<int:pk>/edit/", views.role_update, name="role_update"),
    path("roles/<int:pk>/delete/", views.role_delete, name="role_delete"),
    path("permissions/", views.permission_list, name="permission_list"),
    # start 只接受 POST；provider 仅作为注册表键，state、PKCE、nonce 与 Session 绑定均由服务层生成。
    path(
        "external/<str:provider>/start/",
        views.external_start,
        name="external_start",
    ),
    path(
        "external/<str:provider>/bind/",
        views.external_bind_start,
        name="external_bind_start",
    ),
    # callback 只接受 GET，并通过数据库行锁先消费事务；旧回调、跨 Session 回调和校验不符均失败关闭。
    path(
        "external/<str:provider>/callback/",
        views.external_callback,
        name="external_callback",
    ),
    # Fake 授权页仅用于本地教程；注册表和 settings 会在非 DEBUG 环境双重禁用。
    path("external/fake/authorize/", views.fake_authorize, name="fake_authorize"),
    # 身份列表只显示当前用户；解绑只接受 POST，并在服务层锁定用户和全部身份后保护最后登录方式。
    path(
        "external/identities/",
        views.external_identities,
        name="external_identities",
    ),
    path(
        "external/identities/<int:pk>/unbind/",
        views.external_identity_unbind,
        name="external_identity_unbind",
    ),
]
