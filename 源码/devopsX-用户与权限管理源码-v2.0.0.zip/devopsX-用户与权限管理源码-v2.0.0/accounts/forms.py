# accounts/forms.py
from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm

from .capabilities import ROLE_KEYS, ROLE_NAMES
from .models import Capability, Department, Role, RoleCapability, User, UserRole
from .policy import PolicySnapshot


def operator_capability_queryset(operator):
    # 输入：当前操作用户；输出：其可委派的启用能力 QuerySet；调用者：角色表单；失败：数据库读取异常向上抛出。
    # 数据库读取：超级用户取得全部启用能力，普通用户只取得策略快照中的能力。
    capabilities = Capability.objects.filter(is_active=True).order_by("key")
    if operator.is_active and operator.is_superuser:
        return capabilities
    capability_keys = PolicySnapshot(operator).capability_keys
    return capabilities.filter(key__in=capability_keys)


def role_capability_keys(role):
    # 输入：角色实例；输出：该角色全部关联能力编码集合；调用者：角色委派校验；失败：数据库读取异常向上抛出。
    # 停用能力也属于角色的潜在授权范围，不能借停用状态绕过委派边界。
    return set(
        RoleCapability.objects.filter(role=role).values_list(
            "capability__key", flat=True
        )
    )


# 兼容教程前文的命名；安全语义已经包含全部关联能力。
active_role_capability_keys = role_capability_keys


def assignable_role_queryset(operator):
    # 输入：当前操作用户；输出：能力集合不超过操作人的启用角色 QuerySet；调用者：用户角色表单和视图；失败：数据库读取异常向上抛出。
    # 数据库读取：先取得候选角色，再逐个比较完整能力集合，避免只看启用能力造成越权。
    roles = Role.objects.filter(is_active=True).order_by("name", "key")
    if operator.is_active and operator.is_superuser:
        return roles

    # 非超级用户只能向下授予自己能力集合的子集。
    operator_keys = PolicySnapshot(operator).capability_keys
    role_ids = []
    for role in roles:
        if role_capability_keys(role) <= operator_keys:
            role_ids.append(role.pk)
    return Role.objects.filter(pk__in=role_ids).order_by("name", "key")


def role_capabilities_within_limit(operator, role):
    # 输入：操作用户和目标角色；输出：角色能力是否为操作人能力子集；调用者：角色管理视图；失败：数据库读取异常向上抛出。
    if operator.is_active and operator.is_superuser:
        return True
    return role_capability_keys(role) <= PolicySnapshot(operator).capability_keys


class LoginForm(AuthenticationForm):
    username = forms.CharField(
        label="用户名",
        widget=forms.TextInput(attrs={"autofocus": True, "autocomplete": "username"}),
    )
    password = forms.CharField(
        label="密码",
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "current-password"}),
    )


class ExternalIdentityBindForm(forms.Form):
    identity = forms.ChoiceField(label="Fake 测试身份", choices=())
    password = forms.CharField(
        label="当前密码",
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "current-password"}),
    )

    def __init__(self, *args, user, identity_choices, **kwargs):
        # 输入：标准表单参数、当前用户和允许的 Fake 身份选项；输出：初始化绑定表单；调用者：绑定起点视图；失败：参数或父类初始化异常向上抛出。
        self.user = user
        super().__init__(*args, **kwargs)
        self.fields["identity"].choices = identity_choices

    def clean_password(self):
        # 输入：表单中的当前密码；输出：校验通过的原密码；调用者：Django 表单校验；失败：无可用密码或密码不匹配时抛 ValidationError。
        password = self.cleaned_data["password"]
        # 绑定新的外部身份属于敏感操作，不能只依赖一个长期未退出的浏览器 Session。
        if not self.user.has_usable_password() or not self.user.check_password(password):
            raise forms.ValidationError("当前密码不正确，不能绑定第三方身份。")
        return password


class FakeAuthorizeForm(forms.Form):
    identity = forms.CharField(widget=forms.HiddenInput)
    redirect_uri = forms.CharField(max_length=500, widget=forms.HiddenInput)
    state = forms.CharField(max_length=200, widget=forms.HiddenInput)
    code_challenge = forms.CharField(max_length=128, widget=forms.HiddenInput)
    nonce = forms.CharField(max_length=200, widget=forms.HiddenInput)
    transaction_id = forms.UUIDField(widget=forms.HiddenInput)
    decision = forms.ChoiceField(
        choices=(("approve", "同意"), ("deny", "拒绝")),
        widget=forms.RadioSelect,
    )


class UserCreateForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = User
        fields = (
            "username",
            "display_name",
            "employee_number",
            "email",
            "mobile",
            "department",
            "is_active",
        )


class UserUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = (
            "username",
            "display_name",
            "employee_number",
            "email",
            "mobile",
            "department",
        )


class UserAccessForm(forms.Form):
    roles = forms.ModelMultipleChoiceField(
        label="角色",
        queryset=Role.objects.none(),
        required=False,
        widget=forms.CheckboxSelectMultiple,
    )

    def __init__(self, *args, operator, instance=None, **kwargs):
        # 输入：标准表单参数、操作用户和可选目标用户；输出：初始化可分配角色及初值；调用者：用户角色管理视图；失败：数据库或父类初始化异常向上抛出。
        self.operator = operator
        self.instance = instance
        super().__init__(*args, **kwargs)
        self.fields["roles"].queryset = assignable_role_queryset(operator)
        if not self.is_bound and instance is not None and instance.pk:
            self.initial["roles"] = list(
                UserRole.objects.filter(user=instance).values_list("role_id", flat=True)
            )

    def clean_roles(self):
        # 输入：提交的角色集合；输出：验证后的 QuerySet；调用者：Django 表单校验；失败：含操作人不可授予角色时抛 ValidationError。
        # 数据库读取与业务判断：重新查询允许角色主键，拒绝篡改 POST 注入的越界角色。
        roles = self.cleaned_data["roles"]
        allowed_role_ids = set(
            assignable_role_queryset(self.operator).values_list("pk", flat=True)
        )
        submitted_role_ids = set(roles.values_list("pk", flat=True))
        if not submitted_role_ids <= allowed_role_ids:
            raise forms.ValidationError("不能分配能力范围高于自己的角色。")
        return roles

    def save(self):
        # 输入：已校验且带已保存目标用户的表单；输出：目标用户；调用者：用户角色管理视图的原子事务；失败：实例未保存时 ValueError，数据库错误向上抛出。
        if self.instance is None or not self.instance.pk:
            raise ValueError("保存用户角色前必须提供已保存的用户。")

        roles = list(self.cleaned_data["roles"])
        # 保存：调用视图已在事务内锁定旧关联；这里先删除再创建，明确表达“本次提交完全替换旧角色”。
        UserRole.objects.filter(user=self.instance).delete()
        UserRole.objects.bulk_create(
            [
                UserRole(
                    user=self.instance,
                    role=role,
                    assigned_by=self.operator,
                )
                for role in roles
            ]
        )
        # 返回：角色关联已按提交集合替换，用户对象本身未再次保存。
        return self.instance


class DepartmentForm(forms.ModelForm):
    class Meta:
        model = Department
        fields = ("code", "name", "parent", "is_active", "sort_order")

    def __init__(self, *args, **kwargs):
        # 输入：标准 ModelForm 参数；输出：排除自身的父部门候选表单；调用者：部门创建/编辑视图；失败：数据库或父类初始化异常向上抛出。
        super().__init__(*args, **kwargs)
        # 数据库读取：编辑时排除当前部门，完整环路仍由模型 clean() 检查。
        queryset = Department.objects.order_by("sort_order", "code")
        if self.instance.pk:
            queryset = queryset.exclude(pk=self.instance.pk)
        self.fields["parent"].queryset = queryset


class RoleForm(forms.ModelForm):
    capabilities = forms.ModelMultipleChoiceField(
        label="包含的能力",
        queryset=Capability.objects.none(),
        required=False,
        widget=forms.CheckboxSelectMultiple,
    )

    class Meta:
        model = Role
        fields = ("key", "name", "description", "is_active", "capabilities")
        labels = {
            "key": "角色编码",
            "name": "角色名称",
            "description": "说明",
            "is_active": "启用",
        }

    def __init__(self, *args, operator, **kwargs):
        # 输入：标准 ModelForm 参数和操作用户；输出：仅含可委派能力的角色表单；调用者：角色创建/编辑视图；失败：数据库或父类初始化异常向上抛出。
        self.operator = operator
        super().__init__(*args, **kwargs)
        # 数据库读取：选项限制为操作人能力；编辑时回填当前启用能力，系统角色编码只读。
        self.fields["capabilities"].queryset = operator_capability_queryset(operator)
        if self.instance.pk:
            self.initial["capabilities"] = list(
                RoleCapability.objects.filter(
                    role=self.instance,
                    capability__is_active=True,
                ).values_list("capability_id", flat=True)
            )
        if self.instance.pk and self.instance.is_system:
            # 系统角色的稳定编码不能被表单改名。
            self.fields["key"].disabled = True

    def clean_key(self):
        # 输入：提交的角色编码；输出：去空格并转小写的编码；调用者：Django 表单校验；失败：非现有系统角色占用保留键时抛 ValidationError。
        key = self.cleaned_data["key"].strip().lower()
        is_existing_system_key = (
            self.instance.pk
            and self.instance.is_system
            and self.instance.key == key
        )
        if key in ROLE_KEYS and not is_existing_system_key:
            raise forms.ValidationError("该角色编码由系统内置角色保留。")
        return key

    def clean_name(self):
        # 输入：提交的角色名称；输出：去除首尾空格的名称；调用者：Django 表单校验；失败：非现有系统角色占用保留名称时抛 ValidationError。
        name = self.cleaned_data["name"].strip()
        is_existing_system_name = (
            self.instance.pk
            and self.instance.is_system
            and self.instance.name == name
        )
        if name in ROLE_NAMES and not is_existing_system_name:
            raise forms.ValidationError("该角色名称由系统内置角色保留。")
        return name

    def clean_capabilities(self):
        # 输入：提交的能力集合；输出：验证后的 QuerySet；调用者：Django 表单校验；失败：含操作人不具备的能力时抛 ValidationError。
        # 数据库读取与业务判断：重新查询允许能力主键，拒绝通过篡改 POST 扩大角色权限。
        capabilities = self.cleaned_data["capabilities"]
        allowed_ids = set(
            operator_capability_queryset(self.operator).values_list("pk", flat=True)
        )
        submitted_ids = set(capabilities.values_list("pk", flat=True))
        if not submitted_ids <= allowed_ids:
            raise forms.ValidationError("不能把自己不具备的能力加入角色。")
        return capabilities

    def save(self, commit=True):
        # 输入：已校验角色表单及 commit 开关；输出：角色实例；调用者：角色管理视图；失败：数据库写入异常向上抛出并由外层事务回滚。
        role = super().save(commit=commit)
        if not commit:
            return role

        capabilities = list(self.cleaned_data["capabilities"])
        # 保存：调用视图已锁目录；显式替换中间模型才能记录分配人并保持写入路径清晰。
        RoleCapability.objects.filter(role=role).delete()
        RoleCapability.objects.bulk_create(
            [
                RoleCapability(
                    role=role,
                    capability=capability,
                    assigned_by=self.operator,
                )
                for capability in capabilities
            ]
        )
        # 返回：角色及其能力关联已按表单内容保存。
        return role
