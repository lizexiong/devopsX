# accounts/views.py
import uuid
from urllib.parse import urlencode

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.core.exceptions import PermissionDenied
from django.db import transaction
from django.db.models import Count, Q
from django.db.models.deletion import ProtectedError
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_http_methods, require_POST

from .capabilities import (
    CAPABILITY_VIEW,
    DASHBOARD_VIEW,
    DEPARTMENT_MANAGE,
    DEPARTMENT_VIEW,
    ROLE_MANAGE,
    ROLE_VIEW,
    USER_ASSIGN_ROLE,
    USER_CHANGE,
    USER_CREATE,
    USER_DELETE,
    USER_STATUS,
    USER_VIEW,
)
from .decorators import capability_required
from .forms import (
    DepartmentForm,
    ExternalIdentityBindForm,
    FakeAuthorizeForm,
    RoleForm,
    UserAccessForm,
    UserCreateForm,
    UserUpdateForm,
    assignable_role_queryset,
    role_capabilities_within_limit,
)
from .identity import (
    ExternalFlowError,
    SESSION_IDENTITY_HINT_KEY,
    SESSION_STATE_KEY,
    SESSION_TRANSACTION_KEY,
    expected_redirect_uri,
    finish_external_callback,
    reject_external_callback,
    start_external_flow,
    unbind_external_identity,
)
from .models import (
    Capability,
    Department,
    ExternalIdentity,
    IdentityProvider,
    LoginIntent,
    Role,
    RoleCapability,
    User,
    UserRole,
)
from .policy import require_capability
from .providers import get_provider
from .providers.base import ProviderUnavailable
from .providers.fake import FAKE_IDENTITIES


@capability_required(DASHBOARD_VIEW)
def home(request):
    # 输入：已通过首页能力校验的请求；输出：首页 HttpResponse；调用者：根路由；失败：未登录或缺能力由装饰器处理。
    return render(request, "accounts/home.html")


def _deny_non_superuser_managing_superuser(operator, user_obj):
    # 输入：操作用户和目标用户；输出：无返回值；调用者：用户编辑、状态和删除视图；失败：普通用户操作超级用户时抛 PermissionDenied。
    if user_obj.is_superuser and not operator.is_superuser:
        raise PermissionDenied("只有超级用户可以修改超级用户账号。")


def _locked_active_superuser_ids():
    # 输入：无；输出：已按主键锁定的激活超级用户 ID 列表；调用者：状态和删除事务；失败：数据库锁或读取异常向上抛出。
    # 先锁定整个集合，再判断最后一个，避免并发请求同时通过检查。
    return list(
        User.objects.select_for_update()
        .filter(is_superuser=True, is_active=True)
        .order_by("pk")
        .values_list("pk", flat=True)
    )


def _last_active_superuser(user_obj, active_superuser_ids):
    # 输入：目标用户和锁定后的激活超级用户 ID；输出：目标是否为最后一个激活超级用户；调用者：状态和删除视图；失败：无特殊失败路径。
    return (
        user_obj.is_superuser
        and user_obj.is_active
        and len(active_superuser_ids) <= 1
    )


def _lock_role_catalog():
    # 输入：无；输出：已锁定角色 ID 列表；调用者：所有权限敏感写事务；失败：数据库锁或读取异常向上抛出。
    # 数据库读取：固定按“角色 -> 能力 -> 角色能力”顺序加锁，与 bootstrap 命令保持一致以避免死锁。
    # 角色、能力和关联行一起加锁，提交时重新计算可授予范围。
    role_ids = list(
        Role.objects.select_for_update().order_by("pk").values_list("pk", flat=True)
    )
    list(
        Capability.objects.select_for_update()
        .order_by("pk")
        .values_list("pk", flat=True)
    )
    list(
        RoleCapability.objects.select_for_update()
        .order_by("pk")
        .values_list("pk", flat=True)
    )
    return role_ids


def _require_locked_capability(operator, capability_key):
    # 输入：事务内重新锁定的操作用户和能力键；输出：无返回值；调用者：权限敏感写视图；失败：锁后已失权时抛 PermissionDenied。
    # 装饰器只负责快速拒绝，事务内必须使用锁后账号重新检查。
    require_capability(operator, capability_key)


def _deny_role_outside_capability_limit(operator, role):
    # 输入：操作用户和目标角色；输出：无返回值；调用者：角色编辑/删除视图；失败：角色能力超出操作人边界时抛 PermissionDenied。
    if not role_capabilities_within_limit(operator, role):
        raise PermissionDenied("不能管理能力范围高于自己的角色。")


def _deny_editing_system_role(role):
    # 输入：目标角色；输出：无返回值；调用者：角色编辑/删除视图；失败：系统角色时抛 PermissionDenied。
    # 系统角色来自代码目录，只能由 bootstrap_rbac 精确同步。
    # 网页若允许编辑，下一次初始化会覆盖修改，也可能造成短暂越权或目录漂移。
    if role.is_system:
        raise PermissionDenied("系统内置角色只能通过初始化命令维护。")


def _deny_editing_own_role(operator, role):
    # 输入：操作用户和目标角色；输出：无返回值；调用者：角色编辑/删除视图；失败：普通用户管理自己持有的角色时抛 PermissionDenied。
    if operator.is_active and operator.is_superuser:
        return
    if UserRole.objects.filter(user=operator, role=role).exists():
        # 禁止把临时获得的能力固化到自己的长期角色中。
        raise PermissionDenied("不能编辑当前账号已经持有的角色。")


def _deny_user_roles_outside_capability_limit(operator, user_obj):
    # 输入：操作用户和目标用户；输出：无返回值；调用者：用户角色管理视图；失败：目标含不可委派角色时抛 PermissionDenied。
    if operator.is_active and operator.is_superuser:
        return
    allowed_role_ids = set(
        assignable_role_queryset(operator).values_list("pk", flat=True)
    )
    existing_role_ids = set(
        UserRole.objects.filter(user=user_obj).values_list("role_id", flat=True)
    )
    # 不能借“替换角色”删除自己无权授予的高权限或停用角色。
    if not existing_role_ids <= allowed_role_ids:
        raise PermissionDenied("目标用户包含当前账号无权管理的角色。")


def _locked_users(operator_id, target_id):
    # 输入：操作用户与目标用户 ID；输出：按主键锁定的用户字典；调用者：用户写事务；失败：数据库锁或读取异常向上抛出。
    # 锁顺序：对两个 ID 排序后统一加锁，避免相反方向的并发操作形成死锁。
    ids = sorted({operator_id, target_id})
    return {
        user.pk: user
        for user in User.objects.select_for_update().filter(pk__in=ids).order_by("pk")
    }


def _lock_user_roles(user_ids):
    # 输入：需要保护的用户 ID 集合；输出：已锁定的 UserRole 主键列表；调用者：用户和权限写事务；失败：数据库锁或读取异常向上抛出。
    # 锁住能力来源，防止事务重检后角色又被并发替换。
    return list(
        UserRole.objects.select_for_update()
        .filter(user_id__in=sorted(set(user_ids)))
        .order_by("pk")
        .values_list("pk", flat=True)
    )


@capability_required(USER_VIEW)
def user_list(request):
    # 输入：带可选关键字、部门、状态和页码的请求；输出：分页用户列表响应；调用者：用户列表路由；失败：缺能力 403，非法筛选值安全忽略。
    # 数据库读取：预取部门和项目角色，避免模板逐行触发额外查询。
    users = User.objects.select_related("department").prefetch_related(
        "user_roles__role"
    )
    keyword = request.GET.get("q", "").strip()
    department_id = request.GET.get("department", "").strip()
    status = request.GET.get("status", "").strip()

    # 业务判断：文本使用受控 ORM 查询；部门主键只接受正的 64 位十进制，避免异常或超大整数进入查询。
    if keyword:
        users = users.filter(
            Q(username__icontains=keyword)
            | Q(display_name__icontains=keyword)
            | Q(employee_number__icontains=keyword)
            | Q(email__icontains=keyword)
            | Q(mobile__icontains=keyword)
        )
    department_pk = None
    if department_id.isascii() and department_id.isdecimal() and len(department_id) <= 19:
        candidate = int(department_id)
        if 0 < candidate <= 9223372036854775807:
            department_pk = candidate

    if department_pk is not None:
        users = users.filter(department_id=department_pk)
        department_id = str(department_pk)
    else:
        department_id = ""
    if status == "active":
        users = users.filter(is_active=True)
    elif status == "inactive":
        users = users.filter(is_active=False)

    page_obj = Paginator(users.order_by("username"), 10).get_page(request.GET.get("page"))
    context = {
        "page_obj": page_obj,
        "departments": Department.objects.filter(is_active=True),
        "keyword": keyword,
        "selected_department": department_id,
        "selected_status": status,
    }
    # 返回：查询在分页和模板渲染时执行，筛选值同时回显给页面。
    return render(request, "accounts/user_list.html", context)


@capability_required(USER_VIEW)
def user_detail(request, pk):
    # 输入：请求和用户主键；输出：用户详情响应；调用者：用户详情路由；失败：缺能力 403 或目标不存在 404。
    # 数据库读取：一次加载部门并预取角色，供详情模板只读展示。
    user_obj = get_object_or_404(
        User.objects.select_related("department").prefetch_related("user_roles__role"),
        pk=pk,
    )
    return render(request, "accounts/user_detail.html", {"user_obj": user_obj})


@capability_required(USER_CREATE)
@require_http_methods(["GET", "POST"])
def user_create(request):
    # 输入：GET 或用户创建 POST；输出：表单响应或成功重定向；调用者：用户创建路由；失败：方法、能力、表单或数据库错误按 Django 机制处理。
    form = UserCreateForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        # 数据库读取与锁定：固定锁目录、操作人及其角色来源，再在锁后重验创建能力。
        with transaction.atomic():
            _lock_role_catalog()
            operator = User.objects.select_for_update().get(pk=request.user.pk)
            _lock_user_roles([operator.pk])
            _require_locked_capability(operator, USER_CREATE)
            # 业务判断与保存：锁后重建并重验表单，防止等待锁期间权限或提交关联条件变化。
            locked_form = UserCreateForm(request.POST)
            if locked_form.is_valid():
                user_obj = locked_form.save()
                messages.success(request, "用户“%s”已创建。" % user_obj)
                return redirect("accounts:user_detail", pk=user_obj.pk)
            form = locked_form
    # 返回：GET 或校验失败时渲染表单，成功路径已在原子提交后重定向。
    return render(request, "accounts/user_form.html", {"form": form, "title": "新建用户"})


@capability_required(USER_CHANGE)
@require_http_methods(["GET", "POST"])
def user_update(request, pk):
    # 输入：GET/POST 请求和目标用户主键；输出：编辑表单或成功重定向；调用者：用户编辑路由；失败：越权 403、目标不存在 404 或表单错误。
    # 数据库读取：先做页面级存在与超级用户边界检查，提交时会重新锁定并复查。
    user_obj = get_object_or_404(User, pk=pk)
    _deny_non_superuser_managing_superuser(request.user, user_obj)
    form = UserUpdateForm(request.POST or None, instance=user_obj)
    if request.method == "POST" and form.is_valid():
        # 数据库读取与锁定：锁目录和排序后的操作人/目标用户，再锁操作人角色来源并重验能力。
        with transaction.atomic():
            _lock_role_catalog()
            locked_users = _locked_users(request.user.pk, pk)
            operator = locked_users[request.user.pk]
            user_obj = locked_users.get(pk)
            if user_obj is None:
                raise PermissionDenied("目标用户已不存在。")
            _lock_user_roles([operator.pk])
            _require_locked_capability(operator, USER_CHANGE)
            _deny_non_superuser_managing_superuser(operator, user_obj)
            # 业务判断与保存：基于锁后实例重建表单，避免用锁前对象覆盖并发修改。
            locked_form = UserUpdateForm(request.POST, instance=user_obj)
            if locked_form.is_valid():
                user_obj = locked_form.save()
                messages.success(request, "用户“%s”已更新。" % user_obj)
                return redirect("accounts:user_detail", pk=user_obj.pk)
            form = locked_form
    # 返回：GET 或校验失败时渲染锁前/锁后对应表单，成功路径已重定向。
    return render(
        request,
        "accounts/user_form.html",
        {"form": form, "title": "编辑用户", "user_obj": user_obj},
    )


@capability_required(USER_ASSIGN_ROLE)
@require_http_methods(["GET", "POST"])
def user_access(request, pk):
    # 输入：GET/POST 请求和目标用户主键；输出：角色表单或成功重定向；调用者：用户角色路由；失败：自改、越权、目标缺失或表单错误。
    # 数据库读取与业务判断：页面入口先拒绝自改、超级用户边界及目标已有的不可管理角色。
    user_obj = get_object_or_404(User, pk=pk)
    if user_obj.pk == request.user.pk:
        messages.error(request, "不能修改自己的角色。")
        return redirect("accounts:user_detail", pk=user_obj.pk)
    _deny_non_superuser_managing_superuser(request.user, user_obj)
    _deny_user_roles_outside_capability_limit(request.user, user_obj)

    form = UserAccessForm(
        request.POST if request.method == "POST" else None,
        instance=user_obj,
        operator=request.user,
    )
    if request.method == "POST" and form.is_valid():
        # 锁顺序：目录 -> 排序用户 -> 操作人和目标的角色关联；锁后重新计算授权边界。
        with transaction.atomic():
            _lock_role_catalog()
            locked_users = _locked_users(request.user.pk, user_obj.pk)
            operator = locked_users[request.user.pk]
            user_obj = locked_users.get(user_obj.pk)
            if user_obj is None:
                raise PermissionDenied("目标用户已不存在。")
            _lock_user_roles([operator.pk, user_obj.pk])
            _require_locked_capability(operator, USER_ASSIGN_ROLE)
            if user_obj.pk == operator.pk:
                messages.error(request, "不能修改自己的角色。")
                return redirect("accounts:user_detail", pk=user_obj.pk)
            _deny_non_superuser_managing_superuser(operator, user_obj)
            _deny_user_roles_outside_capability_limit(operator, user_obj)
            # 保存：旧关联已加锁，锁后表单再次限制可授予角色，完整替换不会与另一分配请求交错。
            locked_form = UserAccessForm(
                request.POST,
                instance=user_obj,
                operator=operator,
            )
            if locked_form.is_valid():
                locked_form.save()
                messages.success(request, "用户“%s”的角色已更新。" % user_obj)
                return redirect("accounts:user_detail", pk=user_obj.pk)
            form = locked_form

    # 返回：GET 或校验失败时展示当前可管理角色集合；成功路径已提交并重定向。
    return render(
        request,
        "accounts/user_access_form.html",
        {"form": form, "user_obj": user_obj},
    )


@capability_required(USER_STATUS)
@require_POST
def user_status(request, pk):
    # 输入：POST 请求和目标用户主键；输出：详情页重定向；调用者：用户状态路由；失败：缺能力、自改、超级用户边界或最后超级用户时拒绝。
    # 锁顺序：目录 -> 全部激活超级用户 -> 排序用户 -> 操作人角色，保证“最后一个”判断并发安全。
    with transaction.atomic():
        _lock_role_catalog()
        active_superuser_ids = _locked_active_superuser_ids()
        locked_users = _locked_users(request.user.pk, pk)
        operator = locked_users[request.user.pk]
        user_obj = locked_users.get(pk)
        if user_obj is None:
            user_obj = get_object_or_404(User, pk=pk)
        _lock_user_roles([operator.pk])
        _require_locked_capability(operator, USER_STATUS)
        _deny_non_superuser_managing_superuser(operator, user_obj)
        if user_obj.pk == operator.pk:
            messages.error(request, "不能停用或变更自己的登录状态。")
        elif user_obj.is_active and _last_active_superuser(user_obj, active_superuser_ids):
            messages.error(request, "不能停用最后一个激活的超级用户。")
        else:
            # 保存：只切换 is_active，锁后能力与最后超级用户检查通过后才写入。
            user_obj.is_active = not user_obj.is_active
            user_obj.save(update_fields=["is_active"])
            state = "启用" if user_obj.is_active else "停用"
            messages.success(request, "用户“%s”已%s。" % (user_obj, state))
    # 返回：无论切换或业务拒绝都回到目标详情页，事务退出后锁释放。
    return redirect("accounts:user_detail", pk=pk)


@capability_required(USER_DELETE)
@require_http_methods(["GET", "POST"])
def user_delete(request, pk):
    # 输入：GET/POST 请求和目标用户主键；输出：确认页或列表/详情重定向；调用者：用户删除路由；失败：自删、超级用户边界或最后超级用户时拒绝。
    if request.method == "POST":
        # 锁顺序：目录 -> 激活超级用户 -> 排序用户 -> 操作人角色，删除前在锁后重验全部条件。
        with transaction.atomic():
            _lock_role_catalog()
            active_superuser_ids = _locked_active_superuser_ids()
            locked_users = _locked_users(request.user.pk, pk)
            operator = locked_users[request.user.pk]
            user_obj = locked_users.get(pk)
            if user_obj is None:
                user_obj = get_object_or_404(User, pk=pk)
            _lock_user_roles([operator.pk])
            _require_locked_capability(operator, USER_DELETE)
            _deny_non_superuser_managing_superuser(operator, user_obj)
            if user_obj.pk == operator.pk:
                messages.error(request, "不能删除自己。")
                return redirect("accounts:user_detail", pk=user_obj.pk)
            if _last_active_superuser(user_obj, active_superuser_ids):
                messages.error(request, "不能删除最后一个激活的超级用户。")
                return redirect("accounts:user_detail", pk=user_obj.pk)
            label = str(user_obj)
            # 保存：所有并发安全检查通过后删除用户，相关 CASCADE/SET_NULL/PROTECT 语义由模型约束执行。
            user_obj.delete()
        messages.success(request, "用户“%s”已删除。" % label)
        return redirect("accounts:user_list")

    # 返回：GET 只读取目标并展示确认页，仍先执行超级用户管理边界检查。
    user_obj = get_object_or_404(User, pk=pk)
    _deny_non_superuser_managing_superuser(request.user, user_obj)
    return render(request, "accounts/user_confirm_delete.html", {"user_obj": user_obj})


@capability_required(DEPARTMENT_VIEW)
def department_list(request):
    # 输入：已通过部门查看能力校验的请求；输出：带统计的部门列表响应；调用者：部门列表路由；失败：缺能力 403 或数据库读取异常。
    # 数据库读取：关联父部门并在数据库聚合子部门数和用户数。
    departments = Department.objects.select_related("parent").annotate(
        child_count=Count("children", distinct=True),
        user_count=Count("users", distinct=True),
    )
    return render(request, "accounts/department_list.html", {"departments": departments})


@capability_required(DEPARTMENT_MANAGE)
@require_http_methods(["GET", "POST"])
def department_create(request):
    # 输入：GET 或部门创建 POST；输出：表单响应或列表重定向；调用者：部门创建路由；失败：方法、能力、模型层级或数据库校验失败。
    form = DepartmentForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        # 数据库读取与锁定：锁权限目录、操作人及其角色来源，再锁后重验部门管理能力。
        with transaction.atomic():
            _lock_role_catalog()
            operator = User.objects.select_for_update().get(pk=request.user.pk)
            _lock_user_roles([operator.pk])
            _require_locked_capability(operator, DEPARTMENT_MANAGE)
            # 业务判断与保存：锁后重建表单并执行模型 clean()，通过后才创建部门。
            locked_form = DepartmentForm(request.POST)
            if locked_form.is_valid():
                department = locked_form.save()
                messages.success(request, "部门“%s”已创建。" % department)
                return redirect("accounts:department_list")
            form = locked_form
    # 返回：GET 或校验失败时展示表单；成功路径在事务提交后重定向。
    return render(request, "accounts/department_form.html", {"form": form, "title": "新建部门"})


@capability_required(DEPARTMENT_MANAGE)
@require_http_methods(["GET", "POST"])
def department_update(request, pk):
    # 输入：GET/POST 请求和部门主键；输出：编辑表单或列表重定向；调用者：部门编辑路由；失败：目标不存在、能力或层级校验失败。
    # 数据库读取：先加载展示实例，提交时会重新锁定目标部门。
    department = get_object_or_404(Department, pk=pk)
    form = DepartmentForm(request.POST or None, instance=department)
    if request.method == "POST" and form.is_valid():
        # 锁顺序：权限目录 -> 操作人 -> 操作人角色 -> 目标部门；锁后重验能力和表单。
        with transaction.atomic():
            _lock_role_catalog()
            operator = User.objects.select_for_update().get(pk=request.user.pk)
            _lock_user_roles([operator.pk])
            _require_locked_capability(operator, DEPARTMENT_MANAGE)
            department = get_object_or_404(
                Department.objects.select_for_update(),
                pk=pk,
            )
            # 业务判断与保存：基于锁后部门实例重新校验父链，避免并发层级变化造成环。
            locked_form = DepartmentForm(request.POST, instance=department)
            if locked_form.is_valid():
                department = locked_form.save()
                messages.success(request, "部门“%s”已更新。" % department)
                return redirect("accounts:department_list")
            form = locked_form
    # 返回：GET 或校验失败时展示表单，成功路径已提交并重定向。
    return render(
        request,
        "accounts/department_form.html",
        {"form": form, "title": "编辑部门", "department": department},
    )


@capability_required(DEPARTMENT_MANAGE)
@require_http_methods(["GET", "POST"])
def department_delete(request, pk):
    # 输入：GET/POST 请求和部门主键；输出：确认页或列表重定向；调用者：部门删除路由；失败：目标不存在、仍被引用或能力不足时拒绝。
    department = get_object_or_404(Department, pk=pk)
    if request.method == "POST":
        # 锁顺序：权限目录 -> 操作人 -> 操作人角色 -> 目标部门；锁后重验权限和引用情况。
        with transaction.atomic():
            _lock_role_catalog()
            operator = User.objects.select_for_update().get(pk=request.user.pk)
            _lock_user_roles([operator.pk])
            _require_locked_capability(operator, DEPARTMENT_MANAGE)
            department = get_object_or_404(
                Department.objects.select_for_update(),
                pk=pk,
            )
            if department.children.exists() or department.users.exists():
                messages.error(request, "该部门仍有子部门或用户，不能删除。")
                return redirect("accounts:department_list")
            label = str(department)
            # 保存：显式检查后仍捕获数据库 PROTECT 竞争，防止检查与删除之间新增引用导致未处理异常。
            try:
                department.delete()
            except ProtectedError:
                messages.error(request, "该部门仍被其他数据引用，不能删除。")
            else:
                messages.success(request, "部门“%s”已删除。" % label)
            return redirect("accounts:department_list")
    # 返回：GET 展示确认页；POST 无论成功或被引用都回列表。
    return render(
        request,
        "accounts/department_confirm_delete.html",
        {"department": department},
    )


@capability_required(ROLE_VIEW)
def role_list(request):
    # 输入：已通过角色查看能力校验的请求；输出：角色列表响应；调用者：角色列表路由；失败：缺能力 403 或数据库读取异常。
    # 数据库读取：聚合用户数并预取角色能力，避免模板逐角色查询。
    roles = Role.objects.annotate(user_count=Count("user_roles", distinct=True)).prefetch_related(
        "role_capabilities__capability"
    )
    return render(request, "accounts/role_list.html", {"roles": roles.order_by("name", "key")})


@capability_required(ROLE_MANAGE)
@require_http_methods(["GET", "POST"])
def role_create(request):
    # 输入：GET 或角色创建 POST；输出：表单响应或列表重定向；调用者：角色创建路由；失败：能力委派、保留键、表单或数据库校验失败。
    form = RoleForm(request.POST or None, operator=request.user)
    if request.method == "POST" and form.is_valid():
        # 锁顺序：完整权限目录 -> 操作人 -> 操作人角色；锁后重验角色管理能力和可委派能力。
        with transaction.atomic():
            _lock_role_catalog()
            operator = User.objects.select_for_update().get(pk=request.user.pk)
            _lock_user_roles([operator.pk])
            _require_locked_capability(operator, ROLE_MANAGE)
            # 业务判断与保存：用锁后操作人重建表单，角色及中间关联在同一外层事务写入。
            locked_form = RoleForm(request.POST, operator=operator)
            if locked_form.is_valid():
                role = locked_form.save()
                messages.success(request, "角色“%s”已创建。" % role.name)
                return redirect("accounts:role_list")
            form = locked_form
    # 返回：GET 或校验失败时展示表单；成功路径在事务提交后重定向。
    return render(request, "accounts/role_form.html", {"form": form, "title": "新建角色"})


@capability_required(ROLE_MANAGE)
@require_http_methods(["GET", "POST"])
def role_update(request, pk):
    # 输入：GET/POST 请求和角色主键；输出：编辑表单或列表重定向；调用者：角色编辑路由；失败：系统角色、自持角色、能力越界或目标缺失时拒绝。
    # 数据库读取与业务判断：入口先检查显示对象，提交时会在锁后全部复查。
    role = get_object_or_404(Role, pk=pk)
    _deny_editing_system_role(role)
    _deny_role_outside_capability_limit(request.user, role)
    _deny_editing_own_role(request.user, role)
    form = RoleForm(request.POST or None, instance=role, operator=request.user)
    if request.method == "POST" and form.is_valid():
        # 锁顺序：权限目录 -> 操作人 -> 操作人角色 -> 目标角色，锁后重验全部委派边界。
        with transaction.atomic():
            _lock_role_catalog()
            operator = User.objects.select_for_update().get(pk=request.user.pk)
            _lock_user_roles([operator.pk])
            _require_locked_capability(operator, ROLE_MANAGE)
            role = get_object_or_404(Role.objects.select_for_update(), pk=pk)
            _deny_editing_system_role(role)
            _deny_role_outside_capability_limit(operator, role)
            _deny_editing_own_role(operator, role)
            # 保存：基于锁后角色和操作人重建表单，角色字段与能力关联在同一事务替换。
            locked_form = RoleForm(request.POST, instance=role, operator=operator)
            if locked_form.is_valid():
                role = locked_form.save()
                messages.success(request, "角色“%s”已更新。" % role.name)
                return redirect("accounts:role_list")
            form = locked_form
    # 返回：GET 或校验失败时展示表单；成功路径已提交并重定向。
    return render(
        request,
        "accounts/role_form.html",
        {"form": form, "title": "编辑角色", "role": role},
    )


@capability_required(ROLE_MANAGE)
@require_http_methods(["GET", "POST"])
def role_delete(request, pk):
    # 输入：GET/POST 请求和角色主键；输出：确认页或列表重定向；调用者：角色删除路由；失败：系统角色、自持角色、能力越界、仍有成员或目标缺失时拒绝。
    # 数据库读取与业务判断：入口检查页面对象，提交时在锁后重新执行全部限制。
    role = get_object_or_404(Role, pk=pk)
    _deny_editing_system_role(role)
    _deny_role_outside_capability_limit(request.user, role)
    _deny_editing_own_role(request.user, role)
    if request.method == "POST":
        # 锁顺序：权限目录 -> 操作人 -> 操作人角色 -> 目标角色，防止检查后权限或角色内容并发变化。
        with transaction.atomic():
            _lock_role_catalog()
            operator = User.objects.select_for_update().get(pk=request.user.pk)
            _lock_user_roles([operator.pk])
            _require_locked_capability(operator, ROLE_MANAGE)
            role = get_object_or_404(Role.objects.select_for_update(), pk=pk)
            _deny_editing_system_role(role)
            _deny_role_outside_capability_limit(operator, role)
            _deny_editing_own_role(operator, role)
            if role.user_roles.exists():
                messages.error(request, "该角色仍有已分配用户，不能删除。")
                return redirect("accounts:role_list")
            label = role.name
            # 保存：锁后确认无成员才删除，RoleCapability 关联按 CASCADE 一并删除。
            role.delete()
        messages.success(request, "角色“%s”已删除。" % label)
        return redirect("accounts:role_list")
    # 返回：GET 展示确认页，POST 成功或业务拒绝按分支重定向。
    return render(request, "accounts/role_confirm_delete.html", {"role": role})


@capability_required(CAPABILITY_VIEW)
def permission_list(request):
    # 输入：带可选 app_label 和关键字的请求；输出：只读能力目录响应；调用者：能力列表路由；失败：缺能力 403，未知应用标签返回空集。
    # 数据库读取：能力目录只来自项目自有 Capability，不混入 Django auth.Permission。
    capabilities = Capability.objects.all()
    app_label = request.GET.get("app_label", "").strip()
    keyword = request.GET.get("q", "").strip()
    if app_label and app_label != "accounts":
        capabilities = capabilities.none()
    if keyword:
        capabilities = capabilities.filter(
            Q(key__icontains=keyword)
            | Q(name__icontains=keyword)
            | Q(description__icontains=keyword)
        )
    context = {
        "capabilities": capabilities.order_by("key"),
        "app_labels": ["accounts"],
        "selected_app_label": app_label,
        "keyword": keyword,
    }
    return render(request, "accounts/permission_list.html", context)


def _external_flow_error_response(request, error):
    # 输入：当前请求和安全 ExternalFlowError；输出：统一失败响应；调用者：登录、绑定和回调视图；失败：匿名用户不回显身份，避免泄露绑定状态。
    # 业务判断：仅向已登录用户显示相关身份，并只为已知 Fake 身份生成重新绑定提示。
    visible_identity = error.identity if request.user.is_authenticated else None
    identity_hint = ""
    if visible_identity is not None and visible_identity.provider == IdentityProvider.FAKE:
        for hint, data in FAKE_IDENTITIES.items():
            if data["subject"] == visible_identity.subject:
                identity_hint = hint
                break
    # 返回：无论失败原因来自哪一层，都使用同一模板和安全文案，只保留允许当前用户看到的字段。
    return render(
        request,
        "accounts/external_identity_result.html",
        {
            "success": False,
            "message": "外部身份流程未完成。请重新开始登录或绑定，不要重复提交旧回调。",
            "identity": visible_identity,
            "identity_hint": identity_hint,
            "can_bind": bool(
                visible_identity is not None
                and visible_identity.user_id is None
                and request.user.is_authenticated
                and request.user.is_active
                and identity_hint
            ),
        },
        status=error.status_code,
    )


@require_POST
def external_start(request, provider):
    # 输入：未登录用户的 POST 和 provider 路由键；输出：授权跳转或统一失败页；调用者：第三方登录起点路由；失败：已登录、未配置或流程参数错误时失败关闭。
    # Session 绑定、state、PKCE 和 nonce 的生成与持久化由 start_external_flow 统一完成，视图不自行接受回调地址。
    if request.user.is_authenticated:
        messages.info(request, "当前账号已经登录，如需切换账号请先退出。")
        return redirect("accounts:home")
    try:
        location = start_external_flow(
            request,
            provider,
            LoginIntent.LOGIN,
            identity_hint=request.POST.get("identity", ""),
        )
    except (ExternalFlowError, ProviderUnavailable) as error:
        if isinstance(error, ProviderUnavailable):
            error = ExternalFlowError("provider_unavailable")
        return _external_flow_error_response(request, error)
    return HttpResponseRedirect(location)


@login_required
def external_bind_start(request, provider):
    # 输入：当前登录用户的 GET/POST 和 provider 键；输出：密码确认表单、授权跳转或失败页；调用者：第三方绑定路由；失败：停用、密码错误或 provider 不可用时拒绝。
    # 业务判断：绑定在创建事务前要求重新验证当前密码；事务随后再绑定发起用户与当前 Session。
    if not request.user.is_active:
        raise PermissionDenied("停用账号不能管理第三方身份。")
    identity_choices = tuple(
        (hint, data["display_name"]) for hint, data in FAKE_IDENTITIES.items()
    )
    form = ExternalIdentityBindForm(
        request.POST or None,
        user=request.user,
        identity_choices=identity_choices,
    )
    if request.method == "POST":
        if not form.is_valid():
            return render(request, "accounts/external_identity_bind.html", {"form": form})
        try:
            location = start_external_flow(
                request,
                provider,
                LoginIntent.BIND,
                identity_hint=form.cleaned_data["identity"],
            )
        except (ExternalFlowError, ProviderUnavailable) as error:
            if isinstance(error, ProviderUnavailable):
                error = ExternalFlowError("provider_unavailable")
            return _external_flow_error_response(request, error)
        # 返回：密码确认和流程创建都成功后，浏览器才进入 provider 授权页。
        return HttpResponseRedirect(location)
    # 返回：GET 仅展示绑定表单，不提前创建登录事务或生成 state。
    return render(request, "accounts/external_identity_bind.html", {"form": form})


@require_http_methods(["GET", "POST"])
def fake_authorize(request):
    # 输入：Fake 授权页 GET/POST；输出：授权确认页或带一次性 code/拒绝错误的回调重定向；调用者：Fake provider；失败：配置、Session 或参数不匹配时拒绝。
    # 业务判断：Fake 也必须经过完整浏览器往返，且未启用时失败关闭，绝不作为真实 provider 的隐式降级。
    try:
        fake_provider = get_provider(IdentityProvider.FAKE)
    except ProviderUnavailable:
        return render(
            request,
            "accounts/external_identity_result.html",
            {"success": False, "message": "Fake Provider 当前未启用。"},
            status=404,
        )

    source = request.POST if request.method == "POST" else request.GET
    initial = {
        "identity": source.get("identity", ""),
        "redirect_uri": source.get("redirect_uri", ""),
        "state": source.get("state", ""),
        "code_challenge": source.get("code_challenge", ""),
        "nonce": source.get("nonce", ""),
        "transaction_id": source.get("transaction_id", ""),
        "decision": "approve",
    }
    identity_data = FAKE_IDENTITIES.get(initial["identity"])
    # Session 绑定与 state：回调地址必须由服务端生成，事务号、state、身份提示必须仍与当前 Session 成组一致。
    request_is_current = (
        identity_data is not None
        and initial["redirect_uri"]
        == expected_redirect_uri(request, IdentityProvider.FAKE)
        and request.session.get(SESSION_TRANSACTION_KEY)
        == initial["transaction_id"]
        and request.session.get(SESSION_STATE_KEY) == initial["state"]
        and request.session.get(SESSION_IDENTITY_HINT_KEY)
        == initial["identity"]
    )
    if not request_is_current:
        return render(
            request,
            "accounts/external_identity_result.html",
            {"success": False, "message": "Fake 授权请求已经失效，请重新开始流程。"},
            status=400,
        )

    form = FakeAuthorizeForm(request.POST or None, initial=initial)
    if request.method == "GET":
        return render(
            request,
            "accounts/fake_authorize.html",
            {"form": form, "identity": identity_data},
        )
    if not form.is_valid():
        return render(
            request,
            "accounts/fake_authorize.html",
            {"form": form, "identity": identity_data},
            status=400,
        )

    values = form.cleaned_data
    # 业务判断：POST 隐藏字段还必须与本次已验证的初始值一致，防止浏览器篡改事务、state 或回调地址。
    if (
        values["identity"] != initial["identity"]
        or values["redirect_uri"] != initial["redirect_uri"]
        or str(values["transaction_id"]) != initial["transaction_id"]
        or values["state"] != initial["state"]
    ):
        return render(
            request,
            "accounts/external_identity_result.html",
            {"success": False, "message": "Fake 授权参数被修改，请重新开始流程。"},
            status=400,
        )

    # 返回拒绝：仍带原 state 和事务号回服务端回调，由身份服务原子消费事务并记录拒绝，防止重放。
    if values["decision"] == "deny":
        callback_query = urlencode(
            {
                "transaction_id": str(values["transaction_id"]),
                "state": values["state"],
                "error": "access_denied",
            }
        )
        return HttpResponseRedirect("%s?%s" % (values["redirect_uri"], callback_query))

    # 保存：一次性 code 连同固定 redirect_uri、PKCE challenge 和 nonce 写入当前 Session；complete_callback 会先 pop 防重放。
    code = fake_provider.issue_code(
        request,
        subject=identity_data["subject"],
        display_name=identity_data["display_name"],
        email=identity_data["email"],
        redirect_uri=values["redirect_uri"],
        state=values["state"],
        code_challenge=values["code_challenge"],
        nonce=values["nonce"],
    )
    callback_query = urlencode(
        {
            "transaction_id": str(values["transaction_id"]),
            "state": values["state"],
            "code": code,
        }
    )
    # 返回批准：浏览器只携带一次性 code、事务号和 state，verifier/nonce 原值仍只在服务端 Session。
    return HttpResponseRedirect("%s?%s" % (values["redirect_uri"], callback_query))


@require_http_methods(["GET"])
def external_callback(request, provider):
    # 输入：provider 回调 GET，含事务号、state 以及 code 或错误；输出：结果页或成功重定向；调用者：第三方授权服务器；失败：缺参、重放、绑定校验或 provider 验证失败时统一拒绝。
    # 输入判断：只接受完整的服务端事务号与 state；code 和 provider_error 必须至少有一个。
    transaction_id = request.GET.get("transaction_id", "")
    state = request.GET.get("state", "")
    code = request.GET.get("code", "")
    provider_error = request.GET.get("error", "")
    if not transaction_id or not state or (not code and not provider_error):
        return render(
            request,
            "accounts/external_identity_result.html",
            {"success": False, "message": "外部身份回调无效，请重新开始流程。"},
            status=400,
        )
    try:
        transaction_id = uuid.UUID(transaction_id)
    except ValueError:
        return render(
            request,
            "accounts/external_identity_result.html",
            {"success": False, "message": "外部身份回调无效，请重新开始流程。"},
            status=400,
        )

    # 业务判断：有 provider_error 时走拒绝消费；否则才允许携带 code 完成身份验证，二者都不能绕过事务校验。
    try:
        if provider_error:
            reject_external_callback(request, provider, transaction_id, state)
        result = finish_external_callback(
            request,
            provider,
            transaction_id,
            state,
            code,
        )
    except (ExternalFlowError, ProviderUnavailable) as error:
        if isinstance(error, ProviderUnavailable):
            error = ExternalFlowError("provider_unavailable")
        return _external_flow_error_response(request, error)

    # 返回：绑定保持当前登录用户并回身份列表；登录已由服务层轮换 Session key 后回首页。
    if result["kind"] == "bound":
        messages.success(request, "第三方身份已绑定到当前账号。")
        return redirect("accounts:external_identities")
    messages.success(request, "第三方身份登录成功。")
    return redirect("accounts:home")


@login_required
def external_identities(request):
    # 输入：当前登录请求；输出：本人第三方身份列表响应；调用者：身份列表路由；失败：停用账号 403 或数据库读取异常。
    if not request.user.is_active:
        raise PermissionDenied("停用账号不能管理第三方身份。")
    # 数据库读取：仅按当前用户外键过滤，不允许通过请求参数查看其他用户身份。
    identities = ExternalIdentity.objects.filter(user=request.user).order_by(
        "provider", "subject"
    )
    return render(
        request,
        "accounts/external_identity_list.html",
        {"identities": identities},
    )


@login_required
@require_POST
def external_identity_unbind(request, pk):
    # 输入：当前用户 POST 和身份主键；输出：身份列表重定向；调用者：解绑路由；失败：停用、非本人或最后登录方式时拒绝并显示安全消息。
    # 业务判断、锁顺序和保存由 unbind_external_identity 在同一事务内完成，视图不直接修改归属。
    if not request.user.is_active:
        raise PermissionDenied("停用账号不能管理第三方身份。")
    try:
        unbind_external_identity(request, pk)
    except ExternalFlowError as error:
        if error.reason_code == "last_login_method":
            messages.error(request, "至少保留一个可用的本地密码或第三方登录方式。")
        elif error.status_code == 404:
            messages.error(request, "第三方身份不存在或不属于当前账号。")
        else:
            messages.error(request, "第三方身份解绑失败。")
    else:
        messages.success(request, "第三方身份已解绑，历史身份记录仍被保留。")
    return redirect("accounts:external_identities")
