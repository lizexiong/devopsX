# devopsX/settings.py
import os
from pathlib import Path

from django.core.exceptions import ImproperlyConfigured
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
# 教程从项目根目录读取 .env；load_dotenv 只补充进程环境，具体值仍在下方逐项校验。
load_dotenv(BASE_DIR / ".env")


def _env_bool(name, default=False):
    # 输入：环境变量名和缺省布尔值；输出：严格解析后的 bool；调用者：DEBUG 与 Fake Provider 配置；失败：未知文本时抛 ImproperlyConfigured 而不猜测。
    raw_value = os.getenv(name)
    if raw_value is None:
        return default
    normalized = raw_value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise ImproperlyConfigured("环境变量 %s 必须是布尔值。" % name)


# SECRET_KEY 同时保护 Django 签名及本教程 state、nonce、Session 绑定摘要，禁止使用源码内默认值。
SECRET_KEY = os.getenv("DEVOPSX_SECRET_KEY", "").strip()
if not SECRET_KEY:
    raise ImproperlyConfigured("必须通过 DEVOPSX_SECRET_KEY 配置 Django 密钥。")

DEBUG = _env_bool("DEVOPSX_DEBUG", False)
# ALLOWED_HOSTS 只接收显式逗号分隔值；空项被丢弃，避免教程环境隐式信任任意 Host。
ALLOWED_HOSTS = [
    host.strip()
    for host in os.getenv("DEVOPSX_ALLOWED_HOSTS", "").split(",")
    if host.strip()
]

INSTALLED_APPS = [
    # Django 内置后台与认证模型保留用于登录兼容；业务授权由 accounts 自有 RBAC 实现。
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "accounts.apps.AccountsConfig",
]

MIDDLEWARE = [
    # Session 必须先于 AuthenticationMiddleware，第三方流程才能同时读取 Session 绑定和 request.user。
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "devopsX.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                # request 进入模板上下文后，policy_can 标签才能复用请求级 PolicySnapshot。
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "devopsX.wsgi.application"
ASGI_APPLICATION = "devopsX.asgi.application"

# 本隔离项目只使用 SQLite。MySQL 将在后续教程中单独配置。
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.CommonPasswordValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.NumericPasswordValidator",
    },
]

LANGUAGE_CODE = "zh-hans"
TIME_ZONE = "Asia/Shanghai"
USE_I18N = True
USE_TZ = True

STATIC_URL = "/static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# 自定义用户模型必须在首次迁移前固定；默认后端仅负责密码认证，业务能力检查位于 accounts.policy。
AUTH_USER_MODEL = "accounts.User"
AUTHENTICATION_BACKENDS = ["django.contrib.auth.backends.ModelBackend"]
LOGIN_URL = "accounts:login"
LOGIN_REDIRECT_URL = "accounts:home"
LOGOUT_REDIRECT_URL = "accounts:login"

# Fake provider 只用于本地学习和确定性测试，真实环境默认关闭。
ACCOUNTS_ENABLE_FAKE_PROVIDER = _env_bool(
    "DEVOPSX_ACCOUNTS_ENABLE_FAKE_PROVIDER",
    DEBUG,
)
if ACCOUNTS_ENABLE_FAKE_PROVIDER and not DEBUG:
    raise ImproperlyConfigured("生产模式禁止启用本地 Fake Provider。")
ACCOUNTS_FAKE_PROVIDER_ALLOWED = DEBUG
# 登录事务五分钟后失效；回调还必须同时通过 state、Session、PKCE、nonce 和一次消费状态检查。
ACCOUNTS_EXTERNAL_LOGIN_TTL_SECONDS = 300
