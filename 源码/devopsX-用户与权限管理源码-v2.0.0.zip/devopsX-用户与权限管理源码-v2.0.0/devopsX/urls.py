# devopsX/urls.py
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    # Django Admin 保留为仅激活超级用户可用的内部运维入口，模型后台另有只读/禁止删除限制。
    path("admin/", admin.site.urls),
    # 业务首页、账号 RBAC 与第三方身份流程统一由 accounts 应用命名路由承载。
    path("", include("accounts.urls")),
]
