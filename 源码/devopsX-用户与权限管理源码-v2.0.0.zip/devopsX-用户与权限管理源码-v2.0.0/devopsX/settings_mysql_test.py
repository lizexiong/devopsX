import os


os.environ.setdefault("DEVOPSX_SECRET_KEY", "test-only-key-not-for-deployment")
os.environ.setdefault("DEVOPSX_DEBUG", "true")
os.environ.setdefault("DEVOPSX_ALLOWED_HOSTS", "localhost,127.0.0.1,testserver")

from .settings import *  # noqa: F403,E402

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "NAME": "devopsx_test",
        "USER": os.environ["DEVOPSX_DB_USER"],
        "PASSWORD": os.environ["DEVOPSX_DB_PASSWORD"],
        "HOST": os.getenv("DEVOPSX_DB_HOST", "127.0.0.1"),
        "PORT": os.getenv("DEVOPSX_DB_PORT", "3306"),
        "OPTIONS": {
            "charset": "utf8mb4",
            "init_command": "SET sql_mode='STRICT_TRANS_TABLES'",
        },
        "TEST": {
            "NAME": "devopsx_test",
        },
    }
}

PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.MD5PasswordHasher",
]
