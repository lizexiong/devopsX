# devopsX/devopsX/settings_test.py
import os


os.environ.setdefault("DEVOPSX_SECRET_KEY", "test-only-key-not-for-deployment")
os.environ.setdefault("DEVOPSX_DEBUG", "true")
os.environ.setdefault("DEVOPSX_ALLOWED_HOSTS", "localhost,127.0.0.1,testserver")

# 导入正常 settings.py 中的全部配置。
from .settings import *  # noqa: F403,E402


# 测试时覆盖默认数据库，使用内存 SQLite。
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": ":memory:",
    }
}

# 测试只验证密码逻辑，不需要使用生产级慢哈希消耗时间。
PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.MD5PasswordHasher",
]
